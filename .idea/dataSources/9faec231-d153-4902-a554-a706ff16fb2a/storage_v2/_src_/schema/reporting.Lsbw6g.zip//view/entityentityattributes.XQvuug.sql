create definer = echothree@`127.0.0.1` view entityentityattributes as
select `echothree`.`entityentityattributes`.`eea_entityentityattributeid`   AS `eea_entityentityattributeid`,
       `echothree`.`entityentityattributes`.`eea_ena_entityattributeid`     AS `eea_ena_entityattributeid`,
       `echothree`.`entityentityattributes`.`eea_eni_entityinstanceid`      AS `eea_eni_entityinstanceid`,
       `echothree`.`entityentityattributes`.`eea_entityinstanceattributeid` AS `eea_entityinstanceattributeid`
from `echothree`.`entityentityattributes`
where (`echothree`.`entityentityattributes`.`eea_thrutime` = 9223372036854775807);

