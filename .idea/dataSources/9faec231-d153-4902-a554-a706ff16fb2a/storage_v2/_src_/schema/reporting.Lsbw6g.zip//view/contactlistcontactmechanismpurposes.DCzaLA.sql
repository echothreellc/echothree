create definer = echothree@`127.0.0.1` view contactlistcontactmechanismpurposes as
select `echothree`.`contactlistcontactmechanismpurposes`.`clstcmpr_contactlistcontactmechanismpurposeid`   AS `clstcmpr_contactlistcontactmechanismpurposeid`,
       `echothree`.`contactlistcontactmechanismpurposedetails`.`clstcmprdt_clst_contactlistid`             AS `clstcmprdt_clst_contactlistid`,
       `echothree`.`contactlistcontactmechanismpurposedetails`.`clstcmprdt_cmpr_contactmechanismpurposeid` AS `clstcmprdt_cmpr_contactmechanismpurposeid`,
       `echothree`.`contactlistcontactmechanismpurposedetails`.`clstcmprdt_isdefault`                      AS `clstcmprdt_isdefault`,
       `echothree`.`contactlistcontactmechanismpurposedetails`.`clstcmprdt_sortorder`                      AS `clstcmprdt_sortorder`
from `echothree`.`contactlistcontactmechanismpurposes`
         join `echothree`.`contactlistcontactmechanismpurposedetails`
where (`echothree`.`contactlistcontactmechanismpurposes`.`clstcmpr_activedetailid` =
       `echothree`.`contactlistcontactmechanismpurposedetails`.`clstcmprdt_contactlistcontactmechanismpurposedetailid`);

