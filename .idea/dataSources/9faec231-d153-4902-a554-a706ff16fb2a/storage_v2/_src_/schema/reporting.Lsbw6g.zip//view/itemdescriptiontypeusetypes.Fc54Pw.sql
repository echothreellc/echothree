create definer = echothree@`127.0.0.1` view itemdescriptiontypeusetypes as
select `echothree`.`itemdescriptiontypeusetypes`.`idtutyp_itemdescriptiontypeusetypeid`           AS `idtutyp_itemdescriptiontypeusetypeid`,
       `echothree`.`itemdescriptiontypeusetypedetails`.`idtutypdt_itemdescriptiontypeusetypename` AS `idtutypdt_itemdescriptiontypeusetypename`,
       `echothree`.`itemdescriptiontypeusetypedetails`.`idtutypdt_isdefault`                      AS `idtutypdt_isdefault`,
       `echothree`.`itemdescriptiontypeusetypedetails`.`idtutypdt_sortorder`                      AS `idtutypdt_sortorder`
from `echothree`.`itemdescriptiontypeusetypes`
         join `echothree`.`itemdescriptiontypeusetypedetails`
where (`echothree`.`itemdescriptiontypeusetypes`.`idtutyp_activedetailid` =
       `echothree`.`itemdescriptiontypeusetypedetails`.`idtutypdt_itemdescriptiontypeusetypedetailid`);

