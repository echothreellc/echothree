create definer = echothree@`127.0.0.1` view documentblobs as
select `echothree`.`documentblobs`.`dcmntb_documentblobid`   AS `dcmntb_documentblobid`,
       `echothree`.`documentblobs`.`dcmntb_dcmnt_documentid` AS `dcmntb_dcmnt_documentid`,
       `echothree`.`documentblobs`.`dcmntb_blob`             AS `dcmntb_blob`
from `echothree`.`documentblobs`
where (`echothree`.`documentblobs`.`dcmntb_thrutime` = 9223372036854775807);

