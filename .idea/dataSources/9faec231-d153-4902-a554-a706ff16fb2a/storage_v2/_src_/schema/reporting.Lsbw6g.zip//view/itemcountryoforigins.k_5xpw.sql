create definer = echothree@`127.0.0.1` view itemcountryoforigins as
select `echothree`.`itemcountryoforigins`.`icoorgn_itemcountryoforiginid` AS `icoorgn_itemcountryoforiginid`,
       `echothree`.`itemcountryoforigins`.`icoorgn_itm_itemid`            AS `icoorgn_itm_itemid`,
       `echothree`.`itemcountryoforigins`.`icoorgn_countrygeocodeid`      AS `icoorgn_countrygeocodeid`,
       `echothree`.`itemcountryoforigins`.`icoorgn_percent`               AS `icoorgn_percent`
from `echothree`.`itemcountryoforigins`
where (`echothree`.`itemcountryoforigins`.`icoorgn_thrutime` = 9223372036854775807);

