create definer = echothree@`127.0.0.1` view contacttelephones as
select `echothree`.`contacttelephones`.`cttp_contacttelephoneid`      AS `cttp_contacttelephoneid`,
       `echothree`.`contacttelephones`.`cttp_cmch_contactmechanismid` AS `cttp_cmch_contactmechanismid`,
       `echothree`.`contacttelephones`.`cttp_countrygeocodeid`        AS `cttp_countrygeocodeid`,
       `echothree`.`contacttelephones`.`cttp_areacode`                AS `cttp_areacode`,
       `echothree`.`contacttelephones`.`cttp_telephonenumber`         AS `cttp_telephonenumber`,
       `echothree`.`contacttelephones`.`cttp_telephoneextension`      AS `cttp_telephoneextension`
from `echothree`.`contacttelephones`
where (`echothree`.`contacttelephones`.`cttp_thrutime` = 9223372036854775807);

