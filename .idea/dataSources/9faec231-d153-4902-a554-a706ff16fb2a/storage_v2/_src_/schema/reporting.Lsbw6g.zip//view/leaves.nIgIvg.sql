create definer = echothree@`127.0.0.1` view leaves as
select `echothree`.`leaves`.`lv_leaveid`                     AS `lv_leaveid`,
       `echothree`.`leavedetails`.`lvdt_leavename`           AS `lvdt_leavename`,
       `echothree`.`leavedetails`.`lvdt_par_partyid`         AS `lvdt_par_partyid`,
       `echothree`.`leavedetails`.`lvdt_companypartyid`      AS `lvdt_companypartyid`,
       `echothree`.`leavedetails`.`lvdt_lvtyp_leavetypeid`   AS `lvdt_lvtyp_leavetypeid`,
       `echothree`.`leavedetails`.`lvdt_lvrsn_leavereasonid` AS `lvdt_lvrsn_leavereasonid`,
       `echothree`.`leavedetails`.`lvdt_starttime`           AS `lvdt_starttime`,
       `echothree`.`leavedetails`.`lvdt_endtime`             AS `lvdt_endtime`,
       `echothree`.`leavedetails`.`lvdt_totaltime`           AS `lvdt_totaltime`
from `echothree`.`leaves`
         join `echothree`.`leavedetails`
where (`echothree`.`leaves`.`lv_activedetailid` = `echothree`.`leavedetails`.`lvdt_leavedetailid`);

