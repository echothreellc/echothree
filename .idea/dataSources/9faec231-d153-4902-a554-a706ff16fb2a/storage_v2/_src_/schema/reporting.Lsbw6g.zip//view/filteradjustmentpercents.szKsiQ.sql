create definer = echothree@`127.0.0.1` view filteradjustmentpercents as
select `echothree`.`filteradjustmentpercents`.`fltap_filteradjustmentpercentid` AS `fltap_filteradjustmentpercentid`,
       `echothree`.`filteradjustmentpercents`.`fltap_flta_filteradjustmentid`   AS `fltap_flta_filteradjustmentid`,
       `echothree`.`filteradjustmentpercents`.`fltap_uomt_unitofmeasuretypeid`  AS `fltap_uomt_unitofmeasuretypeid`,
       `echothree`.`filteradjustmentpercents`.`fltap_cur_currencyid`            AS `fltap_cur_currencyid`,
       `echothree`.`filteradjustmentpercents`.`fltap_percent`                   AS `fltap_percent`
from `echothree`.`filteradjustmentpercents`
where (`echothree`.`filteradjustmentpercents`.`fltap_thrutime` = 9223372036854775807);

