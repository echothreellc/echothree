create definer = echothree@`127.0.0.1` view indextypes as
select `echothree`.`indextypes`.`idxt_indextypeid`              AS `idxt_indextypeid`,
       `echothree`.`indextypedetails`.`idxtdt_indextypename`    AS `idxtdt_indextypename`,
       `echothree`.`indextypedetails`.`idxtdt_ent_entitytypeid` AS `idxtdt_ent_entitytypeid`,
       `echothree`.`indextypedetails`.`idxtdt_isdefault`        AS `idxtdt_isdefault`,
       `echothree`.`indextypedetails`.`idxtdt_sortorder`        AS `idxtdt_sortorder`
from `echothree`.`indextypes`
         join `echothree`.`indextypedetails`
where (`echothree`.`indextypes`.`idxt_activedetailid` = `echothree`.`indextypedetails`.`idxtdt_indextypedetailid`);

