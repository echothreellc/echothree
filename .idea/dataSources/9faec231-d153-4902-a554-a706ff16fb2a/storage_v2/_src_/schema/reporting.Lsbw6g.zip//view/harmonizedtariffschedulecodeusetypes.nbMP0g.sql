create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodeusetypes as
select `echothree`.`harmonizedtariffschedulecodeusetypes`.`hztscutyp_harmonizedtariffschedulecodeusetypeid`           AS `hztscutyp_harmonizedtariffschedulecodeusetypeid`,
       `echothree`.`harmonizedtariffschedulecodeusetypedetails`.`hztscutypdt_harmonizedtariffschedulecodeusetypename` AS `hztscutypdt_harmonizedtariffschedulecodeusetypename`,
       `echothree`.`harmonizedtariffschedulecodeusetypedetails`.`hztscutypdt_isdefault`                               AS `hztscutypdt_isdefault`,
       `echothree`.`harmonizedtariffschedulecodeusetypedetails`.`hztscutypdt_sortorder`                               AS `hztscutypdt_sortorder`
from `echothree`.`harmonizedtariffschedulecodeusetypes`
         join `echothree`.`harmonizedtariffschedulecodeusetypedetails`
where (`echothree`.`harmonizedtariffschedulecodeusetypes`.`hztscutyp_activedetailid` =
       `echothree`.`harmonizedtariffschedulecodeusetypedetails`.`hztscutypdt_harmonizedtariffschedulecodeusetypedetailid`);

