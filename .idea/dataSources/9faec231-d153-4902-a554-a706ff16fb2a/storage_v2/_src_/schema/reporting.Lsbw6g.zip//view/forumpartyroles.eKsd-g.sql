create definer = echothree@`127.0.0.1` view forumpartyroles as
select `echothree`.`forumpartyroles`.`frmparr_forumpartyroleid`        AS `frmparr_forumpartyroleid`,
       `echothree`.`forumpartyroles`.`frmparr_frm_forumid`             AS `frmparr_frm_forumid`,
       `echothree`.`forumpartyroles`.`frmparr_par_partyid`             AS `frmparr_par_partyid`,
       `echothree`.`forumpartyroles`.`frmparr_frmrtyp_forumroletypeid` AS `frmparr_frmrtyp_forumroletypeid`
from `echothree`.`forumpartyroles`
where (`echothree`.`forumpartyroles`.`frmparr_thrutime` = 9223372036854775807);

