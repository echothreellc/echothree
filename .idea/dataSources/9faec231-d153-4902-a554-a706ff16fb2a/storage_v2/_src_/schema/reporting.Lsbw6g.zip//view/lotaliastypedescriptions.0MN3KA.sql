create definer = echothree@`127.0.0.1` view lotaliastypedescriptions as
select `echothree`.`lotaliastypedescriptions`.`ltaltypd_lotaliastypedescriptionid` AS `ltaltypd_lotaliastypedescriptionid`,
       `echothree`.`lotaliastypedescriptions`.`ltaltypd_ltaltyp_lotaliastypeid`    AS `ltaltypd_ltaltyp_lotaliastypeid`,
       `echothree`.`lotaliastypedescriptions`.`ltaltypd_lang_languageid`           AS `ltaltypd_lang_languageid`,
       `echothree`.`lotaliastypedescriptions`.`ltaltypd_description`               AS `ltaltypd_description`
from `echothree`.`lotaliastypedescriptions`
where (`echothree`.`lotaliastypedescriptions`.`ltaltypd_thrutime` = 9223372036854775807);

