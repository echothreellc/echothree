create definer = echothree@`127.0.0.1` view entitylongrangedescriptions as
select `echothree`.`entitylongrangedescriptions`.`enlrd_entitylongrangedescriptionid` AS `enlrd_entitylongrangedescriptionid`,
       `echothree`.`entitylongrangedescriptions`.`enlrd_enlr_entitylongrangeid`       AS `enlrd_enlr_entitylongrangeid`,
       `echothree`.`entitylongrangedescriptions`.`enlrd_lang_languageid`              AS `enlrd_lang_languageid`,
       `echothree`.`entitylongrangedescriptions`.`enlrd_description`                  AS `enlrd_description`
from `echothree`.`entitylongrangedescriptions`
where (`echothree`.`entitylongrangedescriptions`.`enlrd_thrutime` = 9223372036854775807);

