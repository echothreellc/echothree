create definer = echothree@`127.0.0.1` view itemvariableprices as
select `echothree`.`itemvariableprices`.`itmvp_itemvariablepriceid` AS `itmvp_itemvariablepriceid`,
       `echothree`.`itemvariableprices`.`itmvp_itmp_itempriceid`    AS `itmvp_itmp_itempriceid`,
       `echothree`.`itemvariableprices`.`itmvp_minimumunitprice`    AS `itmvp_minimumunitprice`,
       `echothree`.`itemvariableprices`.`itmvp_maximumunitprice`    AS `itmvp_maximumunitprice`,
       `echothree`.`itemvariableprices`.`itmvp_unitpriceincrement`  AS `itmvp_unitpriceincrement`
from `echothree`.`itemvariableprices`
where (`echothree`.`itemvariableprices`.`itmvp_thrutime` = 9223372036854775807);

