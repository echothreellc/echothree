create definer = echothree@`127.0.0.1` view communicationsourcetypedescriptions as
select `echothree`.`communicationsourcetypedescriptions`.`cmmnsrctypd_communicationsourcetypedescriptionid` AS `cmmnsrctypd_communicationsourcetypedescriptionid`,
       `echothree`.`communicationsourcetypedescriptions`.`cmmnsrctypd_cmmnsrctyp_communicationsourcetypeid` AS `cmmnsrctypd_cmmnsrctyp_communicationsourcetypeid`,
       `echothree`.`communicationsourcetypedescriptions`.`cmmnsrctypd_lang_languageid`                      AS `cmmnsrctypd_lang_languageid`,
       `echothree`.`communicationsourcetypedescriptions`.`cmmnsrctypd_description`                          AS `cmmnsrctypd_description`
from `echothree`.`communicationsourcetypedescriptions`;

