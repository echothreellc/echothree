create definer = echothree@`127.0.0.1` view appearancedescriptions as
select `echothree`.`appearancedescriptions`.`apprncd_appearancedescriptionid` AS `apprncd_appearancedescriptionid`,
       `echothree`.`appearancedescriptions`.`apprncd_apprnc_appearanceid`     AS `apprncd_apprnc_appearanceid`,
       `echothree`.`appearancedescriptions`.`apprncd_lang_languageid`         AS `apprncd_lang_languageid`,
       `echothree`.`appearancedescriptions`.`apprncd_description`             AS `apprncd_description`
from `echothree`.`appearancedescriptions`
where (`echothree`.`appearancedescriptions`.`apprncd_thrutime` = 9223372036854775807);

