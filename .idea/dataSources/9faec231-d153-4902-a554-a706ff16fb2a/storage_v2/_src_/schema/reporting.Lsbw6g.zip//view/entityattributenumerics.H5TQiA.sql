create definer = echothree@`127.0.0.1` view entityattributenumerics as
select `echothree`.`entityattributenumerics`.`enan_entityattributenumericid` AS `enan_entityattributenumericid`,
       `echothree`.`entityattributenumerics`.`enan_ena_entityattributeid`    AS `enan_ena_entityattributeid`,
       `echothree`.`entityattributenumerics`.`enan_uomt_unitofmeasuretypeid` AS `enan_uomt_unitofmeasuretypeid`
from `echothree`.`entityattributenumerics`
where (`echothree`.`entityattributenumerics`.`enan_thrutime` = 9223372036854775807);

