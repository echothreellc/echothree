create definer = echothree@`127.0.0.1` view itemaliases as
select `echothree`.`itemaliases`.`itmal_itemaliasid`              AS `itmal_itemaliasid`,
       `echothree`.`itemaliases`.`itmal_itm_itemid`               AS `itmal_itm_itemid`,
       `echothree`.`itemaliases`.`itmal_uomt_unitofmeasuretypeid` AS `itmal_uomt_unitofmeasuretypeid`,
       `echothree`.`itemaliases`.`itmal_iat_itemaliastypeid`      AS `itmal_iat_itemaliastypeid`,
       `echothree`.`itemaliases`.`itmal_alias`                    AS `itmal_alias`
from `echothree`.`itemaliases`
where (`echothree`.`itemaliases`.`itmal_thrutime` = 9223372036854775807);

