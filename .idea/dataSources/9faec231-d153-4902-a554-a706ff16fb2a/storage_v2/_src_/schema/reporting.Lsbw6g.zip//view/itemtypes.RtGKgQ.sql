create definer = echothree@`127.0.0.1` view itemtypes as
select `echothree`.`itemtypes`.`ityp_itemtypeid`   AS `ityp_itemtypeid`,
       `echothree`.`itemtypes`.`ityp_itemtypename` AS `ityp_itemtypename`,
       `echothree`.`itemtypes`.`ityp_isdefault`    AS `ityp_isdefault`,
       `echothree`.`itemtypes`.`ityp_sortorder`    AS `ityp_sortorder`
from `echothree`.`itemtypes`;

