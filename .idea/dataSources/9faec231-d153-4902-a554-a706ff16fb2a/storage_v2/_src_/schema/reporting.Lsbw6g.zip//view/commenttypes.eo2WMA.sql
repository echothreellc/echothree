create definer = echothree@`127.0.0.1` view commenttypes as
select `echothree`.`commenttypes`.`cmnttyp_commenttypeid`                      AS `cmnttyp_commenttypeid`,
       `echothree`.`commenttypedetails`.`cmnttypdt_ent_entitytypeid`           AS `cmnttypdt_ent_entitytypeid`,
       `echothree`.`commenttypedetails`.`cmnttypdt_commenttypename`            AS `cmnttypdt_commenttypename`,
       `echothree`.`commenttypedetails`.`cmnttypdt_commentsequenceid`          AS `cmnttypdt_commentsequenceid`,
       `echothree`.`commenttypedetails`.`cmnttypdt_wkflen_workflowentranceid`  AS `cmnttypdt_wkflen_workflowentranceid`,
       `echothree`.`commenttypedetails`.`cmnttypdt_mtyput_mimetypeusagetypeid` AS `cmnttypdt_mtyput_mimetypeusagetypeid`,
       `echothree`.`commenttypedetails`.`cmnttypdt_sortorder`                  AS `cmnttypdt_sortorder`
from `echothree`.`commenttypes`
         join `echothree`.`commenttypedetails`
where (`echothree`.`commenttypes`.`cmnttyp_activedetailid` =
       `echothree`.`commenttypedetails`.`cmnttypdt_commenttypedetailid`);

