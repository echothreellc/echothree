create definer = echothree@`127.0.0.1` view invoiceroletypedescriptions as
select `echothree`.`invoiceroletypedescriptions`.`invcrtypd_invoiceroletypedescriptionid` AS `invcrtypd_invoiceroletypedescriptionid`,
       `echothree`.`invoiceroletypedescriptions`.`invcrtypd_invcrtyp_invoiceroletypeid`   AS `invcrtypd_invcrtyp_invoiceroletypeid`,
       `echothree`.`invoiceroletypedescriptions`.`invcrtypd_lang_languageid`              AS `invcrtypd_lang_languageid`,
       `echothree`.`invoiceroletypedescriptions`.`invcrtypd_description`                  AS `invcrtypd_description`
from `echothree`.`invoiceroletypedescriptions`;

