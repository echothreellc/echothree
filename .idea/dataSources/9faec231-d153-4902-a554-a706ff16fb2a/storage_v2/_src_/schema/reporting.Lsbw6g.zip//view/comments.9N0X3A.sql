create definer = echothree@`127.0.0.1` view comments as
select `echothree`.`comments`.`cmnt_commentid`                           AS `cmnt_commentid`,
       `echothree`.`commentdetails`.`cmntdt_commentname`                 AS `cmntdt_commentname`,
       `echothree`.`commentdetails`.`cmntdt_cmnttyp_commenttypeid`       AS `cmntdt_cmnttyp_commenttypeid`,
       `echothree`.`commentdetails`.`cmntdt_commentedentityinstanceid`   AS `cmntdt_commentedentityinstanceid`,
       `echothree`.`commentdetails`.`cmntdt_commentedbyentityinstanceid` AS `cmntdt_commentedbyentityinstanceid`,
       `echothree`.`commentdetails`.`cmntdt_lang_languageid`             AS `cmntdt_lang_languageid`,
       `echothree`.`commentdetails`.`cmntdt_description`                 AS `cmntdt_description`,
       `echothree`.`commentdetails`.`cmntdt_mtyp_mimetypeid`             AS `cmntdt_mtyp_mimetypeid`
from `echothree`.`comments`
         join `echothree`.`commentdetails`
where (`echothree`.`comments`.`cmnt_activedetailid` = `echothree`.`commentdetails`.`cmntdt_commentdetailid`);

