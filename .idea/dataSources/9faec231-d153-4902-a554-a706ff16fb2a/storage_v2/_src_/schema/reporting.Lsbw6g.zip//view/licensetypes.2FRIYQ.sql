create definer = echothree@`127.0.0.1` view licensetypes as
select `echothree`.`licensetypes`.`lcnstyp_licensetypeid`           AS `lcnstyp_licensetypeid`,
       `echothree`.`licensetypedetails`.`lcnstypdt_licensetypename` AS `lcnstypdt_licensetypename`,
       `echothree`.`licensetypedetails`.`lcnstypdt_isdefault`       AS `lcnstypdt_isdefault`,
       `echothree`.`licensetypedetails`.`lcnstypdt_sortorder`       AS `lcnstypdt_sortorder`
from `echothree`.`licensetypes`
         join `echothree`.`licensetypedetails`
where (`echothree`.`licensetypes`.`lcnstyp_activedetailid` =
       `echothree`.`licensetypedetails`.`lcnstypdt_licensetypedetailid`);

