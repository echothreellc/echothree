create definer = echothree@`127.0.0.1` view entitylongattributes as
select `echothree`.`entitylongattributes`.`enla_entitylongattributeid` AS `enla_entitylongattributeid`,
       `echothree`.`entitylongattributes`.`enla_ena_entityattributeid` AS `enla_ena_entityattributeid`,
       `echothree`.`entitylongattributes`.`enla_eni_entityinstanceid`  AS `enla_eni_entityinstanceid`,
       `echothree`.`entitylongattributes`.`enla_longattribute`         AS `enla_longattribute`
from `echothree`.`entitylongattributes`
where (`echothree`.`entitylongattributes`.`enla_thrutime` = 9223372036854775807);

