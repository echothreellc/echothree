create definer = echothree@`127.0.0.1` view itemharmonizedtariffschedulecodes as
select `echothree`.`itemharmonizedtariffschedulecodes`.`itmhztsc_itemharmonizedtariffschedulecodeid`                      AS `itmhztsc_itemharmonizedtariffschedulecodeid`,
       `echothree`.`itemharmonizedtariffschedulecodedetails`.`itmhztscdt_itm_itemid`                                      AS `itmhztscdt_itm_itemid`,
       `echothree`.`itemharmonizedtariffschedulecodedetails`.`itmhztscdt_countrygeocodeid`                                AS `itmhztscdt_countrygeocodeid`,
       `echothree`.`itemharmonizedtariffschedulecodedetails`.`itmhztscdt_hztscutyp_harmonizedtariffschedulecodeusetypeid` AS `itmhztscdt_hztscutyp_harmonizedtariffschedulecodeusetypeid`,
       `echothree`.`itemharmonizedtariffschedulecodedetails`.`itmhztscdt_hztsc_harmonizedtariffschedulecodeid`            AS `itmhztscdt_hztsc_harmonizedtariffschedulecodeid`
from `echothree`.`itemharmonizedtariffschedulecodes`
         join `echothree`.`itemharmonizedtariffschedulecodedetails`
where (`echothree`.`itemharmonizedtariffschedulecodes`.`itmhztsc_activedetailid` =
       `echothree`.`itemharmonizedtariffschedulecodedetails`.`itmhztscdt_itemharmonizedtariffschedulecodedetailid`);

