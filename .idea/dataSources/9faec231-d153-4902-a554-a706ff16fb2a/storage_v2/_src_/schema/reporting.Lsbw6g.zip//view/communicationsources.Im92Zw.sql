create definer = echothree@`127.0.0.1` view communicationsources as
select `echothree`.`communicationsources`.`cmmnsrc_communicationsourceid`                        AS `cmmnsrc_communicationsourceid`,
       `echothree`.`communicationsourcedetails`.`cmmnsrcdt_communicationsourcename`              AS `cmmnsrcdt_communicationsourcename`,
       `echothree`.`communicationsourcedetails`.`cmmnsrcdt_cmmnsrctyp_communicationsourcetypeid` AS `cmmnsrcdt_cmmnsrctyp_communicationsourcetypeid`,
       `echothree`.`communicationsourcedetails`.`cmmnsrcdt_sortorder`                            AS `cmmnsrcdt_sortorder`
from `echothree`.`communicationsources`
         join `echothree`.`communicationsourcedetails`
where (`echothree`.`communicationsources`.`cmmnsrc_activedetailid` =
       `echothree`.`communicationsourcedetails`.`cmmnsrcdt_communicationsourcedetailid`);

