create definer = echothree@`127.0.0.1` view chainkinddescriptions as
select `echothree`.`chainkinddescriptions`.`chnkd_chainkinddescriptionid` AS `chnkd_chainkinddescriptionid`,
       `echothree`.`chainkinddescriptions`.`chnkd_chnk_chainkindid`       AS `chnkd_chnk_chainkindid`,
       `echothree`.`chainkinddescriptions`.`chnkd_lang_languageid`        AS `chnkd_lang_languageid`,
       `echothree`.`chainkinddescriptions`.`chnkd_description`            AS `chnkd_description`
from `echothree`.`chainkinddescriptions`
where (`echothree`.`chainkinddescriptions`.`chnkd_thrutime` = 9223372036854775807);

