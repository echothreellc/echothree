create definer = echothree@`127.0.0.1` view invoicealiastypedescriptions as
select `echothree`.`invoicealiastypedescriptions`.`invcaltypd_invoicealiastypedescriptionid` AS `invcaltypd_invoicealiastypedescriptionid`,
       `echothree`.`invoicealiastypedescriptions`.`invcaltypd_invcaltyp_invoicealiastypeid`  AS `invcaltypd_invcaltyp_invoicealiastypeid`,
       `echothree`.`invoicealiastypedescriptions`.`invcaltypd_lang_languageid`               AS `invcaltypd_lang_languageid`,
       `echothree`.`invoicealiastypedescriptions`.`invcaltypd_description`                   AS `invcaltypd_description`
from `echothree`.`invoicealiastypedescriptions`
where (`echothree`.`invoicealiastypedescriptions`.`invcaltypd_thrutime` = 9223372036854775807);

