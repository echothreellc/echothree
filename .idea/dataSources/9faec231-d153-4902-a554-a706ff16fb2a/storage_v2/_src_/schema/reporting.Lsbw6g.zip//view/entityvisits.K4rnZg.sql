create definer = echothree@`127.0.0.1` view entityvisits as
select `echothree`.`entityvisits`.`evis_entityvisitid`           AS `evis_entityvisitid`,
       `echothree`.`entityvisits`.`evis_eni_entityinstanceid`    AS `evis_eni_entityinstanceid`,
       `echothree`.`entityvisits`.`evis_visitedentityinstanceid` AS `evis_visitedentityinstanceid`,
       `echothree`.`entityvisits`.`evis_visitedtime`             AS `evis_visitedtime`
from `echothree`.`entityvisits`;

