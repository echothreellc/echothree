create definer = echothree@`127.0.0.1` view locationdescriptions as
select `echothree`.`locationdescriptions`.`locd_locationdescriptionid` AS `locd_locationdescriptionid`,
       `echothree`.`locationdescriptions`.`locd_loc_locationid`        AS `locd_loc_locationid`,
       `echothree`.`locationdescriptions`.`locd_lang_languageid`       AS `locd_lang_languageid`,
       `echothree`.`locationdescriptions`.`locd_description`           AS `locd_description`
from `echothree`.`locationdescriptions`
where (`echothree`.`locationdescriptions`.`locd_thrutime` = 9223372036854775807);

