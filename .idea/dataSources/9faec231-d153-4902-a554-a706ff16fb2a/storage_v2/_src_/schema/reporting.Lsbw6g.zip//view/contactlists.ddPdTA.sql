create definer = echothree@`127.0.0.1` view contactlists as
select `echothree`.`contactlists`.`clst_contactlistid`                           AS `clst_contactlistid`,
       `echothree`.`contactlistdetails`.`clstdt_contactlistname`                 AS `clstdt_contactlistname`,
       `echothree`.`contactlistdetails`.`clstdt_clstgrp_contactlistgroupid`      AS `clstdt_clstgrp_contactlistgroupid`,
       `echothree`.`contactlistdetails`.`clstdt_clsttyp_contactlisttypeid`       AS `clstdt_clsttyp_contactlisttypeid`,
       `echothree`.`contactlistdetails`.`clstdt_clstfrq_contactlistfrequencyid`  AS `clstdt_clstfrq_contactlistfrequencyid`,
       `echothree`.`contactlistdetails`.`clstdt_defaultpartycontactliststatusid` AS `clstdt_defaultpartycontactliststatusid`,
       `echothree`.`contactlistdetails`.`clstdt_isdefault`                       AS `clstdt_isdefault`,
       `echothree`.`contactlistdetails`.`clstdt_sortorder`                       AS `clstdt_sortorder`
from `echothree`.`contactlists`
         join `echothree`.`contactlistdetails`
where (`echothree`.`contactlists`.`clst_activedetailid` =
       `echothree`.`contactlistdetails`.`clstdt_contactlistdetailid`);

