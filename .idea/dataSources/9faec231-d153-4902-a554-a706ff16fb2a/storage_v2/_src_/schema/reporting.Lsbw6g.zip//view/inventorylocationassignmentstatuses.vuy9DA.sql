create definer = echothree@`127.0.0.1` view inventorylocationassignmentstatuses as
select `echothree`.`inventorylocationassignmentstatuses`.`invlocasgnst_inventorylocationassignmentstatusid`      AS `invlocasgnst_inventorylocationassignmentstatusid`,
       `echothree`.`inventorylocationassignmentstatuses`.`invlocasgnst_invlocasgn_inventorylocationassignmentid` AS `invlocasgnst_invlocasgn_inventorylocationassignmentid`,
       `echothree`.`inventorylocationassignmentstatuses`.`invlocasgnst_quantityonhand`                           AS `invlocasgnst_quantityonhand`,
       `echothree`.`inventorylocationassignmentstatuses`.`invlocasgnst_availabletopromise`                       AS `invlocasgnst_availabletopromise`
from `echothree`.`inventorylocationassignmentstatuses`;

