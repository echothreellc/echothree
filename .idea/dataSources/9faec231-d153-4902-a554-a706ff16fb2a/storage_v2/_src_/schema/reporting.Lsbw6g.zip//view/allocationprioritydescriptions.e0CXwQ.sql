create definer = echothree@`127.0.0.1` view allocationprioritydescriptions as
select `echothree`.`allocationprioritydescriptions`.`allocprd_allocationprioritydescriptionid` AS `allocprd_allocationprioritydescriptionid`,
       `echothree`.`allocationprioritydescriptions`.`allocprd_allocpr_allocationpriorityid`    AS `allocprd_allocpr_allocationpriorityid`,
       `echothree`.`allocationprioritydescriptions`.`allocprd_lang_languageid`                 AS `allocprd_lang_languageid`,
       `echothree`.`allocationprioritydescriptions`.`allocprd_description`                     AS `allocprd_description`
from `echothree`.`allocationprioritydescriptions`
where (`echothree`.`allocationprioritydescriptions`.`allocprd_thrutime` = 9223372036854775807);

