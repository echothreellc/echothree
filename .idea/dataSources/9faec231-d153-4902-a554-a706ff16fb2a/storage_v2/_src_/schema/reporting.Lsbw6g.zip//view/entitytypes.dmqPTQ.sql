create definer = echothree@`127.0.0.1` view entitytypes as
select `echothree`.`entitytypes`.`ent_entitytypeid`                   AS `ent_entitytypeid`,
       `echothree`.`entitytypedetails`.`entdt_cvnd_componentvendorid` AS `entdt_cvnd_componentvendorid`,
       `echothree`.`entitytypedetails`.`entdt_entitytypename`         AS `entdt_entitytypename`,
       `echothree`.`entitytypedetails`.`entdt_keepallhistory`         AS `entdt_keepallhistory`,
       `echothree`.`entitytypedetails`.`entdt_locktimeout`            AS `entdt_locktimeout`,
       `echothree`.`entitytypedetails`.`entdt_sortorder`              AS `entdt_sortorder`
from `echothree`.`entitytypes`
         join `echothree`.`entitytypedetails`
where (`echothree`.`entitytypes`.`ent_activedetailid` = `echothree`.`entitytypedetails`.`entdt_entitytypedetailid`);

