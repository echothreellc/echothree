create definer = echothree@`127.0.0.1` view entitymessages as
select `echothree`.`entitymessages`.`emssg_entitymessageid`      AS `emssg_entitymessageid`,
       `echothree`.`entitymessages`.`emssg_eni_entityinstanceid` AS `emssg_eni_entityinstanceid`,
       `echothree`.`entitymessages`.`emssg_mssg_messageid`       AS `emssg_mssg_messageid`
from `echothree`.`entitymessages`
where (`echothree`.`entitymessages`.`emssg_thrutime` = 9223372036854775807);

