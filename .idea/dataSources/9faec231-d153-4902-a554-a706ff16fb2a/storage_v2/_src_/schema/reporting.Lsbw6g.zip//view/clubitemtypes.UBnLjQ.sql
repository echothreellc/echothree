create definer = echothree@`127.0.0.1` view clubitemtypes as
select `echothree`.`clubitemtypes`.`clbitmtyp_clubitemtypeid`   AS `clbitmtyp_clubitemtypeid`,
       `echothree`.`clubitemtypes`.`clbitmtyp_clubitemtypename` AS `clbitmtyp_clubitemtypename`,
       `echothree`.`clubitemtypes`.`clbitmtyp_isdefault`        AS `clbitmtyp_isdefault`,
       `echothree`.`clubitemtypes`.`clbitmtyp_sortorder`        AS `clbitmtyp_sortorder`
from `echothree`.`clubitemtypes`;

