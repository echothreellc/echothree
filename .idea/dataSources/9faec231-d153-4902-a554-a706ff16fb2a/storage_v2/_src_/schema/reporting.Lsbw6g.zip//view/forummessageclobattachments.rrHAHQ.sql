create definer = echothree@`127.0.0.1` view forummessageclobattachments as
select `echothree`.`forummessageclobattachments`.`frmmsgcatt_forummessageclobattachmentid`       AS `frmmsgcatt_forummessageclobattachmentid`,
       `echothree`.`forummessageclobattachments`.`frmmsgcatt_frmmsgatt_forummessageattachmentid` AS `frmmsgcatt_frmmsgatt_forummessageattachmentid`,
       `echothree`.`forummessageclobattachments`.`frmmsgcatt_clob`                               AS `frmmsgcatt_clob`
from `echothree`.`forummessageclobattachments`
where (`echothree`.`forummessageclobattachments`.`frmmsgcatt_thrutime` = 9223372036854775807);

