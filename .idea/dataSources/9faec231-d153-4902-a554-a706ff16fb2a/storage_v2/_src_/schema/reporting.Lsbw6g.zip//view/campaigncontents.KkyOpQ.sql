create definer = echothree@`127.0.0.1` view campaigncontents as
select `echothree`.`campaigncontents`.`cmpgncnt_campaigncontentid`           AS `cmpgncnt_campaigncontentid`,
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_campaigncontentname` AS `cmpgncntdt_campaigncontentname`,
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_valuesha1hash`       AS `cmpgncntdt_valuesha1hash`,
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_value`               AS `cmpgncntdt_value`,
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_isdefault`           AS `cmpgncntdt_isdefault`,
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_sortorder`           AS `cmpgncntdt_sortorder`
from `echothree`.`campaigncontents`
         join `echothree`.`campaigncontentdetails`
where (`echothree`.`campaigncontents`.`cmpgncnt_activedetailid` =
       `echothree`.`campaigncontentdetails`.`cmpgncntdt_campaigncontentdetailid`);

