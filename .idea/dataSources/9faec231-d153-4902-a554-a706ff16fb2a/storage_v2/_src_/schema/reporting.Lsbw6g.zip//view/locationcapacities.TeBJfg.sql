create definer = echothree@`127.0.0.1` view locationcapacities as
select `echothree`.`locationcapacities`.`loccap_locationcapacityid`       AS `loccap_locationcapacityid`,
       `echothree`.`locationcapacities`.`loccap_loc_locationid`           AS `loccap_loc_locationid`,
       `echothree`.`locationcapacities`.`loccap_uomt_unitofmeasuretypeid` AS `loccap_uomt_unitofmeasuretypeid`,
       `echothree`.`locationcapacities`.`loccap_capacity`                 AS `loccap_capacity`
from `echothree`.`locationcapacities`
where (`echothree`.`locationcapacities`.`loccap_thrutime` = 9223372036854775807);

