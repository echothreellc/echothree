create definer = echothree@`127.0.0.1` view entitybooleanattributes as
select `echothree`.`entitybooleanattributes`.`enbla_entitybooleanattributeid` AS `enbla_entitybooleanattributeid`,
       `echothree`.`entitybooleanattributes`.`enbla_ena_entityattributeid`    AS `enbla_ena_entityattributeid`,
       `echothree`.`entitybooleanattributes`.`enbla_eni_entityinstanceid`     AS `enbla_eni_entityinstanceid`,
       `echothree`.`entitybooleanattributes`.`enbla_booleanattribute`         AS `enbla_booleanattribute`
from `echothree`.`entitybooleanattributes`
where (`echothree`.`entitybooleanattributes`.`enbla_thrutime` = 9223372036854775807);

