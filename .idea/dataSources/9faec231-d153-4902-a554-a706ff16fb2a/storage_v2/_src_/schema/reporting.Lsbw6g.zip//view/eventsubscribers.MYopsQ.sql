create definer = echothree@`127.0.0.1` view eventsubscribers as
select `echothree`.`eventsubscribers`.`evs_eventsubscriberid`            AS `evs_eventsubscriberid`,
       `echothree`.`eventsubscriberdetails`.`evsdt_eventsubscribername`  AS `evsdt_eventsubscribername`,
       `echothree`.`eventsubscriberdetails`.`evsdt_eni_entityinstanceid` AS `evsdt_eni_entityinstanceid`,
       `echothree`.`eventsubscriberdetails`.`evsdt_description`          AS `evsdt_description`,
       `echothree`.`eventsubscriberdetails`.`evsdt_sortorder`            AS `evsdt_sortorder`
from `echothree`.`eventsubscribers`
         join `echothree`.`eventsubscriberdetails`
where (`echothree`.`eventsubscribers`.`evs_activedetailid` =
       `echothree`.`eventsubscriberdetails`.`evsdt_eventsubscriberdetailid`);

