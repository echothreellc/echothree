create definer = echothree@`127.0.0.1` view locationnameelements as
select `echothree`.`locationnameelements`.`locne_locationnameelementid`           AS `locne_locationnameelementid`,
       `echothree`.`locationnameelementdetails`.`locnedt_loctyp_locationtypeid`   AS `locnedt_loctyp_locationtypeid`,
       `echothree`.`locationnameelementdetails`.`locnedt_locationnameelementname` AS `locnedt_locationnameelementname`,
       `echothree`.`locationnameelementdetails`.`locnedt_offset`                  AS `locnedt_offset`,
       `echothree`.`locationnameelementdetails`.`locnedt_length`                  AS `locnedt_length`,
       `echothree`.`locationnameelementdetails`.`locnedt_validationpattern`       AS `locnedt_validationpattern`
from `echothree`.`locationnameelements`
         join `echothree`.`locationnameelementdetails`
where (`echothree`.`locationnameelements`.`locne_activedetailid` =
       `echothree`.`locationnameelementdetails`.`locnedt_locationnameelementdetailid`);

