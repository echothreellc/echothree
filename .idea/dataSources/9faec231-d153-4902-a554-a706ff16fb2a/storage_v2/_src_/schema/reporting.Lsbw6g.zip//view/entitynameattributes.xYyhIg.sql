create definer = echothree@`127.0.0.1` view entitynameattributes as
select `echothree`.`entitynameattributes`.`enna_entitynameattributeid` AS `enna_entitynameattributeid`,
       `echothree`.`entitynameattributes`.`enna_ena_entityattributeid` AS `enna_ena_entityattributeid`,
       `echothree`.`entitynameattributes`.`enna_nameattribute`         AS `enna_nameattribute`,
       `echothree`.`entitynameattributes`.`enna_eni_entityinstanceid`  AS `enna_eni_entityinstanceid`
from `echothree`.`entitynameattributes`
where (`echothree`.`entitynameattributes`.`enna_thrutime` = 9223372036854775807);

