create definer = echothree@`127.0.0.1` view geocodealiastypedescriptions as
select `echothree`.`geocodealiastypedescriptions`.`geoatd_geocodealiastypedescriptionid` AS `geoatd_geocodealiastypedescriptionid`,
       `echothree`.`geocodealiastypedescriptions`.`geoatd_geoat_geocodealiastypeid`      AS `geoatd_geoat_geocodealiastypeid`,
       `echothree`.`geocodealiastypedescriptions`.`geoatd_lang_languageid`               AS `geoatd_lang_languageid`,
       `echothree`.`geocodealiastypedescriptions`.`geoatd_description`                   AS `geoatd_description`
from `echothree`.`geocodealiastypedescriptions`
where (`echothree`.`geocodealiastypedescriptions`.`geoatd_thrutime` = 9223372036854775807);

