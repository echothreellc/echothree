create definer = echothree@`127.0.0.1` view carrierservices as
select `echothree`.`carrierservices`.`crrsrv_carrierserviceid`           AS `crrsrv_carrierserviceid`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_carrierpartyid`     AS `crrsrvdt_carrierpartyid`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_carrierservicename` AS `crrsrvdt_carrierservicename`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_geocodeselectorid`  AS `crrsrvdt_geocodeselectorid`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_itemselectorid`     AS `crrsrvdt_itemselectorid`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_isdefault`          AS `crrsrvdt_isdefault`,
       `echothree`.`carrierservicedetails`.`crrsrvdt_sortorder`          AS `crrsrvdt_sortorder`
from `echothree`.`carrierservices`
         join `echothree`.`carrierservicedetails`
where (`echothree`.`carrierservices`.`crrsrv_activedetailid` =
       `echothree`.`carrierservicedetails`.`crrsrvdt_carrierservicedetailid`);

