create definer = echothree@`127.0.0.1` view locationvolumes as
select `echothree`.`locationvolumes`.`locvol_locationvolumeid` AS `locvol_locationvolumeid`,
       `echothree`.`locationvolumes`.`locvol_loc_locationid`   AS `locvol_loc_locationid`,
       `echothree`.`locationvolumes`.`locvol_height`           AS `locvol_height`,
       `echothree`.`locationvolumes`.`locvol_width`            AS `locvol_width`,
       `echothree`.`locationvolumes`.`locvol_depth`            AS `locvol_depth`
from `echothree`.`locationvolumes`
where (`echothree`.`locationvolumes`.`locvol_thrutime` = 9223372036854775807);

