create definer = echothree@`127.0.0.1` view eventtypedescriptions as
select `echothree`.`eventtypedescriptions`.`evtyd_eventtypedescriptionid` AS `evtyd_eventtypedescriptionid`,
       `echothree`.`eventtypedescriptions`.`evtyd_evty_eventtypeid`       AS `evtyd_evty_eventtypeid`,
       `echothree`.`eventtypedescriptions`.`evtyd_lang_languageid`        AS `evtyd_lang_languageid`,
       `echothree`.`eventtypedescriptions`.`evtyd_description`            AS `evtyd_description`
from `echothree`.`eventtypedescriptions`;

