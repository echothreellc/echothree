create definer = echothree@`127.0.0.1` view financialaccountroles as
select `echothree`.`financialaccountroles`.`fnar_financialaccountroleid`             AS `fnar_financialaccountroleid`,
       `echothree`.`financialaccountroles`.`fnar_fina_financialaccountid`            AS `fnar_fina_financialaccountid`,
       `echothree`.`financialaccountroles`.`fnar_par_partyid`                        AS `fnar_par_partyid`,
       `echothree`.`financialaccountroles`.`fnar_finatyp_financialaccountroletypeid` AS `fnar_finatyp_financialaccountroletypeid`
from `echothree`.`financialaccountroles`
where (`echothree`.`financialaccountroles`.`fnar_thrutime` = 9223372036854775807);

