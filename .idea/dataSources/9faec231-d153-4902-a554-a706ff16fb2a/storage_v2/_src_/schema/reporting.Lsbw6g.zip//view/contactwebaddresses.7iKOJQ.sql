create definer = echothree@`127.0.0.1` view contactwebaddresses as
select `echothree`.`contactwebaddresses`.`ctwa_contactwebaddressid`     AS `ctwa_contactwebaddressid`,
       `echothree`.`contactwebaddresses`.`ctwa_cmch_contactmechanismid` AS `ctwa_cmch_contactmechanismid`,
       `echothree`.`contactwebaddresses`.`ctwa_url`                     AS `ctwa_url`
from `echothree`.`contactwebaddresses`
where (`echothree`.`contactwebaddresses`.`ctwa_thrutime` = 9223372036854775807);

