create definer = echothree@`127.0.0.1` view jobdescriptions as
select `echothree`.`jobdescriptions`.`jbd_jobdescriptionid` AS `jbd_jobdescriptionid`,
       `echothree`.`jobdescriptions`.`jbd_jb_jobid`         AS `jbd_jb_jobid`,
       `echothree`.`jobdescriptions`.`jbd_lang_languageid`  AS `jbd_lang_languageid`,
       `echothree`.`jobdescriptions`.`jbd_description`      AS `jbd_description`
from `echothree`.`jobdescriptions`
where (`echothree`.`jobdescriptions`.`jbd_thrutime` = 9223372036854775807);

