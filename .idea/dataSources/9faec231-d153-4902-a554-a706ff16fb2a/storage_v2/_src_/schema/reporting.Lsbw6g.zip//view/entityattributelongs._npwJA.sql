create definer = echothree@`127.0.0.1` view entityattributelongs as
select `echothree`.`entityattributelongs`.`enal_entityattributelongid` AS `enal_entityattributelongid`,
       `echothree`.`entityattributelongs`.`enal_ena_entityattributeid` AS `enal_ena_entityattributeid`,
       `echothree`.`entityattributelongs`.`enal_upperrangelongvalue`   AS `enal_upperrangelongvalue`,
       `echothree`.`entityattributelongs`.`enal_upperlimitlongvalue`   AS `enal_upperlimitlongvalue`,
       `echothree`.`entityattributelongs`.`enal_lowerlimitlongvalue`   AS `enal_lowerlimitlongvalue`,
       `echothree`.`entityattributelongs`.`enal_lowerrangelongvalue`   AS `enal_lowerrangelongvalue`
from `echothree`.`entityattributelongs`
where (`echothree`.`entityattributelongs`.`enal_thrutime` = 9223372036854775807);

