create definer = echothree@`127.0.0.1` view clubitemtypedescriptions as
select `echothree`.`clubitemtypedescriptions`.`clbitmtypd_clubitemtypedescriptionid` AS `clbitmtypd_clubitemtypedescriptionid`,
       `echothree`.`clubitemtypedescriptions`.`clbitmtypd_clbitmtyp_clubitemtypeid`  AS `clbitmtypd_clbitmtyp_clubitemtypeid`,
       `echothree`.`clubitemtypedescriptions`.`clbitmtypd_lang_languageid`           AS `clbitmtypd_lang_languageid`,
       `echothree`.`clubitemtypedescriptions`.`clbitmtypd_description`               AS `clbitmtypd_description`
from `echothree`.`clubitemtypedescriptions`;

