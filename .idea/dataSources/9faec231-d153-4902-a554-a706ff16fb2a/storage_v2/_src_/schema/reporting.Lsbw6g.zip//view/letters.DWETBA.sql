create definer = echothree@`127.0.0.1` view letters as
select `echothree`.`letters`.`lttr_letterid`                       AS `lttr_letterid`,
       `echothree`.`letterdetails`.`lttrdt_chntyp_chaintypeid`     AS `lttrdt_chntyp_chaintypeid`,
       `echothree`.`letterdetails`.`lttrdt_lettername`             AS `lttrdt_lettername`,
       `echothree`.`letterdetails`.`lttrdt_lttrsrc_lettersourceid` AS `lttrdt_lttrsrc_lettersourceid`,
       `echothree`.`letterdetails`.`lttrdt_clst_contactlistid`     AS `lttrdt_clst_contactlistid`,
       `echothree`.`letterdetails`.`lttrdt_isdefault`              AS `lttrdt_isdefault`,
       `echothree`.`letterdetails`.`lttrdt_sortorder`              AS `lttrdt_sortorder`
from `echothree`.`letters`
         join `echothree`.`letterdetails`
where (`echothree`.`letters`.`lttr_activedetailid` = `echothree`.`letterdetails`.`lttrdt_letterdetailid`);

