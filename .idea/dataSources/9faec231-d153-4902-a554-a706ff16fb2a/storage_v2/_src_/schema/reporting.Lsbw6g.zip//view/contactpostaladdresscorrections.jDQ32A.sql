create definer = echothree@`127.0.0.1` view contactpostaladdresscorrections as
select `echothree`.`contactpostaladdresscorrections`.`ctpac_contactpostaladdresscorrectionid` AS `ctpac_contactpostaladdresscorrectionid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_cmch_contactmechanismid`          AS `ctpac_cmch_contactmechanismid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_address1`                         AS `ctpac_address1`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_address2`                         AS `ctpac_address2`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_address3`                         AS `ctpac_address3`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_city`                             AS `ctpac_city`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_citygeocodeid`                    AS `ctpac_citygeocodeid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_countygeocodeid`                  AS `ctpac_countygeocodeid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_state`                            AS `ctpac_state`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_stategeocodeid`                   AS `ctpac_stategeocodeid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_postalcode`                       AS `ctpac_postalcode`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_postalcodegeocodeid`              AS `ctpac_postalcodegeocodeid`,
       `echothree`.`contactpostaladdresscorrections`.`ctpac_countrygeocodeid`                 AS `ctpac_countrygeocodeid`
from `echothree`.`contactpostaladdresscorrections`
where (`echothree`.`contactpostaladdresscorrections`.`ctpac_thrutime` = 9223372036854775807);

