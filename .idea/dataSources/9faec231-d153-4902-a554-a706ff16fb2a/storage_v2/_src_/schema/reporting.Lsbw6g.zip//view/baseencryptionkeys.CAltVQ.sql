create definer = echothree@`127.0.0.1` view baseencryptionkeys as
select `echothree`.`baseencryptionkeys`.`bek_baseencryptionkeyid`   AS `bek_baseencryptionkeyid`,
       `echothree`.`baseencryptionkeys`.`bek_baseencryptionkeyname` AS `bek_baseencryptionkeyname`,
       `echothree`.`baseencryptionkeys`.`bek_sha1hash`              AS `bek_sha1hash`
from `echothree`.`baseencryptionkeys`;

