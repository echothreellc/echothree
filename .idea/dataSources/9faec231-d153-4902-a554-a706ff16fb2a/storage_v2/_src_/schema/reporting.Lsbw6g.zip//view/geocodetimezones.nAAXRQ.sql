create definer = echothree@`127.0.0.1` view geocodetimezones as
select `echothree`.`geocodetimezones`.`geotz_geocodetimezoneid` AS `geotz_geocodetimezoneid`,
       `echothree`.`geocodetimezones`.`geotz_geo_geocodeid`     AS `geotz_geo_geocodeid`,
       `echothree`.`geocodetimezones`.`geotz_tz_timezoneid`     AS `geotz_tz_timezoneid`,
       `echothree`.`geocodetimezones`.`geotz_isdefault`         AS `geotz_isdefault`,
       `echothree`.`geocodetimezones`.`geotz_sortorder`         AS `geotz_sortorder`
from `echothree`.`geocodetimezones`
where (`echothree`.`geocodetimezones`.`geotz_thrutime` = 9223372036854775807);

