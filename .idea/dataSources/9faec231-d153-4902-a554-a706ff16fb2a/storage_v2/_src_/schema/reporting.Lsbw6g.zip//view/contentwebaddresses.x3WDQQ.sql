create definer = echothree@`127.0.0.1` view contentwebaddresses as
select `echothree`.`contentwebaddresses`.`cntwa_contentwebaddressid`             AS `cntwa_contentwebaddressid`,
       `echothree`.`contentwebaddressdetails`.`cntwadt_contentwebaddressname`    AS `cntwadt_contentwebaddressname`,
       `echothree`.`contentwebaddressdetails`.`cntwadt_cntc_contentcollectionid` AS `cntwadt_cntc_contentcollectionid`
from `echothree`.`contentwebaddresses`
         join `echothree`.`contentwebaddressdetails`
where (`echothree`.`contentwebaddresses`.`cntwa_activedetailid` =
       `echothree`.`contentwebaddressdetails`.`cntwadt_contentwebaddressdetailid`);

