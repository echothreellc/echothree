create definer = echothree@`127.0.0.1` view lottimetypes as
select `echothree`.`lottimetypes`.`lttimtyp_lottimetypeid`           AS `lttimtyp_lottimetypeid`,
       `echothree`.`lottimetypedetails`.`lttimtypdt_lottimetypename` AS `lttimtypdt_lottimetypename`,
       `echothree`.`lottimetypedetails`.`lttimtypdt_isdefault`       AS `lttimtypdt_isdefault`,
       `echothree`.`lottimetypedetails`.`lttimtypdt_sortorder`       AS `lttimtypdt_sortorder`
from `echothree`.`lottimetypes`
         join `echothree`.`lottimetypedetails`
where (`echothree`.`lottimetypes`.`lttimtyp_activedetailid` =
       `echothree`.`lottimetypedetails`.`lttimtypdt_lottimetypedetailid`);

