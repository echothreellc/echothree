create definer = echothree@`127.0.0.1` view forummessageattachmentdescriptions as
select `echothree`.`forummessageattachmentdescriptions`.`frmmsgattd_forummessageattachmentdescriptionid` AS `frmmsgattd_forummessageattachmentdescriptionid`,
       `echothree`.`forummessageattachmentdescriptions`.`frmmsgattd_frmmsgatt_forummessageattachmentid`  AS `frmmsgattd_frmmsgatt_forummessageattachmentid`,
       `echothree`.`forummessageattachmentdescriptions`.`frmmsgattd_lang_languageid`                     AS `frmmsgattd_lang_languageid`,
       `echothree`.`forummessageattachmentdescriptions`.`frmmsgattd_description`                         AS `frmmsgattd_description`
from `echothree`.`forummessageattachmentdescriptions`
where (`echothree`.`forummessageattachmentdescriptions`.`frmmsgattd_thrutime` = 9223372036854775807);

