create definer = echothree@`127.0.0.1` view filterkinds as
select `echothree`.`filterkinds`.`fltk_filterkindid`           AS `fltk_filterkindid`,
       `echothree`.`filterkinddetails`.`fltkdt_filterkindname` AS `fltkdt_filterkindname`,
       `echothree`.`filterkinddetails`.`fltkdt_isdefault`      AS `fltkdt_isdefault`,
       `echothree`.`filterkinddetails`.`fltkdt_sortorder`      AS `fltkdt_sortorder`
from `echothree`.`filterkinds`
         join `echothree`.`filterkinddetails`
where (`echothree`.`filterkinds`.`fltk_activedetailid` = `echothree`.`filterkinddetails`.`fltkdt_filterkinddetailid`);

