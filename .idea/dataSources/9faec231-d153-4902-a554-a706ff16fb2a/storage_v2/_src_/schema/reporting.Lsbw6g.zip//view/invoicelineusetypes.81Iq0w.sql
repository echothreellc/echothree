create definer = echothree@`127.0.0.1` view invoicelineusetypes as
select `echothree`.`invoicelineusetypes`.`invclut_invoicelineusetypeid`   AS `invclut_invoicelineusetypeid`,
       `echothree`.`invoicelineusetypes`.`invclut_invoicelineusetypename` AS `invclut_invoicelineusetypename`
from `echothree`.`invoicelineusetypes`;

