create definer = echothree@`127.0.0.1` view eventsubscribereventtypes as
select `echothree`.`eventsubscribereventtypes`.`evsevt_eventsubscribereventtypeid` AS `evsevt_eventsubscribereventtypeid`,
       `echothree`.`eventsubscribereventtypes`.`evsevt_evs_eventsubscriberid`      AS `evsevt_evs_eventsubscriberid`,
       `echothree`.`eventsubscribereventtypes`.`evsevt_evty_eventtypeid`           AS `evsevt_evty_eventtypeid`
from `echothree`.`eventsubscribereventtypes`
where (`echothree`.`eventsubscribereventtypes`.`evsevt_thrutime` = 9223372036854775807);

