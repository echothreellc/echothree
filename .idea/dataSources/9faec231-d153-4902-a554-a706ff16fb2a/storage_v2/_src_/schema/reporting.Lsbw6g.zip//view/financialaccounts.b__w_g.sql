create definer = echothree@`127.0.0.1` view financialaccounts as
select `echothree`.`financialaccounts`.`fina_financialaccountid`                    AS `fina_financialaccountid`,
       `echothree`.`financialaccountdetails`.`finadt_fnatyp_financialaccounttypeid` AS `finadt_fnatyp_financialaccounttypeid`,
       `echothree`.`financialaccountdetails`.`finadt_financialaccountname`          AS `finadt_financialaccountname`,
       `echothree`.`financialaccountdetails`.`finadt_cur_currencyid`                AS `finadt_cur_currencyid`,
       `echothree`.`financialaccountdetails`.`finadt_gla_glaccountid`               AS `finadt_gla_glaccountid`,
       `echothree`.`financialaccountdetails`.`finadt_reference`                     AS `finadt_reference`,
       `echothree`.`financialaccountdetails`.`finadt_description`                   AS `finadt_description`
from `echothree`.`financialaccounts`
         join `echothree`.`financialaccountdetails`
where (`echothree`.`financialaccounts`.`fina_activedetailid` =
       `echothree`.`financialaccountdetails`.`finadt_financialaccountdetailid`);

