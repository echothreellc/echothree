create definer = echothree@`127.0.0.1` view contactlisttypes as
select `echothree`.`contactlisttypes`.`clsttyp_contactlisttypeid`                  AS `clsttyp_contactlisttypeid`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_contactlisttypename`        AS `clsttypdt_contactlisttypename`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_confirmationrequestchainid` AS `clsttypdt_confirmationrequestchainid`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_subscribechainid`           AS `clsttypdt_subscribechainid`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_unsubscribechainid`         AS `clsttypdt_unsubscribechainid`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_usedforsolicitation`        AS `clsttypdt_usedforsolicitation`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_isdefault`                  AS `clsttypdt_isdefault`,
       `echothree`.`contactlisttypedetails`.`clsttypdt_sortorder`                  AS `clsttypdt_sortorder`
from `echothree`.`contactlisttypes`
         join `echothree`.`contactlisttypedetails`
where (`echothree`.`contactlisttypes`.`clsttyp_activedetailid` =
       `echothree`.`contactlisttypedetails`.`clsttypdt_contactlisttypedetailid`);

