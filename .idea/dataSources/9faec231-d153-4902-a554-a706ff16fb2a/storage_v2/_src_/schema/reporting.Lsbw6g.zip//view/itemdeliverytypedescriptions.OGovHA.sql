create definer = echothree@`127.0.0.1` view itemdeliverytypedescriptions as
select `echothree`.`itemdeliverytypedescriptions`.`idlvrtypd_itemdeliverytypedescriptionid` AS `idlvrtypd_itemdeliverytypedescriptionid`,
       `echothree`.`itemdeliverytypedescriptions`.`idlvrtypd_idlvrtyp_itemdeliverytypeid`   AS `idlvrtypd_idlvrtyp_itemdeliverytypeid`,
       `echothree`.`itemdeliverytypedescriptions`.`idlvrtypd_lang_languageid`               AS `idlvrtypd_lang_languageid`,
       `echothree`.`itemdeliverytypedescriptions`.`idlvrtypd_description`                   AS `idlvrtypd_description`
from `echothree`.`itemdeliverytypedescriptions`;

