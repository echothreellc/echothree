create definer = echothree@`127.0.0.1` view birthdayformats as
select `echothree`.`birthdayformats`.`bdyf_birthdayformatid`           AS `bdyf_birthdayformatid`,
       `echothree`.`birthdayformatdetails`.`bdyfdt_birthdayformatname` AS `bdyfdt_birthdayformatname`,
       `echothree`.`birthdayformatdetails`.`bdyfdt_isdefault`          AS `bdyfdt_isdefault`,
       `echothree`.`birthdayformatdetails`.`bdyfdt_sortorder`          AS `bdyfdt_sortorder`
from `echothree`.`birthdayformats`
         join `echothree`.`birthdayformatdetails`
where (`echothree`.`birthdayformats`.`bdyf_activedetailid` =
       `echothree`.`birthdayformatdetails`.`bdyfdt_birthdayformatdetailid`);

