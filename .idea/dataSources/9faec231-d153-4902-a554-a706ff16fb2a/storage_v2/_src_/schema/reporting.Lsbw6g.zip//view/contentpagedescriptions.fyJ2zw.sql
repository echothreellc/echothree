create definer = echothree@`127.0.0.1` view contentpagedescriptions as
select `echothree`.`contentpagedescriptions`.`cntpd_contentpagedescriptionid` AS `cntpd_contentpagedescriptionid`,
       `echothree`.`contentpagedescriptions`.`cntpd_cntp_contentpageid`       AS `cntpd_cntp_contentpageid`,
       `echothree`.`contentpagedescriptions`.`cntpd_lang_languageid`          AS `cntpd_lang_languageid`,
       `echothree`.`contentpagedescriptions`.`cntpd_description`              AS `cntpd_description`
from `echothree`.`contentpagedescriptions`
where (`echothree`.`contentpagedescriptions`.`cntpd_thrutime` = 9223372036854775807);

