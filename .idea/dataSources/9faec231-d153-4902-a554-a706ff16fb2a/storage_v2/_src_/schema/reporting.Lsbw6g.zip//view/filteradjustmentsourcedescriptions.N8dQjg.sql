create definer = echothree@`127.0.0.1` view filteradjustmentsourcedescriptions as
select `echothree`.`filteradjustmentsourcedescriptions`.`fltasd_filteradjustmentsourcedescriptionid` AS `fltasd_filteradjustmentsourcedescriptionid`,
       `echothree`.`filteradjustmentsourcedescriptions`.`fltasd_fltas_filteradjustmentsourceid`      AS `fltasd_fltas_filteradjustmentsourceid`,
       `echothree`.`filteradjustmentsourcedescriptions`.`fltasd_lang_languageid`                     AS `fltasd_lang_languageid`,
       `echothree`.`filteradjustmentsourcedescriptions`.`fltasd_description`                         AS `fltasd_description`
from `echothree`.`filteradjustmentsourcedescriptions`;

