create definer = echothree@`127.0.0.1` view contentcategories as
select `echothree`.`contentcategories`.`cntcg_contentcategoryid`                    AS `cntcg_contentcategoryid`,
       `echothree`.`contentcategorydetails`.`cntcgdt_cntct_contentcatalogid`        AS `cntcgdt_cntct_contentcatalogid`,
       `echothree`.`contentcategorydetails`.`cntcgdt_contentcategoryname`           AS `cntcgdt_contentcategoryname`,
       `echothree`.`contentcategorydetails`.`cntcgdt_parentcontentcategoryid`       AS `cntcgdt_parentcontentcategoryid`,
       `echothree`.`contentcategorydetails`.`cntcgdt_defaultofferuseid`             AS `cntcgdt_defaultofferuseid`,
       `echothree`.`contentcategorydetails`.`cntcgdt_contentcategoryitemselectorid` AS `cntcgdt_contentcategoryitemselectorid`,
       `echothree`.`contentcategorydetails`.`cntcgdt_isdefault`                     AS `cntcgdt_isdefault`,
       `echothree`.`contentcategorydetails`.`cntcgdt_sortorder`                     AS `cntcgdt_sortorder`
from `echothree`.`contentcategories`
         join `echothree`.`contentcategorydetails`
where (`echothree`.`contentcategories`.`cntcg_activedetailid` =
       `echothree`.`contentcategorydetails`.`cntcgdt_contentcategorydetailid`);

