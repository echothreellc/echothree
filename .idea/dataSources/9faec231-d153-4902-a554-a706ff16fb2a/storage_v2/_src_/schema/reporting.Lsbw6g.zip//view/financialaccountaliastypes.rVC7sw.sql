create definer = echothree@`127.0.0.1` view financialaccountaliastypes as
select `echothree`.`financialaccountaliastypes`.`finaat_financialaccountaliastypeid`           AS `finaat_financialaccountaliastypeid`,
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_fnatyp_financialaccounttypeid` AS `finaatdt_fnatyp_financialaccounttypeid`,
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_financialaccountaliastypename` AS `finaatdt_financialaccountaliastypename`,
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_validationpattern`             AS `finaatdt_validationpattern`,
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_isdefault`                     AS `finaatdt_isdefault`,
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_sortorder`                     AS `finaatdt_sortorder`
from `echothree`.`financialaccountaliastypes`
         join `echothree`.`financialaccountaliastypedetails`
where (`echothree`.`financialaccountaliastypes`.`finaat_activedetailid` =
       `echothree`.`financialaccountaliastypedetails`.`finaatdt_financialaccountaliastypedetailid`);

