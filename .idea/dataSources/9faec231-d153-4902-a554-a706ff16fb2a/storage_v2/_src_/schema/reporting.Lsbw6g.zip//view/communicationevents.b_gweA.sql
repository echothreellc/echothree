create definer = echothree@`127.0.0.1` view communicationevents as
select `echothree`.`communicationevents`.`cmmnev_communicationeventid`                         AS `cmmnev_communicationeventid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_communicationeventname`               AS `cmmnevdt_communicationeventname`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_cmmnevtyp_communicationeventtypeid`   AS `cmmnevdt_cmmnevtyp_communicationeventtypeid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_cmmnsrc_communicationsourceid`        AS `cmmnevdt_cmmnsrc_communicationsourceid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_cmmnevpr_communicationeventpurposeid` AS `cmmnevdt_cmmnevpr_communicationeventpurposeid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_originalcommunicationeventid`         AS `cmmnevdt_originalcommunicationeventid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_parentcommunicationeventid`           AS `cmmnevdt_parentcommunicationeventid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_pcm_partycontactmechanismid`          AS `cmmnevdt_pcm_partycontactmechanismid`,
       `echothree`.`communicationeventdetails`.`cmmnevdt_dcmnt_documentid`                     AS `cmmnevdt_dcmnt_documentid`
from `echothree`.`communicationevents`
         join `echothree`.`communicationeventdetails`
where (`echothree`.`communicationevents`.`cmmnev_activedetailid` =
       `echothree`.`communicationeventdetails`.`cmmnevdt_communicationeventdetailid`);

