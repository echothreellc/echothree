create definer = echothree@`127.0.0.1` view cacheentrydependencies as
select `echothree`.`cacheentrydependencies`.`centd_cacheentrydependencyid` AS `centd_cacheentrydependencyid`,
       `echothree`.`cacheentrydependencies`.`centd_cent_cacheentryid`      AS `centd_cent_cacheentryid`,
       `echothree`.`cacheentrydependencies`.`centd_eni_entityinstanceid`   AS `centd_eni_entityinstanceid`
from `echothree`.`cacheentrydependencies`;

