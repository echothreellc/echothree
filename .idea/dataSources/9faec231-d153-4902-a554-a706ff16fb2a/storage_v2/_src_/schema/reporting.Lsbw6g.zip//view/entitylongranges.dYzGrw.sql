create definer = echothree@`127.0.0.1` view entitylongranges as
select `echothree`.`entitylongranges`.`enlr_entitylongrangeid`             AS `enlr_entitylongrangeid`,
       `echothree`.`entitylongrangedetails`.`enlrdt_ena_entityattributeid` AS `enlrdt_ena_entityattributeid`,
       `echothree`.`entitylongrangedetails`.`enlrdt_entitylongrangename`   AS `enlrdt_entitylongrangename`,
       `echothree`.`entitylongrangedetails`.`enlrdt_minimumlongvalue`      AS `enlrdt_minimumlongvalue`,
       `echothree`.`entitylongrangedetails`.`enlrdt_maximumlongvalue`      AS `enlrdt_maximumlongvalue`,
       `echothree`.`entitylongrangedetails`.`enlrdt_isdefault`             AS `enlrdt_isdefault`,
       `echothree`.`entitylongrangedetails`.`enlrdt_sortorder`             AS `enlrdt_sortorder`
from `echothree`.`entitylongranges`
         join `echothree`.`entitylongrangedetails`
where (`echothree`.`entitylongranges`.`enlr_activedetailid` =
       `echothree`.`entitylongrangedetails`.`enlrdt_entitylongrangedetailid`);

