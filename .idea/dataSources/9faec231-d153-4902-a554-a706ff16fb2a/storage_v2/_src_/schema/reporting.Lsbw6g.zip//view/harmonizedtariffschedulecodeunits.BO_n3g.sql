create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodeunits as
select `echothree`.`harmonizedtariffschedulecodeunits`.`hztscunt_harmonizedtariffschedulecodeunitid`           AS `hztscunt_harmonizedtariffschedulecodeunitid`,
       `echothree`.`harmonizedtariffschedulecodeunitdetails`.`hztscuntdt_harmonizedtariffschedulecodeunitname` AS `hztscuntdt_harmonizedtariffschedulecodeunitname`,
       `echothree`.`harmonizedtariffschedulecodeunitdetails`.`hztscuntdt_isdefault`                            AS `hztscuntdt_isdefault`,
       `echothree`.`harmonizedtariffschedulecodeunitdetails`.`hztscuntdt_sortorder`                            AS `hztscuntdt_sortorder`
from `echothree`.`harmonizedtariffschedulecodeunits`
         join `echothree`.`harmonizedtariffschedulecodeunitdetails`
where (`echothree`.`harmonizedtariffschedulecodeunits`.`hztscunt_activedetailid` =
       `echothree`.`harmonizedtariffschedulecodeunitdetails`.`hztscuntdt_harmonizedtariffschedulecodeunitdetailid`);

