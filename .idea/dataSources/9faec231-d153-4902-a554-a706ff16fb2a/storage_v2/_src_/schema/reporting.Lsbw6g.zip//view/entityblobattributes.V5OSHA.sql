create definer = echothree@`127.0.0.1` view entityblobattributes as
select `echothree`.`entityblobattributes`.`enba_entityblobattributeid` AS `enba_entityblobattributeid`,
       `echothree`.`entityblobattributes`.`enba_ena_entityattributeid` AS `enba_ena_entityattributeid`,
       `echothree`.`entityblobattributes`.`enba_eni_entityinstanceid`  AS `enba_eni_entityinstanceid`,
       `echothree`.`entityblobattributes`.`enba_lang_languageid`       AS `enba_lang_languageid`,
       `echothree`.`entityblobattributes`.`enba_blobattribute`         AS `enba_blobattribute`,
       `echothree`.`entityblobattributes`.`enba_mtyp_mimetypeid`       AS `enba_mtyp_mimetypeid`
from `echothree`.`entityblobattributes`
where (`echothree`.`entityblobattributes`.`enba_thrutime` = 9223372036854775807);

