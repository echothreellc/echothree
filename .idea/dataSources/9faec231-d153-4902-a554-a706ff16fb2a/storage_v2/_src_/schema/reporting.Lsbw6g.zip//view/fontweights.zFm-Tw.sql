create definer = echothree@`127.0.0.1` view fontweights as
select `echothree`.`fontweights`.`fntwght_fontweightid`           AS `fntwght_fontweightid`,
       `echothree`.`fontweightdetails`.`fntwghtdt_fontweightname` AS `fntwghtdt_fontweightname`,
       `echothree`.`fontweightdetails`.`fntwghtdt_isdefault`      AS `fntwghtdt_isdefault`,
       `echothree`.`fontweightdetails`.`fntwghtdt_sortorder`      AS `fntwghtdt_sortorder`
from `echothree`.`fontweights`
         join `echothree`.`fontweightdetails`
where (`echothree`.`fontweights`.`fntwght_activedetailid` =
       `echothree`.`fontweightdetails`.`fntwghtdt_fontweightdetailid`);

