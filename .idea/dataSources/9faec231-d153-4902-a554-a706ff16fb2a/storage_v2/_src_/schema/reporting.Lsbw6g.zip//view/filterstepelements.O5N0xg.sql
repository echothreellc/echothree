create definer = echothree@`127.0.0.1` view filterstepelements as
select `echothree`.`filterstepelements`.`fltstpe_filterstepelementid`             AS `fltstpe_filterstepelementid`,
       `echothree`.`filterstepelementdetails`.`fltstpedt_fltstp_filterstepid`     AS `fltstpedt_fltstp_filterstepid`,
       `echothree`.`filterstepelementdetails`.`fltstpedt_filterstepelementname`   AS `fltstpedt_filterstepelementname`,
       `echothree`.`filterstepelementdetails`.`fltstpedt_filteritemselectorid`    AS `fltstpedt_filteritemselectorid`,
       `echothree`.`filterstepelementdetails`.`fltstpedt_flta_filteradjustmentid` AS `fltstpedt_flta_filteradjustmentid`
from `echothree`.`filterstepelements`
         join `echothree`.`filterstepelementdetails`
where (`echothree`.`filterstepelements`.`fltstpe_activedetailid` =
       `echothree`.`filterstepelementdetails`.`fltstpedt_filterstepelementdetailid`);

