create definer = echothree@`127.0.0.1` view contentcollections as
select `echothree`.`contentcollections`.`cntc_contentcollectionid`           AS `cntc_contentcollectionid`,
       `echothree`.`contentcollectiondetails`.`cntcdt_contentcollectionname` AS `cntcdt_contentcollectionname`,
       `echothree`.`contentcollectiondetails`.`cntcdt_defaultofferuseid`     AS `cntcdt_defaultofferuseid`
from `echothree`.`contentcollections`
         join `echothree`.`contentcollectiondetails`
where (`echothree`.`contentcollections`.`cntc_activedetailid` =
       `echothree`.`contentcollectiondetails`.`cntcdt_contentcollectiondetailid`);

