create definer = echothree@`127.0.0.1` view itemimagedescriptiontypes as
select `echothree`.`itemimagedescriptiontypes`.`iimgdt_itemimagedescriptiontypeid` AS `iimgdt_itemimagedescriptiontypeid`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_idt_itemdescriptiontypeid`  AS `iimgdt_idt_itemdescriptiontypeid`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_minimumheight`              AS `iimgdt_minimumheight`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_minimumwidth`               AS `iimgdt_minimumwidth`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_maximumheight`              AS `iimgdt_maximumheight`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_maximumwidth`               AS `iimgdt_maximumwidth`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_preferredheight`            AS `iimgdt_preferredheight`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_preferredwidth`             AS `iimgdt_preferredwidth`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_preferredmimetypeid`        AS `iimgdt_preferredmimetypeid`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_quality`                    AS `iimgdt_quality`,
       `echothree`.`itemimagedescriptiontypes`.`iimgdt_scalefromparent`            AS `iimgdt_scalefromparent`
from `echothree`.`itemimagedescriptiontypes`
where (`echothree`.`itemimagedescriptiontypes`.`iimgdt_thrutime` = 9223372036854775807);

