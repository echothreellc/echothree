create definer = echothree@`127.0.0.1` view languagedescriptions as
select `echothree`.`languagedescriptions`.`langd_languagedescriptionid` AS `langd_languagedescriptionid`,
       `echothree`.`languagedescriptions`.`langd_lang_languageid`       AS `langd_lang_languageid`,
       `echothree`.`languagedescriptions`.`langd_descriptionlanguageid` AS `langd_descriptionlanguageid`,
       `echothree`.`languagedescriptions`.`langd_description`           AS `langd_description`
from `echothree`.`languagedescriptions`;

