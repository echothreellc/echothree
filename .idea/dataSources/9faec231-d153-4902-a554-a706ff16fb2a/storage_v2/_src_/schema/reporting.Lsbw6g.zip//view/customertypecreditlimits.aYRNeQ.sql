create definer = echothree@`127.0.0.1` view customertypecreditlimits as
select `echothree`.`customertypecreditlimits`.`cutyclim_customertypecreditlimitid` AS `cutyclim_customertypecreditlimitid`,
       `echothree`.`customertypecreditlimits`.`cutyclim_cuty_customertypeid`       AS `cutyclim_cuty_customertypeid`,
       `echothree`.`customertypecreditlimits`.`cutyclim_cur_currencyid`            AS `cutyclim_cur_currencyid`,
       `echothree`.`customertypecreditlimits`.`cutyclim_creditlimit`               AS `cutyclim_creditlimit`,
       `echothree`.`customertypecreditlimits`.`cutyclim_potentialcreditlimit`      AS `cutyclim_potentialcreditlimit`
from `echothree`.`customertypecreditlimits`
where (`echothree`.`customertypecreditlimits`.`cutyclim_thrutime` = 9223372036854775807);

