create definer = echothree@`127.0.0.1` view contactmechanismtypes as
select `echothree`.`contactmechanismtypes`.`cmt_contactmechanismtypeid`       AS `cmt_contactmechanismtypeid`,
       `echothree`.`contactmechanismtypes`.`cmt_contactmechanismtypename`     AS `cmt_contactmechanismtypename`,
       `echothree`.`contactmechanismtypes`.`cmt_parentcontactmechanismtypeid` AS `cmt_parentcontactmechanismtypeid`,
       `echothree`.`contactmechanismtypes`.`cmt_isdefault`                    AS `cmt_isdefault`,
       `echothree`.`contactmechanismtypes`.`cmt_sortorder`                    AS `cmt_sortorder`
from `echothree`.`contactmechanismtypes`;

