create definer = echothree@`127.0.0.1` view entityintegerattributes as
select `echothree`.`entityintegerattributes`.`enia_entityintegerattributeid` AS `enia_entityintegerattributeid`,
       `echothree`.`entityintegerattributes`.`enia_ena_entityattributeid`    AS `enia_ena_entityattributeid`,
       `echothree`.`entityintegerattributes`.`enia_eni_entityinstanceid`     AS `enia_eni_entityinstanceid`,
       `echothree`.`entityintegerattributes`.`enia_integerattribute`         AS `enia_integerattribute`
from `echothree`.`entityintegerattributes`
where (`echothree`.`entityintegerattributes`.`enia_thrutime` = 9223372036854775807);

