create definer = echothree@`127.0.0.1` view forumtypemessagetypes as
select `echothree`.`forumtypemessagetypes`.`frmtypmsgtyp_forumtypemessagetypeid`       AS `frmtypmsgtyp_forumtypemessagetypeid`,
       `echothree`.`forumtypemessagetypes`.`frmtypmsgtyp_frmtyp_forumtypeid`           AS `frmtypmsgtyp_frmtyp_forumtypeid`,
       `echothree`.`forumtypemessagetypes`.`frmtypmsgtyp_frmmsgtyp_forummessagetypeid` AS `frmtypmsgtyp_frmmsgtyp_forummessagetypeid`,
       `echothree`.`forumtypemessagetypes`.`frmtypmsgtyp_isdefault`                    AS `frmtypmsgtyp_isdefault`,
       `echothree`.`forumtypemessagetypes`.`frmtypmsgtyp_sortorder`                    AS `frmtypmsgtyp_sortorder`
from `echothree`.`forumtypemessagetypes`;

