create definer = echothree@`127.0.0.1` view geocodetypedescriptions as
select `echothree`.`geocodetypedescriptions`.`geotd_geocodetypedescriptionid` AS `geotd_geocodetypedescriptionid`,
       `echothree`.`geocodetypedescriptions`.`geotd_geot_geocodetypeid`       AS `geotd_geot_geocodetypeid`,
       `echothree`.`geocodetypedescriptions`.`geotd_lang_languageid`          AS `geotd_lang_languageid`,
       `echothree`.`geocodetypedescriptions`.`geotd_description`              AS `geotd_description`
from `echothree`.`geocodetypedescriptions`
where (`echothree`.`geocodetypedescriptions`.`geotd_thrutime` = 9223372036854775807);

