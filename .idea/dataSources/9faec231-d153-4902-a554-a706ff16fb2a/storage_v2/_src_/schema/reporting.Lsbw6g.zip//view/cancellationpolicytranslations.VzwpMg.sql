create definer = echothree@`127.0.0.1` view cancellationpolicytranslations as
select `echothree`.`cancellationpolicytranslations`.`cnclplcytr_cancellationpolicytranslationid` AS `cnclplcytr_cancellationpolicytranslationid`,
       `echothree`.`cancellationpolicytranslations`.`cnclplcytr_cnclplcy_cancellationpolicyid`   AS `cnclplcytr_cnclplcy_cancellationpolicyid`,
       `echothree`.`cancellationpolicytranslations`.`cnclplcytr_lang_languageid`                 AS `cnclplcytr_lang_languageid`,
       `echothree`.`cancellationpolicytranslations`.`cnclplcytr_description`                     AS `cnclplcytr_description`,
       `echothree`.`cancellationpolicytranslations`.`cnclplcytr_policymimetypeid`                AS `cnclplcytr_policymimetypeid`,
       `echothree`.`cancellationpolicytranslations`.`cnclplcytr_policy`                          AS `cnclplcytr_policy`
from `echothree`.`cancellationpolicytranslations`
where (`echothree`.`cancellationpolicytranslations`.`cnclplcytr_thrutime` = 9223372036854775807);

