create definer = echothree@`127.0.0.1` view appearancetextdecorations as
select `echothree`.`appearancetextdecorations`.`apprntxtdcrtn_appearancetextdecorationid` AS `apprntxtdcrtn_appearancetextdecorationid`,
       `echothree`.`appearancetextdecorations`.`apprntxtdcrtn_apprnc_appearanceid`        AS `apprntxtdcrtn_apprnc_appearanceid`,
       `echothree`.`appearancetextdecorations`.`apprntxtdcrtn_txtdcrtn_textdecorationid`  AS `apprntxtdcrtn_txtdcrtn_textdecorationid`
from `echothree`.`appearancetextdecorations`
where (`echothree`.`appearancetextdecorations`.`apprntxtdcrtn_thrutime` = 9223372036854775807);

