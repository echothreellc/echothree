create definer = echothree@`127.0.0.1` view contentwebaddressservers as
select `echothree`.`contentwebaddressservers`.`cntwaserv_contentwebaddressserverid` AS `cntwaserv_contentwebaddressserverid`,
       `echothree`.`contentwebaddressservers`.`cntwaserv_cntwa_contentwebaddressid` AS `cntwaserv_cntwa_contentwebaddressid`,
       `echothree`.`contentwebaddressservers`.`cntwaserv_serv_serverid`             AS `cntwaserv_serv_serverid`
from `echothree`.`contentwebaddressservers`
where (`echothree`.`contentwebaddressservers`.`cntwaserv_thrutime` = 9223372036854775807);

