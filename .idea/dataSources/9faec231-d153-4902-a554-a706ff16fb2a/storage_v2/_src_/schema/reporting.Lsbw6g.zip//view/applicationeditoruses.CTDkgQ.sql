create definer = echothree@`127.0.0.1` view applicationeditoruses as
select `echothree`.`applicationeditoruses`.`appledtruse_applicationeditoruseid`             AS `appledtruse_applicationeditoruseid`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_appl_applicationid`         AS `appledtrusedt_appl_applicationid`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_applicationeditorusename`   AS `appledtrusedt_applicationeditorusename`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_defaultapplicationeditorid` AS `appledtrusedt_defaultapplicationeditorid`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_defaultheight`              AS `appledtrusedt_defaultheight`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_defaultwidth`               AS `appledtrusedt_defaultwidth`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_isdefault`                  AS `appledtrusedt_isdefault`,
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_sortorder`                  AS `appledtrusedt_sortorder`
from `echothree`.`applicationeditoruses`
         join `echothree`.`applicationeditorusedetails`
where (`echothree`.`applicationeditoruses`.`appledtruse_activedetailid` =
       `echothree`.`applicationeditorusedetails`.`appledtrusedt_applicationeditorusedetailid`);

