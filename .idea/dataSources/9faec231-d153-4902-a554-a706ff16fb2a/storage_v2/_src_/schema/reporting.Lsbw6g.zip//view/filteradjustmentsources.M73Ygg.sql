create definer = echothree@`127.0.0.1` view filteradjustmentsources as
select `echothree`.`filteradjustmentsources`.`fltas_filteradjustmentsourceid`   AS `fltas_filteradjustmentsourceid`,
       `echothree`.`filteradjustmentsources`.`fltas_filteradjustmentsourcename` AS `fltas_filteradjustmentsourcename`,
       `echothree`.`filteradjustmentsources`.`fltas_allowedforinitialamount`    AS `fltas_allowedforinitialamount`,
       `echothree`.`filteradjustmentsources`.`fltas_isdefault`                  AS `fltas_isdefault`,
       `echothree`.`filteradjustmentsources`.`fltas_sortorder`                  AS `fltas_sortorder`
from `echothree`.`filteradjustmentsources`;

