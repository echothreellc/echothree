create definer = echothree@`127.0.0.1` view documenttypeusagetypedescriptions as
select `echothree`.`documenttypeusagetypedescriptions`.`dcmnttyputypd_documenttypeusagetypedescriptionid`   AS `dcmnttyputypd_documenttypeusagetypedescriptionid`,
       `echothree`.`documenttypeusagetypedescriptions`.`dcmnttyputypd_dcmnttyputyp_documenttypeusagetypeid` AS `dcmnttyputypd_dcmnttyputyp_documenttypeusagetypeid`,
       `echothree`.`documenttypeusagetypedescriptions`.`dcmnttyputypd_lang_languageid`                      AS `dcmnttyputypd_lang_languageid`,
       `echothree`.`documenttypeusagetypedescriptions`.`dcmnttyputypd_description`                          AS `dcmnttyputypd_description`
from `echothree`.`documenttypeusagetypedescriptions`
where (`echothree`.`documenttypeusagetypedescriptions`.`dcmnttyputypd_thrutime` = 9223372036854775807);

