create definer = echothree@`127.0.0.1` view clubs as
select `echothree`.`clubs`.`clb_clubid`                               AS `clb_clubid`,
       `echothree`.`clubdetails`.`clbdt_clubname`                     AS `clbdt_clubname`,
       `echothree`.`clubdetails`.`clbdt_subscrtyp_subscriptiontypeid` AS `clbdt_subscrtyp_subscriptiontypeid`,
       `echothree`.`clubdetails`.`clbdt_clubpricefilterid`            AS `clbdt_clubpricefilterid`,
       `echothree`.`clubdetails`.`clbdt_cur_currencyid`               AS `clbdt_cur_currencyid`,
       `echothree`.`clubdetails`.`clbdt_isdefault`                    AS `clbdt_isdefault`,
       `echothree`.`clubdetails`.`clbdt_sortorder`                    AS `clbdt_sortorder`
from `echothree`.`clubs`
         join `echothree`.`clubdetails`
where (`echothree`.`clubs`.`clb_activedetailid` = `echothree`.`clubdetails`.`clbdt_clubdetailid`);

