create definer = echothree@`127.0.0.1` view cachedsearchindexfields as
select `echothree`.`cachedsearchindexfields`.`csrchidxfld_cachedsearchindexfieldid` AS `csrchidxfld_cachedsearchindexfieldid`,
       `echothree`.`cachedsearchindexfields`.`csrchidxfld_csrch_cachedsearchid`     AS `csrchidxfld_csrch_cachedsearchid`,
       `echothree`.`cachedsearchindexfields`.`csrchidxfld_idxfld_indexfieldid`      AS `csrchidxfld_idxfld_indexfieldid`
from `echothree`.`cachedsearchindexfields`
where (`echothree`.`cachedsearchindexfields`.`csrchidxfld_thrutime` = 9223372036854775807);

