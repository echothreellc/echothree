create definer = echothree@`127.0.0.1` view invoicealiases as
select `echothree`.`invoicealiases`.`invcal_invoicealiasid`               AS `invcal_invoicealiasid`,
       `echothree`.`invoicealiases`.`invcal_invc_invoiceid`               AS `invcal_invc_invoiceid`,
       `echothree`.`invoicealiases`.`invcal_invcaltyp_invoicealiastypeid` AS `invcal_invcaltyp_invoicealiastypeid`,
       `echothree`.`invoicealiases`.`invcal_alias`                        AS `invcal_alias`
from `echothree`.`invoicealiases`
where (`echothree`.`invoicealiases`.`invcal_thrutime` = 9223372036854775807);

