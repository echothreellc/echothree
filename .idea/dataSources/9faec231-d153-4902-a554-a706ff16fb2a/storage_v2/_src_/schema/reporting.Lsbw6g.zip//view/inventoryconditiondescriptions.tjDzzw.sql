create definer = echothree@`127.0.0.1` view inventoryconditiondescriptions as
select `echothree`.`inventoryconditiondescriptions`.`invcond_inventoryconditiondescriptionid` AS `invcond_inventoryconditiondescriptionid`,
       `echothree`.`inventoryconditiondescriptions`.`invcond_invcon_inventoryconditionid`     AS `invcond_invcon_inventoryconditionid`,
       `echothree`.`inventoryconditiondescriptions`.`invcond_lang_languageid`                 AS `invcond_lang_languageid`,
       `echothree`.`inventoryconditiondescriptions`.`invcond_description`                     AS `invcond_description`
from `echothree`.`inventoryconditiondescriptions`
where (`echothree`.`inventoryconditiondescriptions`.`invcond_thrutime` = 9223372036854775807);

