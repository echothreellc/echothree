create definer = echothree@`127.0.0.1` view contentpageareastrings as
select `echothree`.`contentpageareastrings`.`cntpas_contentpageareastringid`        AS `cntpas_contentpageareastringid`,
       `echothree`.`contentpageareastrings`.`cntpas_cntpad_contentpageareadetailid` AS `cntpas_cntpad_contentpageareadetailid`,
       `echothree`.`contentpageareastrings`.`cntpas_string`                         AS `cntpas_string`
from `echothree`.`contentpageareastrings`;

