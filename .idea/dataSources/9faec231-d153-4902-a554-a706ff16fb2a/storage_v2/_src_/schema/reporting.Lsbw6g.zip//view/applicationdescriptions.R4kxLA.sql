create definer = echothree@`127.0.0.1` view applicationdescriptions as
select `echothree`.`applicationdescriptions`.`appld_applicationdescriptionid` AS `appld_applicationdescriptionid`,
       `echothree`.`applicationdescriptions`.`appld_appl_applicationid`       AS `appld_appl_applicationid`,
       `echothree`.`applicationdescriptions`.`appld_lang_languageid`          AS `appld_lang_languageid`,
       `echothree`.`applicationdescriptions`.`appld_description`              AS `appld_description`
from `echothree`.`applicationdescriptions`
where (`echothree`.`applicationdescriptions`.`appld_thrutime` = 9223372036854775807);

