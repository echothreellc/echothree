create definer = echothree@`127.0.0.1` view chainactionsets as
select `echothree`.`chainactionsets`.`chnactst_chainactionsetid`           AS `chnactst_chainactionsetid`,
       `echothree`.`chainactionsetdetails`.`chnactstdt_chn_chainid`        AS `chnactstdt_chn_chainid`,
       `echothree`.`chainactionsetdetails`.`chnactstdt_chainactionsetname` AS `chnactstdt_chainactionsetname`,
       `echothree`.`chainactionsetdetails`.`chnactstdt_isdefault`          AS `chnactstdt_isdefault`,
       `echothree`.`chainactionsetdetails`.`chnactstdt_sortorder`          AS `chnactstdt_sortorder`
from `echothree`.`chainactionsets`
         join `echothree`.`chainactionsetdetails`
where (`echothree`.`chainactionsets`.`chnactst_activedetailid` =
       `echothree`.`chainactionsetdetails`.`chnactstdt_chainactionsetdetailid`);

