create definer = echothree@`127.0.0.1` view entityintegerrangedescriptions as
select `echothree`.`entityintegerrangedescriptions`.`enird_entityintegerrangedescriptionid` AS `enird_entityintegerrangedescriptionid`,
       `echothree`.`entityintegerrangedescriptions`.`enird_enir_entityintegerrangeid`       AS `enird_enir_entityintegerrangeid`,
       `echothree`.`entityintegerrangedescriptions`.`enird_lang_languageid`                 AS `enird_lang_languageid`,
       `echothree`.`entityintegerrangedescriptions`.`enird_description`                     AS `enird_description`
from `echothree`.`entityintegerrangedescriptions`
where (`echothree`.`entityintegerrangedescriptions`.`enird_thrutime` = 9223372036854775807);

