create definer = echothree@`127.0.0.1` view customertypes as
select `echothree`.`customertypes`.`cuty_customertypeid`                            AS `cuty_customertypeid`,
       `echothree`.`customertypedetails`.`cutydt_customertypename`                  AS `cutydt_customertypename`,
       `echothree`.`customertypedetails`.`cutydt_customersequenceid`                AS `cutydt_customersequenceid`,
       `echothree`.`customertypedetails`.`cutydt_defaultofferuseid`                 AS `cutydt_defaultofferuseid`,
       `echothree`.`customertypedetails`.`cutydt_defaulttermid`                     AS `cutydt_defaulttermid`,
       `echothree`.`customertypedetails`.`cutydt_defaultfreeonboardid`              AS `cutydt_defaultfreeonboardid`,
       `echothree`.`customertypedetails`.`cutydt_defaultcancellationpolicyid`       AS `cutydt_defaultcancellationpolicyid`,
       `echothree`.`customertypedetails`.`cutydt_defaultreturnpolicyid`             AS `cutydt_defaultreturnpolicyid`,
       `echothree`.`customertypedetails`.`cutydt_defaultcustomerstatusid`           AS `cutydt_defaultcustomerstatusid`,
       `echothree`.`customertypedetails`.`cutydt_defaultcustomercreditstatusid`     AS `cutydt_defaultcustomercreditstatusid`,
       `echothree`.`customertypedetails`.`cutydt_defaultarglaccountid`              AS `cutydt_defaultarglaccountid`,
       `echothree`.`customertypedetails`.`cutydt_defaultholduntilcomplete`          AS `cutydt_defaultholduntilcomplete`,
       `echothree`.`customertypedetails`.`cutydt_defaultallowbackorders`            AS `cutydt_defaultallowbackorders`,
       `echothree`.`customertypedetails`.`cutydt_defaultallowsubstitutions`         AS `cutydt_defaultallowsubstitutions`,
       `echothree`.`customertypedetails`.`cutydt_defaultallowcombiningshipments`    AS `cutydt_defaultallowcombiningshipments`,
       `echothree`.`customertypedetails`.`cutydt_defaultrequirereference`           AS `cutydt_defaultrequirereference`,
       `echothree`.`customertypedetails`.`cutydt_defaultallowreferenceduplicates`   AS `cutydt_defaultallowreferenceduplicates`,
       `echothree`.`customertypedetails`.`cutydt_defaultreferencevalidationpattern` AS `cutydt_defaultreferencevalidationpattern`,
       `echothree`.`customertypedetails`.`cutydt_defaulttaxable`                    AS `cutydt_defaulttaxable`,
       `echothree`.`customertypedetails`.`cutydt_allocpr_allocationpriorityid`      AS `cutydt_allocpr_allocationpriorityid`,
       `echothree`.`customertypedetails`.`cutydt_isdefault`                         AS `cutydt_isdefault`,
       `echothree`.`customertypedetails`.`cutydt_sortorder`                         AS `cutydt_sortorder`
from `echothree`.`customertypes`
         join `echothree`.`customertypedetails`
where (`echothree`.`customertypes`.`cuty_activedetailid` =
       `echothree`.`customertypedetails`.`cutydt_customertypedetailid`);

