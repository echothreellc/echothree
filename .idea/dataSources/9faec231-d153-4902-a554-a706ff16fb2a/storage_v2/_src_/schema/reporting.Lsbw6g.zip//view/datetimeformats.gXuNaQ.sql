create definer = echothree@`127.0.0.1` view datetimeformats as
select `echothree`.`datetimeformats`.`dtf_datetimeformatid`                    AS `dtf_datetimeformatid`,
       `echothree`.`datetimeformatdetails`.`dtfdt_datetimeformatname`          AS `dtfdt_datetimeformatname`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javashortdateformat`         AS `dtfdt_javashortdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javaabbrevdateformat`        AS `dtfdt_javaabbrevdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javaabbrevdateformatweekday` AS `dtfdt_javaabbrevdateformatweekday`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javalongdateformat`          AS `dtfdt_javalongdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javalongdateformatweekday`   AS `dtfdt_javalongdateformatweekday`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javatimeformat`              AS `dtfdt_javatimeformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_javatimeformatseconds`       AS `dtfdt_javatimeformatseconds`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixshortdateformat`         AS `dtfdt_unixshortdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixabbrevdateformat`        AS `dtfdt_unixabbrevdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixabbrevdateformatweekday` AS `dtfdt_unixabbrevdateformatweekday`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixlongdateformat`          AS `dtfdt_unixlongdateformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixlongdateformatweekday`   AS `dtfdt_unixlongdateformatweekday`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixtimeformat`              AS `dtfdt_unixtimeformat`,
       `echothree`.`datetimeformatdetails`.`dtfdt_unixtimeformatseconds`       AS `dtfdt_unixtimeformatseconds`,
       `echothree`.`datetimeformatdetails`.`dtfdt_shortdateseparator`          AS `dtfdt_shortdateseparator`,
       `echothree`.`datetimeformatdetails`.`dtfdt_timeseparator`               AS `dtfdt_timeseparator`,
       `echothree`.`datetimeformatdetails`.`dtfdt_isdefault`                   AS `dtfdt_isdefault`,
       `echothree`.`datetimeformatdetails`.`dtfdt_sortorder`                   AS `dtfdt_sortorder`
from `echothree`.`datetimeformats`
         join `echothree`.`datetimeformatdetails`
where (`echothree`.`datetimeformats`.`dtf_activedetailid` =
       `echothree`.`datetimeformatdetails`.`dtfdt_datetimeformatdetailid`);

