create definer = echothree@`127.0.0.1` view glresourcetypedescriptions as
select `echothree`.`glresourcetypedescriptions`.`glrtypd_glresourcetypedescriptionid` AS `glrtypd_glresourcetypedescriptionid`,
       `echothree`.`glresourcetypedescriptions`.`glrtypd_glrtyp_glresourcetypeid`     AS `glrtypd_glrtyp_glresourcetypeid`,
       `echothree`.`glresourcetypedescriptions`.`glrtypd_lang_languageid`             AS `glrtypd_lang_languageid`,
       `echothree`.`glresourcetypedescriptions`.`glrtypd_description`                 AS `glrtypd_description`
from `echothree`.`glresourcetypedescriptions`
where (`echothree`.`glresourcetypedescriptions`.`glrtypd_thrutime` = 9223372036854775807);

