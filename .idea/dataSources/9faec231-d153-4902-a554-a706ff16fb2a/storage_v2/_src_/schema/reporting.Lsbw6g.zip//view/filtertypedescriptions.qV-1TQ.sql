create definer = echothree@`127.0.0.1` view filtertypedescriptions as
select `echothree`.`filtertypedescriptions`.`flttypd_filtertypedescriptionid` AS `flttypd_filtertypedescriptionid`,
       `echothree`.`filtertypedescriptions`.`flttypd_flttyp_filtertypeid`     AS `flttypd_flttyp_filtertypeid`,
       `echothree`.`filtertypedescriptions`.`flttypd_lang_languageid`         AS `flttypd_lang_languageid`,
       `echothree`.`filtertypedescriptions`.`flttypd_description`             AS `flttypd_description`
from `echothree`.`filtertypedescriptions`
where (`echothree`.`filtertypedescriptions`.`flttypd_thrutime` = 9223372036854775807);

