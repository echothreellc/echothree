create definer = echothree@`127.0.0.1` view colordescriptions as
select `echothree`.`colordescriptions`.`clrd_colordescriptionid` AS `clrd_colordescriptionid`,
       `echothree`.`colordescriptions`.`clrd_clr_colorid`        AS `clrd_clr_colorid`,
       `echothree`.`colordescriptions`.`clrd_lang_languageid`    AS `clrd_lang_languageid`,
       `echothree`.`colordescriptions`.`clrd_description`        AS `clrd_description`
from `echothree`.`colordescriptions`
where (`echothree`.`colordescriptions`.`clrd_thrutime` = 9223372036854775807);

