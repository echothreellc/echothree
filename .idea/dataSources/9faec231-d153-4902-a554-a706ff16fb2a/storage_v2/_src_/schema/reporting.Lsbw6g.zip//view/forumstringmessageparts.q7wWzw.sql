create definer = echothree@`127.0.0.1` view forumstringmessageparts as
select `echothree`.`forumstringmessageparts`.`frmsmsgprt_forumstringmessagepartid`     AS `frmsmsgprt_forumstringmessagepartid`,
       `echothree`.`forumstringmessageparts`.`frmsmsgprt_frmmsgprt_forummessagepartid` AS `frmsmsgprt_frmmsgprt_forummessagepartid`,
       `echothree`.`forumstringmessageparts`.`frmsmsgprt_string`                       AS `frmsmsgprt_string`
from `echothree`.`forumstringmessageparts`
where (`echothree`.`forumstringmessageparts`.`frmsmsgprt_thrutime` = 9223372036854775807);

