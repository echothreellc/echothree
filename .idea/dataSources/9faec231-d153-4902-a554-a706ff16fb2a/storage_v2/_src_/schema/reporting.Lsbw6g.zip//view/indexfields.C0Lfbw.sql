create definer = echothree@`127.0.0.1` view indexfields as
select `echothree`.`indexfields`.`idxfld_indexfieldid`             AS `idxfld_indexfieldid`,
       `echothree`.`indexfielddetails`.`idxflddt_idxt_indextypeid` AS `idxflddt_idxt_indextypeid`,
       `echothree`.`indexfielddetails`.`idxflddt_indexfieldname`   AS `idxflddt_indexfieldname`,
       `echothree`.`indexfielddetails`.`idxflddt_isdefault`        AS `idxflddt_isdefault`,
       `echothree`.`indexfielddetails`.`idxflddt_sortorder`        AS `idxflddt_sortorder`
from `echothree`.`indexfields`
         join `echothree`.`indexfielddetails`
where (`echothree`.`indexfields`.`idxfld_activedetailid` =
       `echothree`.`indexfielddetails`.`idxflddt_indexfielddetailid`);

