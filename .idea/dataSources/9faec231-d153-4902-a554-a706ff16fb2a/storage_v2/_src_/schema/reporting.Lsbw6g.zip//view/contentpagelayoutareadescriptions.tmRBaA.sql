create definer = echothree@`127.0.0.1` view contentpagelayoutareadescriptions as
select `echothree`.`contentpagelayoutareadescriptions`.`cntplad_contentpagelayoutareadescriptionid` AS `cntplad_contentpagelayoutareadescriptionid`,
       `echothree`.`contentpagelayoutareadescriptions`.`cntplad_cntpla_contentpagelayoutareaid`     AS `cntplad_cntpla_contentpagelayoutareaid`,
       `echothree`.`contentpagelayoutareadescriptions`.`cntplad_lang_languageid`                    AS `cntplad_lang_languageid`,
       `echothree`.`contentpagelayoutareadescriptions`.`cntplad_description`                        AS `cntplad_description`
from `echothree`.`contentpagelayoutareadescriptions`;

