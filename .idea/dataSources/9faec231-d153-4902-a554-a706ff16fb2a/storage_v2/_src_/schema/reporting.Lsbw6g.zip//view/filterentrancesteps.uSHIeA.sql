create definer = echothree@`127.0.0.1` view filterentrancesteps as
select `echothree`.`filterentrancesteps`.`fltens_filterentrancestepid` AS `fltens_filterentrancestepid`,
       `echothree`.`filterentrancesteps`.`fltens_flt_filterid`         AS `fltens_flt_filterid`,
       `echothree`.`filterentrancesteps`.`fltens_fltstp_filterstepid`  AS `fltens_fltstp_filterstepid`
from `echothree`.`filterentrancesteps`
where (`echothree`.`filterentrancesteps`.`fltens_thrutime` = 9223372036854775807);

