create definer = echothree@`127.0.0.1` view associates as
select `echothree`.`associates`.`asc_associateid`                        AS `asc_associateid`,
       `echothree`.`associatedetails`.`ascdt_ascprgm_associateprogramid` AS `ascdt_ascprgm_associateprogramid`,
       `echothree`.`associatedetails`.`ascdt_associatename`              AS `ascdt_associatename`,
       `echothree`.`associatedetails`.`ascdt_par_partyid`                AS `ascdt_par_partyid`,
       `echothree`.`associatedetails`.`ascdt_description`                AS `ascdt_description`,
       `echothree`.`associatedetails`.`ascdt_summarymimetypeid`          AS `ascdt_summarymimetypeid`,
       `echothree`.`associatedetails`.`ascdt_summary`                    AS `ascdt_summary`
from `echothree`.`associates`
         join `echothree`.`associatedetails`
where (`echothree`.`associates`.`asc_activedetailid` = `echothree`.`associatedetails`.`ascdt_associatedetailid`);

