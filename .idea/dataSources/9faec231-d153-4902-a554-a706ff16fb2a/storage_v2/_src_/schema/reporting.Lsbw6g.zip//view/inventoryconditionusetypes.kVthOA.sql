create definer = echothree@`127.0.0.1` view inventoryconditionusetypes as
select `echothree`.`inventoryconditionusetypes`.`invconut_inventoryconditionusetypeid`   AS `invconut_inventoryconditionusetypeid`,
       `echothree`.`inventoryconditionusetypes`.`invconut_inventoryconditionusetypename` AS `invconut_inventoryconditionusetypename`,
       `echothree`.`inventoryconditionusetypes`.`invconut_isdefault`                     AS `invconut_isdefault`,
       `echothree`.`inventoryconditionusetypes`.`invconut_sortorder`                     AS `invconut_sortorder`
from `echothree`.`inventoryconditionusetypes`;

