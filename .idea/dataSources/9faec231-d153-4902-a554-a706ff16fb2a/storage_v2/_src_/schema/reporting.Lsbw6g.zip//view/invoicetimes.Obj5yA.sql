create definer = echothree@`127.0.0.1` view invoicetimes as
select `echothree`.`invoicetimes`.`invctim_invoicetimeid`                AS `invctim_invoicetimeid`,
       `echothree`.`invoicetimes`.`invctim_invc_invoiceid`               AS `invctim_invc_invoiceid`,
       `echothree`.`invoicetimes`.`invctim_invctimtyp_invoicetimetypeid` AS `invctim_invctimtyp_invoicetimetypeid`,
       `echothree`.`invoicetimes`.`invctim_time`                         AS `invctim_time`
from `echothree`.`invoicetimes`
where (`echothree`.`invoicetimes`.`invctim_thrutime` = 9223372036854775807);

