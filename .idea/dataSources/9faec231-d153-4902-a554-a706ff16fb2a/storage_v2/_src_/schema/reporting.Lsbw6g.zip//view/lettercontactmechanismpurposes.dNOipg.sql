create definer = echothree@`127.0.0.1` view lettercontactmechanismpurposes as
select `echothree`.`lettercontactmechanismpurposes`.`lttrcmpr_lettercontactmechanismpurposeid`        AS `lttrcmpr_lettercontactmechanismpurposeid`,
       `echothree`.`lettercontactmechanismpurposedetails`.`lttrcmprdt_lttr_letterid`                  AS `lttrcmprdt_lttr_letterid`,
       `echothree`.`lettercontactmechanismpurposedetails`.`lttrcmprdt_priority`                       AS `lttrcmprdt_priority`,
       `echothree`.`lettercontactmechanismpurposedetails`.`lttrcmprdt_cmpr_contactmechanismpurposeid` AS `lttrcmprdt_cmpr_contactmechanismpurposeid`
from `echothree`.`lettercontactmechanismpurposes`
         join `echothree`.`lettercontactmechanismpurposedetails`
where (`echothree`.`lettercontactmechanismpurposes`.`lttrcmpr_activedetailid` =
       `echothree`.`lettercontactmechanismpurposedetails`.`lttrcmprdt_lettercontactmechanismpurposedetailid`);

