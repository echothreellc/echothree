create definer = echothree@`127.0.0.1` view associateprograms as
select `echothree`.`associateprograms`.`ascprgm_associateprogramid`                               AS `ascprgm_associateprogramid`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_associateprogramname`                     AS `ascprgmdt_associateprogramname`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_associatesequenceid`                      AS `ascprgmdt_associatesequenceid`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_associatepartycontactmechanismsequenceid` AS `ascprgmdt_associatepartycontactmechanismsequenceid`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_associatereferralsequenceid`              AS `ascprgmdt_associatereferralsequenceid`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_itemindirectsalepercent`                  AS `ascprgmdt_itemindirectsalepercent`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_itemdirectsalepercent`                    AS `ascprgmdt_itemdirectsalepercent`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_isdefault`                                AS `ascprgmdt_isdefault`,
       `echothree`.`associateprogramdetails`.`ascprgmdt_sortorder`                                AS `ascprgmdt_sortorder`
from `echothree`.`associateprograms`
         join `echothree`.`associateprogramdetails`
where (`echothree`.`associateprograms`.`ascprgm_activedetailid` =
       `echothree`.`associateprogramdetails`.`ascprgmdt_associateprogramdetailid`);

