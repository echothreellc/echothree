create definer = echothree@`127.0.0.1` view componentversions as
select `echothree`.`componentversions`.`cvrs_componentversionid`    AS `cvrs_componentversionid`,
       `echothree`.`componentversions`.`cvrs_cpnt_componentid`      AS `cvrs_cpnt_componentid`,
       `echothree`.`componentversions`.`cvrs_majorrevision`         AS `cvrs_majorrevision`,
       `echothree`.`componentversions`.`cvrs_minorrevision`         AS `cvrs_minorrevision`,
       `echothree`.`componentversions`.`cvrs_cstg_componentstageid` AS `cvrs_cstg_componentstageid`,
       `echothree`.`componentversions`.`cvrs_buildnumber`           AS `cvrs_buildnumber`
from `echothree`.`componentversions`
where (`echothree`.`componentversions`.`cvrs_thrutime` = 9223372036854775807);

