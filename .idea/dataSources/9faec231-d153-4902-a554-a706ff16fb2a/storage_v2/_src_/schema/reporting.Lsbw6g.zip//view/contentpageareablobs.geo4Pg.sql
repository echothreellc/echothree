create definer = echothree@`127.0.0.1` view contentpageareablobs as
select `echothree`.`contentpageareablobs`.`cntpab_contentpageareablobid`          AS `cntpab_contentpageareablobid`,
       `echothree`.`contentpageareablobs`.`cntpab_cntpad_contentpageareadetailid` AS `cntpab_cntpad_contentpageareadetailid`,
       `echothree`.`contentpageareablobs`.`cntpab_blob`                           AS `cntpab_blob`
from `echothree`.`contentpageareablobs`;

