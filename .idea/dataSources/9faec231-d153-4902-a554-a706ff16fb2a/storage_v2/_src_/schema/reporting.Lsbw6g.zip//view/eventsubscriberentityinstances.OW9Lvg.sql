create definer = echothree@`127.0.0.1` view eventsubscriberentityinstances as
select `echothree`.`eventsubscriberentityinstances`.`evsei_eventsubscriberentityinstanceid` AS `evsei_eventsubscriberentityinstanceid`,
       `echothree`.`eventsubscriberentityinstances`.`evsei_evs_eventsubscriberid`           AS `evsei_evs_eventsubscriberid`,
       `echothree`.`eventsubscriberentityinstances`.`evsei_eni_entityinstanceid`            AS `evsei_eni_entityinstanceid`,
       `echothree`.`eventsubscriberentityinstances`.`evsei_evty_eventtypeid`                AS `evsei_evty_eventtypeid`
from `echothree`.`eventsubscriberentityinstances`
where (`echothree`.`eventsubscriberentityinstances`.`evsei_thrutime` = 9223372036854775807);

