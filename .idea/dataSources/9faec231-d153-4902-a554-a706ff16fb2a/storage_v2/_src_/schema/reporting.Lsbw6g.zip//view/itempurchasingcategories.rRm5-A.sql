create definer = echothree@`127.0.0.1` view itempurchasingcategories as
select `echothree`.`itempurchasingcategories`.`iprchc_itempurchasingcategoryid`              AS `iprchc_itempurchasingcategoryid`,
       `echothree`.`itempurchasingcategorydetails`.`iprchcdt_itempurchasingcategoryname`     AS `iprchcdt_itempurchasingcategoryname`,
       `echothree`.`itempurchasingcategorydetails`.`iprchcdt_parentitempurchasingcategoryid` AS `iprchcdt_parentitempurchasingcategoryid`,
       `echothree`.`itempurchasingcategorydetails`.`iprchcdt_isdefault`                      AS `iprchcdt_isdefault`,
       `echothree`.`itempurchasingcategorydetails`.`iprchcdt_sortorder`                      AS `iprchcdt_sortorder`
from `echothree`.`itempurchasingcategories`
         join `echothree`.`itempurchasingcategorydetails`
where (`echothree`.`itempurchasingcategories`.`iprchc_activedetailid` =
       `echothree`.`itempurchasingcategorydetails`.`iprchcdt_itempurchasingcategorydetailid`);

