create definer = echothree@`127.0.0.1` view eventsubscriberentitytypes as
select `echothree`.`eventsubscriberentitytypes`.`evset_eventsubscriberentitytypeid` AS `evset_eventsubscriberentitytypeid`,
       `echothree`.`eventsubscriberentitytypes`.`evset_evs_eventsubscriberid`       AS `evset_evs_eventsubscriberid`,
       `echothree`.`eventsubscriberentitytypes`.`evset_ent_entitytypeid`            AS `evset_ent_entitytypeid`,
       `echothree`.`eventsubscriberentitytypes`.`evset_evty_eventtypeid`            AS `evset_evty_eventtypeid`
from `echothree`.`eventsubscriberentitytypes`
where (`echothree`.`eventsubscriberentitytypes`.`evset_thrutime` = 9223372036854775807);

