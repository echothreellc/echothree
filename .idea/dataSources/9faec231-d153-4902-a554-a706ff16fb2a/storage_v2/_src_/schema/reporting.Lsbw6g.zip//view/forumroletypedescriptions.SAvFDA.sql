create definer = echothree@`127.0.0.1` view forumroletypedescriptions as
select `echothree`.`forumroletypedescriptions`.`frmrtypd_forumroletypedescriptionid` AS `frmrtypd_forumroletypedescriptionid`,
       `echothree`.`forumroletypedescriptions`.`frmrtypd_frmrtyp_forumroletypeid`    AS `frmrtypd_frmrtyp_forumroletypeid`,
       `echothree`.`forumroletypedescriptions`.`frmrtypd_lang_languageid`            AS `frmrtypd_lang_languageid`,
       `echothree`.`forumroletypedescriptions`.`frmrtypd_description`                AS `frmrtypd_description`
from `echothree`.`forumroletypedescriptions`;

