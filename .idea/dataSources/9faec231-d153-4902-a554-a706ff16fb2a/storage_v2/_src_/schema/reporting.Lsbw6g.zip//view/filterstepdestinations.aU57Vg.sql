create definer = echothree@`127.0.0.1` view filterstepdestinations as
select `echothree`.`filterstepdestinations`.`fltstpdn_filterstepdestinationid` AS `fltstpdn_filterstepdestinationid`,
       `echothree`.`filterstepdestinations`.`fltstpdn_fromfilterstepid`        AS `fltstpdn_fromfilterstepid`,
       `echothree`.`filterstepdestinations`.`fltstpdn_tofilterstepid`          AS `fltstpdn_tofilterstepid`
from `echothree`.`filterstepdestinations`
where (`echothree`.`filterstepdestinations`.`fltstpdn_thrutime` = 9223372036854775807);

