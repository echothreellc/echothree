create definer = echothree@`127.0.0.1` view allocationpriorities as
select `echothree`.`allocationpriorities`.`allocpr_allocationpriorityid`          AS `allocpr_allocationpriorityid`,
       `echothree`.`allocationprioritydetails`.`allocprdt_allocationpriorityname` AS `allocprdt_allocationpriorityname`,
       `echothree`.`allocationprioritydetails`.`allocprdt_priority`               AS `allocprdt_priority`,
       `echothree`.`allocationprioritydetails`.`allocprdt_isdefault`              AS `allocprdt_isdefault`,
       `echothree`.`allocationprioritydetails`.`allocprdt_sortorder`              AS `allocprdt_sortorder`
from `echothree`.`allocationpriorities`
         join `echothree`.`allocationprioritydetails`
where (`echothree`.`allocationpriorities`.`allocpr_activedetailid` =
       `echothree`.`allocationprioritydetails`.`allocprdt_allocationprioritydetailid`);

