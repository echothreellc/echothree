create definer = echothree@`127.0.0.1` view itemaliastypes as
select `echothree`.`itemaliastypes`.`iat_itemaliastypeid`                      AS `iat_itemaliastypeid`,
       `echothree`.`itemaliastypedetails`.`iatdt_itemaliastypename`            AS `iatdt_itemaliastypename`,
       `echothree`.`itemaliastypedetails`.`iatdt_validationpattern`            AS `iatdt_validationpattern`,
       `echothree`.`itemaliastypedetails`.`iatdt_iact_itemaliaschecksumtypeid` AS `iatdt_iact_itemaliaschecksumtypeid`,
       `echothree`.`itemaliastypedetails`.`iatdt_allowmultiple`                AS `iatdt_allowmultiple`,
       `echothree`.`itemaliastypedetails`.`iatdt_isdefault`                    AS `iatdt_isdefault`,
       `echothree`.`itemaliastypedetails`.`iatdt_sortorder`                    AS `iatdt_sortorder`
from `echothree`.`itemaliastypes`
         join `echothree`.`itemaliastypedetails`
where (`echothree`.`itemaliastypes`.`iat_activedetailid` =
       `echothree`.`itemaliastypedetails`.`iatdt_itemaliastypedetailid`);

