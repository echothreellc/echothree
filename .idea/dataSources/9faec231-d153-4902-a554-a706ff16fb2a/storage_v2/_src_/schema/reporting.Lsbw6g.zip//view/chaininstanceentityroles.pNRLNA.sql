create definer = echothree@`127.0.0.1` view chaininstanceentityroles as
select `echothree`.`chaininstanceentityroles`.`chnier_chaininstanceentityroleid`      AS `chnier_chaininstanceentityroleid`,
       `echothree`.`chaininstanceentityroles`.`chnier_chni_chaininstanceid`           AS `chnier_chni_chaininstanceid`,
       `echothree`.`chaininstanceentityroles`.`chnier_chnertyp_chainentityroletypeid` AS `chnier_chnertyp_chainentityroletypeid`,
       `echothree`.`chaininstanceentityroles`.`chnier_eni_entityinstanceid`           AS `chnier_eni_entityinstanceid`
from `echothree`.`chaininstanceentityroles`
where (`echothree`.`chaininstanceentityroles`.`chnier_thrutime` = 9223372036854775807);

