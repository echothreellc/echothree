create definer = echothree@`127.0.0.1` view contentpagelayoutdescriptions as
select `echothree`.`contentpagelayoutdescriptions`.`cntpld_contentpagelayoutdescriptionid` AS `cntpld_contentpagelayoutdescriptionid`,
       `echothree`.`contentpagelayoutdescriptions`.`cntpld_cntpl_contentpagelayoutid`      AS `cntpld_cntpl_contentpagelayoutid`,
       `echothree`.`contentpagelayoutdescriptions`.`cntpld_lang_languageid`                AS `cntpld_lang_languageid`,
       `echothree`.`contentpagelayoutdescriptions`.`cntpld_description`                    AS `cntpld_description`
from `echothree`.`contentpagelayoutdescriptions`
where (`echothree`.`contentpagelayoutdescriptions`.`cntpld_thrutime` = 9223372036854775807);

