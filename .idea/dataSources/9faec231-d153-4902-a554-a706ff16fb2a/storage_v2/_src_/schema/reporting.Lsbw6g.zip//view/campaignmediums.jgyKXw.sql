create definer = echothree@`127.0.0.1` view campaignmediums as
select `echothree`.`campaignmediums`.`cmpgnmdm_campaignmediumid`           AS `cmpgnmdm_campaignmediumid`,
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_campaignmediumname` AS `cmpgnmdmdt_campaignmediumname`,
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_valuesha1hash`      AS `cmpgnmdmdt_valuesha1hash`,
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_value`              AS `cmpgnmdmdt_value`,
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_isdefault`          AS `cmpgnmdmdt_isdefault`,
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_sortorder`          AS `cmpgnmdmdt_sortorder`
from `echothree`.`campaignmediums`
         join `echothree`.`campaignmediumdetails`
where (`echothree`.`campaignmediums`.`cmpgnmdm_activedetailid` =
       `echothree`.`campaignmediumdetails`.`cmpgnmdmdt_campaignmediumdetailid`);

