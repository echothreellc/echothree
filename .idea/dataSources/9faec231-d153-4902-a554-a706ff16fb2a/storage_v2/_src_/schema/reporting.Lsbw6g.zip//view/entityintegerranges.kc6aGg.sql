create definer = echothree@`127.0.0.1` view entityintegerranges as
select `echothree`.`entityintegerranges`.`enir_entityintegerrangeid`           AS `enir_entityintegerrangeid`,
       `echothree`.`entityintegerrangedetails`.`enirdt_ena_entityattributeid`  AS `enirdt_ena_entityattributeid`,
       `echothree`.`entityintegerrangedetails`.`enirdt_entityintegerrangename` AS `enirdt_entityintegerrangename`,
       `echothree`.`entityintegerrangedetails`.`enirdt_minimumintegervalue`    AS `enirdt_minimumintegervalue`,
       `echothree`.`entityintegerrangedetails`.`enirdt_maximumintegervalue`    AS `enirdt_maximumintegervalue`,
       `echothree`.`entityintegerrangedetails`.`enirdt_isdefault`              AS `enirdt_isdefault`,
       `echothree`.`entityintegerrangedetails`.`enirdt_sortorder`              AS `enirdt_sortorder`
from `echothree`.`entityintegerranges`
         join `echothree`.`entityintegerrangedetails`
where (`echothree`.`entityintegerranges`.`enir_activedetailid` =
       `echothree`.`entityintegerrangedetails`.`enirdt_entityintegerrangedetailid`);

