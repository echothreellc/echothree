create definer = echothree@`127.0.0.1` view freeonboarddescriptions as
select `echothree`.`freeonboarddescriptions`.`fobd_freeonboarddescriptionid` AS `fobd_freeonboarddescriptionid`,
       `echothree`.`freeonboarddescriptions`.`fobd_fob_freeonboardid`        AS `fobd_fob_freeonboardid`,
       `echothree`.`freeonboarddescriptions`.`fobd_lang_languageid`          AS `fobd_lang_languageid`,
       `echothree`.`freeonboarddescriptions`.`fobd_description`              AS `fobd_description`
from `echothree`.`freeonboarddescriptions`
where (`echothree`.`freeonboarddescriptions`.`fobd_thrutime` = 9223372036854775807);

