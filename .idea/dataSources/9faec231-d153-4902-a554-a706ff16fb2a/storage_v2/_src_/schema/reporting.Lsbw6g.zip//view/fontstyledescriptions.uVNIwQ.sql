create definer = echothree@`127.0.0.1` view fontstyledescriptions as
select `echothree`.`fontstyledescriptions`.`fntstyld_fontstyledescriptionid` AS `fntstyld_fontstyledescriptionid`,
       `echothree`.`fontstyledescriptions`.`fntstyld_fntstyl_fontstyleid`    AS `fntstyld_fntstyl_fontstyleid`,
       `echothree`.`fontstyledescriptions`.`fntstyld_lang_languageid`        AS `fntstyld_lang_languageid`,
       `echothree`.`fontstyledescriptions`.`fntstyld_description`            AS `fntstyld_description`
from `echothree`.`fontstyledescriptions`
where (`echothree`.`fontstyledescriptions`.`fntstyld_thrutime` = 9223372036854775807);

