create definer = echothree@`127.0.0.1` view lotaliases as
select `echothree`.`lotaliases`.`ltal_lotaliasid`             AS `ltal_lotaliasid`,
       `echothree`.`lotaliases`.`ltal_lt_lotid`               AS `ltal_lt_lotid`,
       `echothree`.`lotaliases`.`ltal_ltaltyp_lotaliastypeid` AS `ltal_ltaltyp_lotaliastypeid`,
       `echothree`.`lotaliases`.`ltal_alias`                  AS `ltal_alias`
from `echothree`.`lotaliases`
where (`echothree`.`lotaliases`.`ltal_thrutime` = 9223372036854775807);

