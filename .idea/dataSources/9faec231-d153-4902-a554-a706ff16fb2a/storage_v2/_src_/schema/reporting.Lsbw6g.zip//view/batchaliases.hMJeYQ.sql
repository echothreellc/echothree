create definer = echothree@`127.0.0.1` view batchaliases as
select `echothree`.`batchaliases`.`btchal_batchaliasid`            AS `btchal_batchaliasid`,
       `echothree`.`batchaliases`.`btchal_btch_batchid`            AS `btchal_btch_batchid`,
       `echothree`.`batchaliases`.`btchal_btchat_batchaliastypeid` AS `btchal_btchat_batchaliastypeid`,
       `echothree`.`batchaliases`.`btchal_alias`                   AS `btchal_alias`
from `echothree`.`batchaliases`
where (`echothree`.`batchaliases`.`btchal_thrutime` = 9223372036854775807);

