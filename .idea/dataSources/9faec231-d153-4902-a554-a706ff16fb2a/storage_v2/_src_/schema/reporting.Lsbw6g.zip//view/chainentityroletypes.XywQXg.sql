create definer = echothree@`127.0.0.1` view chainentityroletypes as
select `echothree`.`chainentityroletypes`.`chnertyp_chainentityroletypeid`           AS `chnertyp_chainentityroletypeid`,
       `echothree`.`chainentityroletypedetails`.`chnertypdt_chntyp_chaintypeid`      AS `chnertypdt_chntyp_chaintypeid`,
       `echothree`.`chainentityroletypedetails`.`chnertypdt_chainentityroletypename` AS `chnertypdt_chainentityroletypename`,
       `echothree`.`chainentityroletypedetails`.`chnertypdt_ent_entitytypeid`        AS `chnertypdt_ent_entitytypeid`,
       `echothree`.`chainentityroletypedetails`.`chnertypdt_sortorder`               AS `chnertypdt_sortorder`
from `echothree`.`chainentityroletypes`
         join `echothree`.`chainentityroletypedetails`
where (`echothree`.`chainentityroletypes`.`chnertyp_activedetailid` =
       `echothree`.`chainentityroletypedetails`.`chnertypdt_chainentityroletypedetailid`);

