create definer = echothree@`127.0.0.1` view itemclobdescriptions as
select `echothree`.`itemclobdescriptions`.`icdesc_itemclobdescriptionid`   AS `icdesc_itemclobdescriptionid`,
       `echothree`.`itemclobdescriptions`.`icdesc_idesc_itemdescriptionid` AS `icdesc_idesc_itemdescriptionid`,
       `echothree`.`itemclobdescriptions`.`icdesc_clobdescription`         AS `icdesc_clobdescription`
from `echothree`.`itemclobdescriptions`
where (`echothree`.`itemclobdescriptions`.`icdesc_thrutime` = 9223372036854775807);

