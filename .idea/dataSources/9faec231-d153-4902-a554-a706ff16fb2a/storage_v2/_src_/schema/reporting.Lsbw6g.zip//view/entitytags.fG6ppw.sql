create definer = echothree@`127.0.0.1` view entitytags as
select `echothree`.`entitytags`.`et_entitytagid`            AS `et_entitytagid`,
       `echothree`.`entitytags`.`et_taggedentityinstanceid` AS `et_taggedentityinstanceid`,
       `echothree`.`entitytags`.`et_t_tagid`                AS `et_t_tagid`
from `echothree`.`entitytags`
where (`echothree`.`entitytags`.`et_thrutime` = 9223372036854775807);

