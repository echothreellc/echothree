create definer = echothree@`127.0.0.1` view commentusagetypes as
select `echothree`.`commentusagetypes`.`cmntutyp_commentusagetypeid`            AS `cmntutyp_commentusagetypeid`,
       `echothree`.`commentusagetypedetails`.`cmntutypdt_cmnttyp_commenttypeid` AS `cmntutypdt_cmnttyp_commenttypeid`,
       `echothree`.`commentusagetypedetails`.`cmntutypdt_commentusagetypename`  AS `cmntutypdt_commentusagetypename`,
       `echothree`.`commentusagetypedetails`.`cmntutypdt_selectedbydefault`     AS `cmntutypdt_selectedbydefault`,
       `echothree`.`commentusagetypedetails`.`cmntutypdt_sortorder`             AS `cmntutypdt_sortorder`
from `echothree`.`commentusagetypes`
         join `echothree`.`commentusagetypedetails`
where (`echothree`.`commentusagetypes`.`cmntutyp_activedetailid` =
       `echothree`.`commentusagetypedetails`.`cmntutypdt_commentusagetypedetailid`);

