create definer = echothree@`127.0.0.1` view entityattributeentityattributegroups as
select `echothree`.`entityattributeentityattributegroups`.`enaenagp_entityattributeentityattributegroupid` AS `enaenagp_entityattributeentityattributegroupid`,
       `echothree`.`entityattributeentityattributegroups`.`enaenagp_ena_entityattributeid`                 AS `enaenagp_ena_entityattributeid`,
       `echothree`.`entityattributeentityattributegroups`.`enaenagp_enagp_entityattributegroupid`          AS `enaenagp_enagp_entityattributegroupid`,
       `echothree`.`entityattributeentityattributegroups`.`enaenagp_sortorder`                             AS `enaenagp_sortorder`
from `echothree`.`entityattributeentityattributegroups`
where (`echothree`.`entityattributeentityattributegroups`.`enaenagp_thrutime` = 9223372036854775807);

