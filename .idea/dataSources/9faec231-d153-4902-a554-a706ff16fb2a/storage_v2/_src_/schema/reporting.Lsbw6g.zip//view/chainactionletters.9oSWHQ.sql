create definer = echothree@`127.0.0.1` view chainactionletters as
select `echothree`.`chainactionletters`.`chnactlttr_chainactionletterid`  AS `chnactlttr_chainactionletterid`,
       `echothree`.`chainactionletters`.`chnactlttr_chnact_chainactionid` AS `chnactlttr_chnact_chainactionid`,
       `echothree`.`chainactionletters`.`chnactlttr_lttr_letterid`        AS `chnactlttr_lttr_letterid`
from `echothree`.`chainactionletters`
where (`echothree`.`chainactionletters`.`chnactlttr_thrutime` = 9223372036854775807);

