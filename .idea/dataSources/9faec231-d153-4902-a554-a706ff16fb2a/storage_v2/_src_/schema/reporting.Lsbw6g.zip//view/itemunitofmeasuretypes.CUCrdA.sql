create definer = echothree@`127.0.0.1` view itemunitofmeasuretypes as
select `echothree`.`itemunitofmeasuretypes`.`iuomt_itemunitofmeasuretypeid`  AS `iuomt_itemunitofmeasuretypeid`,
       `echothree`.`itemunitofmeasuretypes`.`iuomt_itm_itemid`               AS `iuomt_itm_itemid`,
       `echothree`.`itemunitofmeasuretypes`.`iuomt_uomt_unitofmeasuretypeid` AS `iuomt_uomt_unitofmeasuretypeid`,
       `echothree`.`itemunitofmeasuretypes`.`iuomt_isdefault`                AS `iuomt_isdefault`,
       `echothree`.`itemunitofmeasuretypes`.`iuomt_sortorder`                AS `iuomt_sortorder`
from `echothree`.`itemunitofmeasuretypes`
where (`echothree`.`itemunitofmeasuretypes`.`iuomt_thrutime` = 9223372036854775807);

