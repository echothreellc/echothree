create definer = echothree@`127.0.0.1` view contactlistdescriptions as
select `echothree`.`contactlistdescriptions`.`clstd_contactlistdescriptionid` AS `clstd_contactlistdescriptionid`,
       `echothree`.`contactlistdescriptions`.`clstd_clst_contactlistid`       AS `clstd_clst_contactlistid`,
       `echothree`.`contactlistdescriptions`.`clstd_lang_languageid`          AS `clstd_lang_languageid`,
       `echothree`.`contactlistdescriptions`.`clstd_description`              AS `clstd_description`
from `echothree`.`contactlistdescriptions`
where (`echothree`.`contactlistdescriptions`.`clstd_thrutime` = 9223372036854775807);

