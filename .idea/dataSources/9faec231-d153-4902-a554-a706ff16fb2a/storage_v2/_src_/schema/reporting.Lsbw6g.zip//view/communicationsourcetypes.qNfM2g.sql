create definer = echothree@`127.0.0.1` view communicationsourcetypes as
select `echothree`.`communicationsourcetypes`.`cmmnsrctyp_communicationsourcetypeid`   AS `cmmnsrctyp_communicationsourcetypeid`,
       `echothree`.`communicationsourcetypes`.`cmmnsrctyp_communicationsourcetypename` AS `cmmnsrctyp_communicationsourcetypename`,
       `echothree`.`communicationsourcetypes`.`cmmnsrctyp_isdefault`                   AS `cmmnsrctyp_isdefault`,
       `echothree`.`communicationsourcetypes`.`cmmnsrctyp_sortorder`                   AS `cmmnsrctyp_sortorder`
from `echothree`.`communicationsourcetypes`;

