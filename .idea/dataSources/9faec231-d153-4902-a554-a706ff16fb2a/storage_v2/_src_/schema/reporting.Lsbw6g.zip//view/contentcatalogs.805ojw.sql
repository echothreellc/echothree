create definer = echothree@`127.0.0.1` view contentcatalogs as
select `echothree`.`contentcatalogs`.`cntct_contentcatalogid`                 AS `cntct_contentcatalogid`,
       `echothree`.`contentcatalogdetails`.`cntctdt_cntc_contentcollectionid` AS `cntctdt_cntc_contentcollectionid`,
       `echothree`.`contentcatalogdetails`.`cntctdt_contentcatalogname`       AS `cntctdt_contentcatalogname`,
       `echothree`.`contentcatalogdetails`.`cntctdt_defaultofferuseid`        AS `cntctdt_defaultofferuseid`,
       `echothree`.`contentcatalogdetails`.`cntctdt_isdefault`                AS `cntctdt_isdefault`,
       `echothree`.`contentcatalogdetails`.`cntctdt_sortorder`                AS `cntctdt_sortorder`
from `echothree`.`contentcatalogs`
         join `echothree`.`contentcatalogdetails`
where (`echothree`.`contentcatalogs`.`cntct_activedetailid` =
       `echothree`.`contentcatalogdetails`.`cntctdt_contentcatalogdetailid`);

