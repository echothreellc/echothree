create definer = echothree@`127.0.0.1` view contentpagelayouts as
select `echothree`.`contentpagelayouts`.`cntpl_contentpagelayoutid`           AS `cntpl_contentpagelayoutid`,
       `echothree`.`contentpagelayoutdetails`.`cntpldt_contentpagelayoutname` AS `cntpldt_contentpagelayoutname`,
       `echothree`.`contentpagelayoutdetails`.`cntpldt_isdefault`             AS `cntpldt_isdefault`,
       `echothree`.`contentpagelayoutdetails`.`cntpldt_sortorder`             AS `cntpldt_sortorder`
from `echothree`.`contentpagelayouts`
         join `echothree`.`contentpagelayoutdetails`
where (`echothree`.`contentpagelayouts`.`cntpl_activedetailid` =
       `echothree`.`contentpagelayoutdetails`.`cntpldt_contentpagelayoutdetailid`);

