create definer = echothree@`127.0.0.1` view billingaccountroletypedescriptions as
select `echothree`.`billingaccountroletypedescriptions`.`bllactrtypd_billingaccountroletypedescriptionid` AS `bllactrtypd_billingaccountroletypedescriptionid`,
       `echothree`.`billingaccountroletypedescriptions`.`bllactrtypd_bllactrtyp_billingaccountroletypeid` AS `bllactrtypd_bllactrtyp_billingaccountroletypeid`,
       `echothree`.`billingaccountroletypedescriptions`.`bllactrtypd_lang_languageid`                     AS `bllactrtypd_lang_languageid`,
       `echothree`.`billingaccountroletypedescriptions`.`bllactrtypd_description`                         AS `bllactrtypd_description`
from `echothree`.`billingaccountroletypedescriptions`;

