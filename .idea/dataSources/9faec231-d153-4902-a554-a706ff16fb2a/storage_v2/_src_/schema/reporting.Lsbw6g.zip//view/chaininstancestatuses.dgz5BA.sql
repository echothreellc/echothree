create definer = echothree@`127.0.0.1` view chaininstancestatuses as
select `echothree`.`chaininstancestatuses`.`chnist_chaininstancestatusid`  AS `chnist_chaininstancestatusid`,
       `echothree`.`chaininstancestatuses`.`chnist_chni_chaininstanceid`   AS `chnist_chni_chaininstanceid`,
       `echothree`.`chaininstancestatuses`.`chnist_nextchainactionsetid`   AS `chnist_nextchainactionsetid`,
       `echothree`.`chaininstancestatuses`.`chnist_nextchainactionsettime` AS `chnist_nextchainactionsettime`,
       `echothree`.`chaininstancestatuses`.`chnist_queuedlettersequence`   AS `chnist_queuedlettersequence`
from `echothree`.`chaininstancestatuses`;

