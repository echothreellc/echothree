create definer = echothree@`127.0.0.1` view forummessageparts as
select `echothree`.`forummessageparts`.`frmmsgprt_forummessagepartid`                          AS `frmmsgprt_forummessagepartid`,
       `echothree`.`forummessagepartdetails`.`frmmsgprtdt_frmmsg_forummessageid`               AS `frmmsgprtdt_frmmsg_forummessageid`,
       `echothree`.`forummessagepartdetails`.`frmmsgprtdt_frmmsgprttyp_forummessageparttypeid` AS `frmmsgprtdt_frmmsgprttyp_forummessageparttypeid`,
       `echothree`.`forummessagepartdetails`.`frmmsgprtdt_lang_languageid`                     AS `frmmsgprtdt_lang_languageid`,
       `echothree`.`forummessagepartdetails`.`frmmsgprtdt_mtyp_mimetypeid`                     AS `frmmsgprtdt_mtyp_mimetypeid`
from `echothree`.`forummessageparts`
         join `echothree`.`forummessagepartdetails`
where (`echothree`.`forummessageparts`.`frmmsgprt_activedetailid` =
       `echothree`.`forummessagepartdetails`.`frmmsgprtdt_forummessagepartdetailid`);

