create definer = echothree@`127.0.0.1` view appearances as
select `echothree`.`appearances`.`apprnc_appearanceid`                 AS `apprnc_appearanceid`,
       `echothree`.`appearancedetails`.`apprncdt_appearancename`       AS `apprncdt_appearancename`,
       `echothree`.`appearancedetails`.`apprncdt_textcolorid`          AS `apprncdt_textcolorid`,
       `echothree`.`appearancedetails`.`apprncdt_backgroundcolorid`    AS `apprncdt_backgroundcolorid`,
       `echothree`.`appearancedetails`.`apprncdt_fntstyl_fontstyleid`  AS `apprncdt_fntstyl_fontstyleid`,
       `echothree`.`appearancedetails`.`apprncdt_fntwght_fontweightid` AS `apprncdt_fntwght_fontweightid`,
       `echothree`.`appearancedetails`.`apprncdt_isdefault`            AS `apprncdt_isdefault`,
       `echothree`.`appearancedetails`.`apprncdt_sortorder`            AS `apprncdt_sortorder`
from `echothree`.`appearances`
         join `echothree`.`appearancedetails`
where (`echothree`.`appearances`.`apprnc_activedetailid` =
       `echothree`.`appearancedetails`.`apprncdt_appearancedetailid`);

