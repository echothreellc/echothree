create definer = echothree@`127.0.0.1` view fontweightdescriptions as
select `echothree`.`fontweightdescriptions`.`fntwghtd_fontweightdescriptionid` AS `fntwghtd_fontweightdescriptionid`,
       `echothree`.`fontweightdescriptions`.`fntwghtd_fntwght_fontweightid`    AS `fntwghtd_fntwght_fontweightid`,
       `echothree`.`fontweightdescriptions`.`fntwghtd_lang_languageid`         AS `fntwghtd_lang_languageid`,
       `echothree`.`fontweightdescriptions`.`fntwghtd_description`             AS `fntwghtd_description`
from `echothree`.`fontweightdescriptions`
where (`echothree`.`fontweightdescriptions`.`fntwghtd_thrutime` = 9223372036854775807);

