create definer = echothree@`127.0.0.1` view forummessageparttypedescriptions as
select `echothree`.`forummessageparttypedescriptions`.`frmmsgprttypd_forummessageparttypedescriptionid`   AS `frmmsgprttypd_forummessageparttypedescriptionid`,
       `echothree`.`forummessageparttypedescriptions`.`frmmsgprttypd_frmmsgprttyp_forummessageparttypeid` AS `frmmsgprttypd_frmmsgprttyp_forummessageparttypeid`,
       `echothree`.`forummessageparttypedescriptions`.`frmmsgprttypd_lang_languageid`                     AS `frmmsgprttypd_lang_languageid`,
       `echothree`.`forummessageparttypedescriptions`.`frmmsgprttypd_description`                         AS `frmmsgprttypd_description`
from `echothree`.`forummessageparttypedescriptions`;

