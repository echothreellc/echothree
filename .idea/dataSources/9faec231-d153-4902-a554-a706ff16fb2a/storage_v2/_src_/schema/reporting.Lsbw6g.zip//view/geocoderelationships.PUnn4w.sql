create definer = echothree@`127.0.0.1` view geocoderelationships as
select `echothree`.`geocoderelationships`.`geor_geocoderelationshipid` AS `geor_geocoderelationshipid`,
       `echothree`.`geocoderelationships`.`geor_fromgeocodeid`         AS `geor_fromgeocodeid`,
       `echothree`.`geocoderelationships`.`geor_togeocodeid`           AS `geor_togeocodeid`
from `echothree`.`geocoderelationships`
where (`echothree`.`geocoderelationships`.`geor_thrutime` = 9223372036854775807);

