create definer = echothree@`127.0.0.1` view contactmechanismpurposedescriptions as
select `echothree`.`contactmechanismpurposedescriptions`.`cmprd_contactmechanismpurposedescriptionid` AS `cmprd_contactmechanismpurposedescriptionid`,
       `echothree`.`contactmechanismpurposedescriptions`.`cmprd_cmpr_contactmechanismpurposeid`       AS `cmprd_cmpr_contactmechanismpurposeid`,
       `echothree`.`contactmechanismpurposedescriptions`.`cmprd_lang_languageid`                      AS `cmprd_lang_languageid`,
       `echothree`.`contactmechanismpurposedescriptions`.`cmprd_description`                          AS `cmprd_description`
from `echothree`.`contactmechanismpurposedescriptions`;

