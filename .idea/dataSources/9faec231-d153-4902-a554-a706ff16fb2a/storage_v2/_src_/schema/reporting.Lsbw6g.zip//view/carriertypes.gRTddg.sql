create definer = echothree@`127.0.0.1` view carriertypes as
select `echothree`.`carriertypes`.`crrtyp_carriertypeid`           AS `crrtyp_carriertypeid`,
       `echothree`.`carriertypedetails`.`crrtypdt_carriertypename` AS `crrtypdt_carriertypename`,
       `echothree`.`carriertypedetails`.`crrtypdt_isdefault`       AS `crrtypdt_isdefault`,
       `echothree`.`carriertypedetails`.`crrtypdt_sortorder`       AS `crrtypdt_sortorder`
from `echothree`.`carriertypes`
         join `echothree`.`carriertypedetails`
where (`echothree`.`carriertypes`.`crrtyp_activedetailid` =
       `echothree`.`carriertypedetails`.`crrtypdt_carriertypedetailid`);

