create definer = echothree@`127.0.0.1` view iconusagetypedescriptions as
select `echothree`.`iconusagetypedescriptions`.`icnutypd_iconusagetypedescriptionid` AS `icnutypd_iconusagetypedescriptionid`,
       `echothree`.`iconusagetypedescriptions`.`icnutypd_icnutyp_iconusagetypeid`    AS `icnutypd_icnutyp_iconusagetypeid`,
       `echothree`.`iconusagetypedescriptions`.`icnutypd_lang_languageid`            AS `icnutypd_lang_languageid`,
       `echothree`.`iconusagetypedescriptions`.`icnutypd_description`                AS `icnutypd_description`
from `echothree`.`iconusagetypedescriptions`
where (`echothree`.`iconusagetypedescriptions`.`icnutypd_thrutime` = 9223372036854775807);

