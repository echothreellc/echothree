create definer = echothree@`127.0.0.1` view entityencryptionkeys as
select `echothree`.`entityencryptionkeys`.`eek_entityencryptionkeyid`   AS `eek_entityencryptionkeyid`,
       `echothree`.`entityencryptionkeys`.`eek_entityencryptionkeyname` AS `eek_entityencryptionkeyname`,
       `echothree`.`entityencryptionkeys`.`eek_isexternal`              AS `eek_isexternal`,
       `echothree`.`entityencryptionkeys`.`eek_secretkey`               AS `eek_secretkey`,
       `echothree`.`entityencryptionkeys`.`eek_initializationvector`    AS `eek_initializationvector`
from `echothree`.`entityencryptionkeys`;

