create definer = echothree@`127.0.0.1` view entityattributeblobs as
select `echothree`.`entityattributeblobs`.`enab_entityattributeblobid`  AS `enab_entityattributeblobid`,
       `echothree`.`entityattributeblobs`.`enab_ena_entityattributeid`  AS `enab_ena_entityattributeid`,
       `echothree`.`entityattributeblobs`.`enab_checkcontentwebaddress` AS `enab_checkcontentwebaddress`
from `echothree`.`entityattributeblobs`
where (`echothree`.`entityattributeblobs`.`enab_thrutime` = 9223372036854775807);

