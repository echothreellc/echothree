create definer = echothree@`127.0.0.1` view glaccountsummaries as
select `echothree`.`glaccountsummaries`.`glasmy_glaccountsummaryid` AS `glasmy_glaccountsummaryid`,
       `echothree`.`glaccountsummaries`.`glasmy_gla_glaccountid`    AS `glasmy_gla_glaccountid`,
       `echothree`.`glaccountsummaries`.`glasmy_grouppartyid`       AS `glasmy_grouppartyid`,
       `echothree`.`glaccountsummaries`.`glasmy_prd_periodid`       AS `glasmy_prd_periodid`,
       `echothree`.`glaccountsummaries`.`glasmy_balance`            AS `glasmy_balance`
from `echothree`.`glaccountsummaries`;

