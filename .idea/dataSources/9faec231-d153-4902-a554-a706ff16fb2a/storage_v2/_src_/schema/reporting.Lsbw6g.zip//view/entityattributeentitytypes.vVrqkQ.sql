create definer = echothree@`127.0.0.1` view entityattributeentitytypes as
select `echothree`.`entityattributeentitytypes`.`enaent_entityattributeentitytypeid` AS `enaent_entityattributeentitytypeid`,
       `echothree`.`entityattributeentitytypes`.`enaent_ena_entityattributeid`       AS `enaent_ena_entityattributeid`,
       `echothree`.`entityattributeentitytypes`.`enaent_allowedentitytypeid`         AS `enaent_allowedentitytypeid`
from `echothree`.`entityattributeentitytypes`
where (`echothree`.`entityattributeentitytypes`.`enaent_thrutime` = 9223372036854775807);

