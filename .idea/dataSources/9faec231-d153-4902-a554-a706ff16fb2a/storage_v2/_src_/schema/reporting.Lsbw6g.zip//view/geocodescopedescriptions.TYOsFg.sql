create definer = echothree@`127.0.0.1` view geocodescopedescriptions as
select `echothree`.`geocodescopedescriptions`.`geosd_geocodescopedescriptionid` AS `geosd_geocodescopedescriptionid`,
       `echothree`.`geocodescopedescriptions`.`geosd_geos_geocodescopeid`       AS `geosd_geos_geocodescopeid`,
       `echothree`.`geocodescopedescriptions`.`geosd_lang_languageid`           AS `geosd_lang_languageid`,
       `echothree`.`geocodescopedescriptions`.`geosd_description`               AS `geosd_description`
from `echothree`.`geocodescopedescriptions`
where (`echothree`.`geocodescopedescriptions`.`geosd_thrutime` = 9223372036854775807);

