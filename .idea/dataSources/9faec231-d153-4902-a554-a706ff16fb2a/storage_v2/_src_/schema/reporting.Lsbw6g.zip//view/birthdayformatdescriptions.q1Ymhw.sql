create definer = echothree@`127.0.0.1` view birthdayformatdescriptions as
select `echothree`.`birthdayformatdescriptions`.`bdyfd_birthdayformatdescriptionid` AS `bdyfd_birthdayformatdescriptionid`,
       `echothree`.`birthdayformatdescriptions`.`bdyfd_bdyf_birthdayformatid`       AS `bdyfd_bdyf_birthdayformatid`,
       `echothree`.`birthdayformatdescriptions`.`bdyfd_lang_languageid`             AS `bdyfd_lang_languageid`,
       `echothree`.`birthdayformatdescriptions`.`bdyfd_description`                 AS `bdyfd_description`
from `echothree`.`birthdayformatdescriptions`
where (`echothree`.`birthdayformatdescriptions`.`bdyfd_thrutime` = 9223372036854775807);

