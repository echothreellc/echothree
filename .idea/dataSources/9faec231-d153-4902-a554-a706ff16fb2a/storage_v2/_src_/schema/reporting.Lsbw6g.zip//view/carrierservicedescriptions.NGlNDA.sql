create definer = echothree@`127.0.0.1` view carrierservicedescriptions as
select `echothree`.`carrierservicedescriptions`.`crrsrvd_carrierservicedescriptionid` AS `crrsrvd_carrierservicedescriptionid`,
       `echothree`.`carrierservicedescriptions`.`crrsrvd_crrsrv_carrierserviceid`     AS `crrsrvd_crrsrv_carrierserviceid`,
       `echothree`.`carrierservicedescriptions`.`crrsrvd_lang_languageid`             AS `crrsrvd_lang_languageid`,
       `echothree`.`carrierservicedescriptions`.`crrsrvd_description`                 AS `crrsrvd_description`
from `echothree`.`carrierservicedescriptions`
where (`echothree`.`carrierservicedescriptions`.`crrsrvd_thrutime` = 9223372036854775807);

