create definer = echothree@`127.0.0.1` view itemfixedprices as
select `echothree`.`itemfixedprices`.`itmfp_itemfixedpriceid` AS `itmfp_itemfixedpriceid`,
       `echothree`.`itemfixedprices`.`itmfp_itmp_itempriceid` AS `itmfp_itmp_itempriceid`,
       `echothree`.`itemfixedprices`.`itmfp_unitprice`        AS `itmfp_unitprice`
from `echothree`.`itemfixedprices`
where (`echothree`.`itemfixedprices`.`itmfp_thrutime` = 9223372036854775807);

