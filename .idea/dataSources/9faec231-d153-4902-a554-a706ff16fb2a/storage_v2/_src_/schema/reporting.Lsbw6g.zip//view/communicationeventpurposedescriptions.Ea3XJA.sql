create definer = echothree@`127.0.0.1` view communicationeventpurposedescriptions as
select `echothree`.`communicationeventpurposedescriptions`.`cmmnevprd_communicationeventpurposedescriptionid` AS `cmmnevprd_communicationeventpurposedescriptionid`,
       `echothree`.`communicationeventpurposedescriptions`.`cmmnevprd_cmmnevpr_communicationeventpurposeid`   AS `cmmnevprd_cmmnevpr_communicationeventpurposeid`,
       `echothree`.`communicationeventpurposedescriptions`.`cmmnevprd_lang_languageid`                        AS `cmmnevprd_lang_languageid`,
       `echothree`.`communicationeventpurposedescriptions`.`cmmnevprd_description`                            AS `cmmnevprd_description`
from `echothree`.`communicationeventpurposedescriptions`
where (`echothree`.`communicationeventpurposedescriptions`.`cmmnevprd_thrutime` = 9223372036854775807);

