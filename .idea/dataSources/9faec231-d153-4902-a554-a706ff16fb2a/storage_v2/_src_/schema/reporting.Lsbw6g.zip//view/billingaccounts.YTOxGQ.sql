create definer = echothree@`127.0.0.1` view billingaccounts as
select `echothree`.`billingaccounts`.`bllact_billingaccountid`           AS `bllact_billingaccountid`,
       `echothree`.`billingaccountdetails`.`bllactdt_billingaccountname` AS `bllactdt_billingaccountname`,
       `echothree`.`billingaccountdetails`.`bllactdt_cur_currencyid`     AS `bllactdt_cur_currencyid`,
       `echothree`.`billingaccountdetails`.`bllactdt_reference`          AS `bllactdt_reference`,
       `echothree`.`billingaccountdetails`.`bllactdt_description`        AS `bllactdt_description`
from `echothree`.`billingaccounts`
         join `echothree`.`billingaccountdetails`
where (`echothree`.`billingaccounts`.`bllact_activedetailid` =
       `echothree`.`billingaccountdetails`.`bllactdt_billingaccountdetailid`);

