create definer = echothree@`127.0.0.1` view invoices as
select `echothree`.`invoices`.`invc_invoiceid`                       AS `invc_invoiceid`,
       `echothree`.`invoicedetails`.`invcdt_invctyp_invoicetypeid`   AS `invcdt_invctyp_invoicetypeid`,
       `echothree`.`invoicedetails`.`invcdt_invoicename`             AS `invcdt_invoicename`,
       `echothree`.`invoicedetails`.`invcdt_bllact_billingaccountid` AS `invcdt_bllact_billingaccountid`,
       `echothree`.`invoicedetails`.`invcdt_gla_glaccountid`         AS `invcdt_gla_glaccountid`,
       `echothree`.`invoicedetails`.`invcdt_trm_termid`              AS `invcdt_trm_termid`,
       `echothree`.`invoicedetails`.`invcdt_fob_freeonboardid`       AS `invcdt_fob_freeonboardid`,
       `echothree`.`invoicedetails`.`invcdt_reference`               AS `invcdt_reference`,
       `echothree`.`invoicedetails`.`invcdt_description`             AS `invcdt_description`
from `echothree`.`invoices`
         join `echothree`.`invoicedetails`
where (`echothree`.`invoices`.`invc_activedetailid` = `echothree`.`invoicedetails`.`invcdt_invoicedetailid`);

