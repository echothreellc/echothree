create definer = echothree@`127.0.0.1` view commandmessagetranslations as
select `echothree`.`commandmessagetranslations`.`cmdmssgtr_commandmessagetranslationid` AS `cmdmssgtr_commandmessagetranslationid`,
       `echothree`.`commandmessagetranslations`.`cmdmssgtr_cmdmssg_commandmessageid`    AS `cmdmssgtr_cmdmssg_commandmessageid`,
       `echothree`.`commandmessagetranslations`.`cmdmssgtr_lang_languageid`             AS `cmdmssgtr_lang_languageid`,
       `echothree`.`commandmessagetranslations`.`cmdmssgtr_translation`                 AS `cmdmssgtr_translation`
from `echothree`.`commandmessagetranslations`
where (`echothree`.`commandmessagetranslations`.`cmdmssgtr_thrutime` = 9223372036854775807);

