create definer = echothree@`127.0.0.1` view itemusetypes as
select `echothree`.`itemusetypes`.`iutyp_itemusetypeid`   AS `iutyp_itemusetypeid`,
       `echothree`.`itemusetypes`.`iutyp_itemusetypename` AS `iutyp_itemusetypename`,
       `echothree`.`itemusetypes`.`iutyp_isdefault`       AS `iutyp_isdefault`,
       `echothree`.`itemusetypes`.`iutyp_sortorder`       AS `iutyp_sortorder`
from `echothree`.`itemusetypes`;

