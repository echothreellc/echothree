create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodeuses as
select `echothree`.`harmonizedtariffschedulecodeuses`.`hztscu_harmonizedtariffschedulecodeuseid`               AS `hztscu_harmonizedtariffschedulecodeuseid`,
       `echothree`.`harmonizedtariffschedulecodeuses`.`hztscu_hztsc_harmonizedtariffschedulecodeid`            AS `hztscu_hztsc_harmonizedtariffschedulecodeid`,
       `echothree`.`harmonizedtariffschedulecodeuses`.`hztscu_hztscutyp_harmonizedtariffschedulecodeusetypeid` AS `hztscu_hztscutyp_harmonizedtariffschedulecodeusetypeid`
from `echothree`.`harmonizedtariffschedulecodeuses`
where (`echothree`.`harmonizedtariffschedulecodeuses`.`hztscu_thrutime` = 9223372036854775807);

