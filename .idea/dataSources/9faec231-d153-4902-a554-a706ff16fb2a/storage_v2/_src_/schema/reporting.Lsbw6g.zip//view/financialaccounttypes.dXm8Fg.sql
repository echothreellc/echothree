create definer = echothree@`127.0.0.1` view financialaccounttypes as
select `echothree`.`financialaccounttypes`.`fnatyp_financialaccounttypeid`                            AS `fnatyp_financialaccounttypeid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccounttypename`                  AS `fnatypdt_financialaccounttypename`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_parentfinancialaccounttypeid`              AS `fnatypdt_parentfinancialaccounttypeid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_defaultglaccountid`                        AS `fnatypdt_defaultglaccountid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccountsequencetypeid`            AS `fnatypdt_financialaccountsequencetypeid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccounttransactionsequencetypeid` AS `fnatypdt_financialaccounttransactionsequencetypeid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccountworkflowid`                AS `fnatypdt_financialaccountworkflowid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccountworkflowentranceid`        AS `fnatypdt_financialaccountworkflowentranceid`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_isdefault`                                 AS `fnatypdt_isdefault`,
       `echothree`.`financialaccounttypedetails`.`fnatypdt_sortorder`                                 AS `fnatypdt_sortorder`
from `echothree`.`financialaccounttypes`
         join `echothree`.`financialaccounttypedetails`
where (`echothree`.`financialaccounttypes`.`fnatyp_activedetailid` =
       `echothree`.`financialaccounttypedetails`.`fnatypdt_financialaccounttypedetailid`);

