create definer = echothree@`127.0.0.1` view itempurchasingcategorydescriptions as
select `echothree`.`itempurchasingcategorydescriptions`.`iprchcd_itempurchasingcategorydescriptionid` AS `iprchcd_itempurchasingcategorydescriptionid`,
       `echothree`.`itempurchasingcategorydescriptions`.`iprchcd_iprchc_itempurchasingcategoryid`     AS `iprchcd_iprchc_itempurchasingcategoryid`,
       `echothree`.`itempurchasingcategorydescriptions`.`iprchcd_lang_languageid`                     AS `iprchcd_lang_languageid`,
       `echothree`.`itempurchasingcategorydescriptions`.`iprchcd_description`                         AS `iprchcd_description`
from `echothree`.`itempurchasingcategorydescriptions`
where (`echothree`.`itempurchasingcategorydescriptions`.`iprchcd_thrutime` = 9223372036854775807);

