create definer = echothree@`127.0.0.1` view forummessagetypeparttypes as
select `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_forummessagetypeparttypeid`          AS `frmmsgtypprttyp_forummessagetypeparttypeid`,
       `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_frmmsgtyp_forummessagetypeid`        AS `frmmsgtypprttyp_frmmsgtyp_forummessagetypeid`,
       `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_includeinindex`                      AS `frmmsgtypprttyp_includeinindex`,
       `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_indexdefault`                        AS `frmmsgtypprttyp_indexdefault`,
       `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_sortorder`                           AS `frmmsgtypprttyp_sortorder`,
       `echothree`.`forummessagetypeparttypes`.`frmmsgtypprttyp_frmmsgprttyp_forummessageparttypeid` AS `frmmsgtypprttyp_frmmsgprttyp_forummessageparttypeid`
from `echothree`.`forummessagetypeparttypes`;

