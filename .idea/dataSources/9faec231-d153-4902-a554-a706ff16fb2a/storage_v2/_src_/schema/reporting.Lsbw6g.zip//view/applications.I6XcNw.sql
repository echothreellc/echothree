create definer = echothree@`127.0.0.1` view applications as
select `echothree`.`applications`.`appl_applicationid`           AS `appl_applicationid`,
       `echothree`.`applicationdetails`.`appldt_applicationname` AS `appldt_applicationname`,
       `echothree`.`applicationdetails`.`appldt_isdefault`       AS `appldt_isdefault`,
       `echothree`.`applicationdetails`.`appldt_sortorder`       AS `appldt_sortorder`
from `echothree`.`applications`
         join `echothree`.`applicationdetails`
where (`echothree`.`applications`.`appl_activedetailid` =
       `echothree`.`applicationdetails`.`appldt_applicationdetailid`);

