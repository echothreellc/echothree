create definer = echothree@`127.0.0.1` view geocodecurrencies as
select `echothree`.`geocodecurrencies`.`geocur_geocodecurrencyid` AS `geocur_geocodecurrencyid`,
       `echothree`.`geocodecurrencies`.`geocur_geo_geocodeid`     AS `geocur_geo_geocodeid`,
       `echothree`.`geocodecurrencies`.`geocur_cur_currencyid`    AS `geocur_cur_currencyid`,
       `echothree`.`geocodecurrencies`.`geocur_isdefault`         AS `geocur_isdefault`,
       `echothree`.`geocodecurrencies`.`geocur_sortorder`         AS `geocur_sortorder`
from `echothree`.`geocodecurrencies`
where (`echothree`.`geocodecurrencies`.`geocur_thrutime` = 9223372036854775807);

