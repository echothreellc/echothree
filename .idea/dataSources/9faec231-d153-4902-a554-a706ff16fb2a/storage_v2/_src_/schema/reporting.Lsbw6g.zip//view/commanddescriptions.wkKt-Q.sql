create definer = echothree@`127.0.0.1` view commanddescriptions as
select `echothree`.`commanddescriptions`.`cmdd_commanddescriptionid` AS `cmdd_commanddescriptionid`,
       `echothree`.`commanddescriptions`.`cmdd_cmd_commandid`        AS `cmdd_cmd_commandid`,
       `echothree`.`commanddescriptions`.`cmdd_lang_languageid`      AS `cmdd_lang_languageid`,
       `echothree`.`commanddescriptions`.`cmdd_description`          AS `cmdd_description`
from `echothree`.`commanddescriptions`
where (`echothree`.`commanddescriptions`.`cmdd_thrutime` = 9223372036854775807);

