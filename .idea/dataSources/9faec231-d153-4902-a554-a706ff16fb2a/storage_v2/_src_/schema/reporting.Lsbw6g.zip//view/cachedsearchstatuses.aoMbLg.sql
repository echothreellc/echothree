create definer = echothree@`127.0.0.1` view cachedsearchstatuses as
select `echothree`.`cachedsearchstatuses`.`csrchst_cachedsearchstatusid` AS `csrchst_cachedsearchstatusid`,
       `echothree`.`cachedsearchstatuses`.`csrchst_csrch_cachedsearchid` AS `csrchst_csrch_cachedsearchid`,
       `echothree`.`cachedsearchstatuses`.`csrchst_isconsistent`         AS `csrchst_isconsistent`
from `echothree`.`cachedsearchstatuses`;

