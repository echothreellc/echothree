create definer = echothree@`127.0.0.1` view itemdescriptiontypeusetypedescriptions as
select `echothree`.`itemdescriptiontypeusetypedescriptions`.`idtutypd_itemdescriptiontypeusetypedescriptionid` AS `idtutypd_itemdescriptiontypeusetypedescriptionid`,
       `echothree`.`itemdescriptiontypeusetypedescriptions`.`idtutypd_idtutyp_itemdescriptiontypeusetypeid`    AS `idtutypd_idtutyp_itemdescriptiontypeusetypeid`,
       `echothree`.`itemdescriptiontypeusetypedescriptions`.`idtutypd_lang_languageid`                         AS `idtutypd_lang_languageid`,
       `echothree`.`itemdescriptiontypeusetypedescriptions`.`idtutypd_description`                             AS `idtutypd_description`
from `echothree`.`itemdescriptiontypeusetypedescriptions`
where (`echothree`.`itemdescriptiontypeusetypedescriptions`.`idtutypd_thrutime` = 9223372036854775807);

