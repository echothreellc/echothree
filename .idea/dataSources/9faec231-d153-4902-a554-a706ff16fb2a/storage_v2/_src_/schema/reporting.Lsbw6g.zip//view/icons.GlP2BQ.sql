create definer = echothree@`127.0.0.1` view icons as
select `echothree`.`icons`.`icn_iconid`                   AS `icn_iconid`,
       `echothree`.`icondetails`.`icndt_iconname`         AS `icndt_iconname`,
       `echothree`.`icondetails`.`icndt_dcmnt_documentid` AS `icndt_dcmnt_documentid`,
       `echothree`.`icondetails`.`icndt_isdefault`        AS `icndt_isdefault`,
       `echothree`.`icondetails`.`icndt_sortorder`        AS `icndt_sortorder`
from `echothree`.`icons`
         join `echothree`.`icondetails`
where (`echothree`.`icons`.`icn_activedetailid` = `echothree`.`icondetails`.`icndt_icondetailid`);

