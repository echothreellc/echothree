create definer = echothree@`127.0.0.1` view itempricetypes as
select `echothree`.`itempricetypes`.`ipt_itempricetypeid`   AS `ipt_itempricetypeid`,
       `echothree`.`itempricetypes`.`ipt_itempricetypename` AS `ipt_itempricetypename`,
       `echothree`.`itempricetypes`.`ipt_isdefault`         AS `ipt_isdefault`,
       `echothree`.`itempricetypes`.`ipt_sortorder`         AS `ipt_sortorder`
from `echothree`.`itempricetypes`;

