create definer = echothree@`127.0.0.1` view iconusages as
select `echothree`.`iconusages`.`icnu_iconusageid`             AS `icnu_iconusageid`,
       `echothree`.`iconusages`.`icnu_icnutyp_iconusagetypeid` AS `icnu_icnutyp_iconusagetypeid`,
       `echothree`.`iconusages`.`icnu_icn_iconid`              AS `icnu_icn_iconid`,
       `echothree`.`iconusages`.`icnu_isdefault`               AS `icnu_isdefault`,
       `echothree`.`iconusages`.`icnu_sortorder`               AS `icnu_sortorder`
from `echothree`.`iconusages`
where (`echothree`.`iconusages`.`icnu_thrutime` = 9223372036854775807);

