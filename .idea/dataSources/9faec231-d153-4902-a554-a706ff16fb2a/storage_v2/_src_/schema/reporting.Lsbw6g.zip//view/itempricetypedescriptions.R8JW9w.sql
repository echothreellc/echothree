create definer = echothree@`127.0.0.1` view itempricetypedescriptions as
select `echothree`.`itempricetypedescriptions`.`iptd_itempricetypedescriptionid` AS `iptd_itempricetypedescriptionid`,
       `echothree`.`itempricetypedescriptions`.`iptd_ipt_itempricetypeid`        AS `iptd_ipt_itempricetypeid`,
       `echothree`.`itempricetypedescriptions`.`iptd_lang_languageid`            AS `iptd_lang_languageid`,
       `echothree`.`itempricetypedescriptions`.`iptd_description`                AS `iptd_description`
from `echothree`.`itempricetypedescriptions`;

