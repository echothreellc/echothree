create definer = echothree@`127.0.0.1` view itemunitcustomertypelimits as
select `echothree`.`itemunitcustomertypelimits`.`iuctl_itemunitcustomertypelimitid` AS `iuctl_itemunitcustomertypelimitid`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_itm_itemid`                  AS `iuctl_itm_itemid`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_invcon_inventoryconditionid` AS `iuctl_invcon_inventoryconditionid`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_uomt_unitofmeasuretypeid`    AS `iuctl_uomt_unitofmeasuretypeid`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_cuty_customertypeid`         AS `iuctl_cuty_customertypeid`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_minimumquantity`             AS `iuctl_minimumquantity`,
       `echothree`.`itemunitcustomertypelimits`.`iuctl_maximumquantity`             AS `iuctl_maximumquantity`
from `echothree`.`itemunitcustomertypelimits`
where (`echothree`.`itemunitcustomertypelimits`.`iuctl_thrutime` = 9223372036854775807);

