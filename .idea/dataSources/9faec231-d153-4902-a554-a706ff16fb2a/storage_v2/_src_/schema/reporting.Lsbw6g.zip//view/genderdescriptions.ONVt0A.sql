create definer = echothree@`127.0.0.1` view genderdescriptions as
select `echothree`.`genderdescriptions`.`gndrd_genderdescriptionid` AS `gndrd_genderdescriptionid`,
       `echothree`.`genderdescriptions`.`gndrd_gndr_genderid`       AS `gndrd_gndr_genderid`,
       `echothree`.`genderdescriptions`.`gndrd_lang_languageid`     AS `gndrd_lang_languageid`,
       `echothree`.`genderdescriptions`.`gndrd_description`         AS `gndrd_description`
from `echothree`.`genderdescriptions`
where (`echothree`.`genderdescriptions`.`gndrd_thrutime` = 9223372036854775807);

