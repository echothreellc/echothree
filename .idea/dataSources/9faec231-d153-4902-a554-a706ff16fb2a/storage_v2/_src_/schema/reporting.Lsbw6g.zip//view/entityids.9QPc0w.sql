create definer = echothree@`127.0.0.1` view entityids as
select `echothree`.`entityids`.`eid_componentvendorname` AS `eid_componentvendorname`,
       `echothree`.`entityids`.`eid_entitytypename`      AS `eid_entitytypename`,
       `echothree`.`entityids`.`eid_lastentityid`        AS `eid_lastentityid`
from `echothree`.`entityids`;

