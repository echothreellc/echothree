create definer = echothree@`127.0.0.1` view associatepartycontactmechanisms as
select `echothree`.`associatepartycontactmechanisms`.`ascpcm_associatepartycontactmechanismid`           AS `ascpcm_associatepartycontactmechanismid`,
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_asc_associateid`                    AS `ascpcmdt_asc_associateid`,
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_associatepartycontactmechanismname` AS `ascpcmdt_associatepartycontactmechanismname`,
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_pcm_partycontactmechanismid`        AS `ascpcmdt_pcm_partycontactmechanismid`,
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_isdefault`                          AS `ascpcmdt_isdefault`,
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_sortorder`                          AS `ascpcmdt_sortorder`
from `echothree`.`associatepartycontactmechanisms`
         join `echothree`.`associatepartycontactmechanismdetails`
where (`echothree`.`associatepartycontactmechanisms`.`ascpcm_activedetailid` =
       `echothree`.`associatepartycontactmechanismdetails`.`ascpcmdt_associatepartycontactmechanismdetailid`);

