create definer = echothree@`127.0.0.1` view itemkitoptions as
select `echothree`.`itemkitoptions`.`ikopt_itemkitoptionid`       AS `ikopt_itemkitoptionid`,
       `echothree`.`itemkitoptions`.`ikopt_itm_itemid`            AS `ikopt_itm_itemid`,
       `echothree`.`itemkitoptions`.`ikopt_allowpartialshipments` AS `ikopt_allowpartialshipments`
from `echothree`.`itemkitoptions`
where (`echothree`.`itemkitoptions`.`ikopt_thrutime` = 9223372036854775807);

