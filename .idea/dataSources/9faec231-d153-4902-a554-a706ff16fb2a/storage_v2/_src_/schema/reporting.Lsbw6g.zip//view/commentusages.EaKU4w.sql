create definer = echothree@`127.0.0.1` view commentusages as
select `echothree`.`commentusages`.`cmntu_commentusageid`              AS `cmntu_commentusageid`,
       `echothree`.`commentusages`.`cmntu_cmnt_commentid`              AS `cmntu_cmnt_commentid`,
       `echothree`.`commentusages`.`cmntu_cmntutyp_commentusagetypeid` AS `cmntu_cmntutyp_commentusagetypeid`
from `echothree`.`commentusages`
where (`echothree`.`commentusages`.`cmntu_thrutime` = 9223372036854775807);

