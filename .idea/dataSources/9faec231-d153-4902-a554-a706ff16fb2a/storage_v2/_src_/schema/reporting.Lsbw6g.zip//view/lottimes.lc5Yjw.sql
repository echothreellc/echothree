create definer = echothree@`127.0.0.1` view lottimes as
select `echothree`.`lottimes`.`lttim_lottimeid`              AS `lttim_lottimeid`,
       `echothree`.`lottimes`.`lttim_lt_lotid`               AS `lttim_lt_lotid`,
       `echothree`.`lottimes`.`lttim_lttimtyp_lottimetypeid` AS `lttim_lttimtyp_lottimetypeid`,
       `echothree`.`lottimes`.`lttim_time`                   AS `lttim_time`
from `echothree`.`lottimes`
where (`echothree`.`lottimes`.`lttim_thrutime` = 9223372036854775807);

