create definer = echothree@`127.0.0.1` view financialaccountstatuses as
select `echothree`.`financialaccountstatuses`.`finast_financialaccountstatusid` AS `finast_financialaccountstatusid`,
       `echothree`.`financialaccountstatuses`.`finast_fina_financialaccountid`  AS `finast_fina_financialaccountid`,
       `echothree`.`financialaccountstatuses`.`finast_actualbalance`            AS `finast_actualbalance`,
       `echothree`.`financialaccountstatuses`.`finast_availablebalance`         AS `finast_availablebalance`
from `echothree`.`financialaccountstatuses`;

