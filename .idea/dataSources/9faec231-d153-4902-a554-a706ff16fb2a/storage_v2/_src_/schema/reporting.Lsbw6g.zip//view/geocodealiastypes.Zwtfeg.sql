create definer = echothree@`127.0.0.1` view geocodealiastypes as
select `echothree`.`geocodealiastypes`.`geoat_geocodealiastypeid`           AS `geoat_geocodealiastypeid`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_geot_geocodetypeid`   AS `geoatdt_geot_geocodetypeid`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_geocodealiastypename` AS `geoatdt_geocodealiastypename`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_validationpattern`    AS `geoatdt_validationpattern`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_isrequired`           AS `geoatdt_isrequired`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_isdefault`            AS `geoatdt_isdefault`,
       `echothree`.`geocodealiastypedetails`.`geoatdt_sortorder`            AS `geoatdt_sortorder`
from `echothree`.`geocodealiastypes`
         join `echothree`.`geocodealiastypedetails`
where (`echothree`.`geocodealiastypes`.`geoat_activedetailid` =
       `echothree`.`geocodealiastypedetails`.`geoatdt_geocodealiastypedetailid`);

