create definer = echothree@`127.0.0.1` view financialaccountroletypedescriptions as
select `echothree`.`financialaccountroletypedescriptions`.`finatypd_financialaccountroletypedescriptionid` AS `finatypd_financialaccountroletypedescriptionid`,
       `echothree`.`financialaccountroletypedescriptions`.`finatypd_finatyp_financialaccountroletypeid`    AS `finatypd_finatyp_financialaccountroletypeid`,
       `echothree`.`financialaccountroletypedescriptions`.`finatypd_lang_languageid`                       AS `finatypd_lang_languageid`,
       `echothree`.`financialaccountroletypedescriptions`.`finatypd_description`                           AS `finatypd_description`
from `echothree`.`financialaccountroletypedescriptions`;

