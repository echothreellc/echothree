create definer = echothree@`127.0.0.1` view forumpartytyperoles as
select `echothree`.`forumpartytyperoles`.`frmptypr_forumpartytyperoleid`    AS `frmptypr_forumpartytyperoleid`,
       `echothree`.`forumpartytyperoles`.`frmptypr_frm_forumid`             AS `frmptypr_frm_forumid`,
       `echothree`.`forumpartytyperoles`.`frmptypr_ptyp_partytypeid`        AS `frmptypr_ptyp_partytypeid`,
       `echothree`.`forumpartytyperoles`.`frmptypr_frmrtyp_forumroletypeid` AS `frmptypr_frmrtyp_forumroletypeid`
from `echothree`.`forumpartytyperoles`
where (`echothree`.`forumpartytyperoles`.`frmptypr_thrutime` = 9223372036854775807);

