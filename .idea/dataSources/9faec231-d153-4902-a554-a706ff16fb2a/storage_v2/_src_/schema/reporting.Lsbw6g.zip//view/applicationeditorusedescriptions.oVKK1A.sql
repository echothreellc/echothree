create definer = echothree@`127.0.0.1` view applicationeditorusedescriptions as
select `echothree`.`applicationeditorusedescriptions`.`appledtrused_applicationeditorusedescriptionid`  AS `appledtrused_applicationeditorusedescriptionid`,
       `echothree`.`applicationeditorusedescriptions`.`appledtrused_appledtruse_applicationeditoruseid` AS `appledtrused_appledtruse_applicationeditoruseid`,
       `echothree`.`applicationeditorusedescriptions`.`appledtrused_lang_languageid`                    AS `appledtrused_lang_languageid`,
       `echothree`.`applicationeditorusedescriptions`.`appledtrused_description`                        AS `appledtrused_description`
from `echothree`.`applicationeditorusedescriptions`
where (`echothree`.`applicationeditorusedescriptions`.`appledtrused_thrutime` = 9223372036854775807);

