create definer = echothree@`127.0.0.1` view inventorylocationgroupcapacities as
select `echothree`.`inventorylocationgroupcapacities`.`invlocgrpcap_inventorylocationgroupcapacityid`   AS `invlocgrpcap_inventorylocationgroupcapacityid`,
       `echothree`.`inventorylocationgroupcapacities`.`invlocgrpcap_invlocgrp_inventorylocationgroupid` AS `invlocgrpcap_invlocgrp_inventorylocationgroupid`,
       `echothree`.`inventorylocationgroupcapacities`.`invlocgrpcap_uomt_unitofmeasuretypeid`           AS `invlocgrpcap_uomt_unitofmeasuretypeid`,
       `echothree`.`inventorylocationgroupcapacities`.`invlocgrpcap_capacity`                           AS `invlocgrpcap_capacity`
from `echothree`.`inventorylocationgroupcapacities`
where (`echothree`.`inventorylocationgroupcapacities`.`invlocgrpcap_thrutime` = 9223372036854775807);

