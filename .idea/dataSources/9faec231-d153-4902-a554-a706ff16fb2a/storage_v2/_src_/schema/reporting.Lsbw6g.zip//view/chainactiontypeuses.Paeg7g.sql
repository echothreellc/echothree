create definer = echothree@`127.0.0.1` view chainactiontypeuses as
select `echothree`.`chainactiontypeuses`.`chnacttypu_chainactiontypeuseid`        AS `chnacttypu_chainactiontypeuseid`,
       `echothree`.`chainactiontypeuses`.`chnacttypu_chnk_chainkindid`            AS `chnacttypu_chnk_chainkindid`,
       `echothree`.`chainactiontypeuses`.`chnacttypu_chnacttyp_chainactiontypeid` AS `chnacttypu_chnacttyp_chainactiontypeid`,
       `echothree`.`chainactiontypeuses`.`chnacttypu_isdefault`                   AS `chnacttypu_isdefault`
from `echothree`.`chainactiontypeuses`;

