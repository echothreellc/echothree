create definer = echothree@`127.0.0.1` view documents as
select `echothree`.`documents`.`dcmnt_documentid`                      AS `dcmnt_documentid`,
       `echothree`.`documentdetails`.`dcmntdt_documentname`            AS `dcmntdt_documentname`,
       `echothree`.`documentdetails`.`dcmntdt_dcmnttyp_documenttypeid` AS `dcmntdt_dcmnttyp_documenttypeid`,
       `echothree`.`documentdetails`.`dcmntdt_mtyp_mimetypeid`         AS `dcmntdt_mtyp_mimetypeid`,
       `echothree`.`documentdetails`.`dcmntdt_pages`                   AS `dcmntdt_pages`
from `echothree`.`documents`
         join `echothree`.`documentdetails`
where (`echothree`.`documents`.`dcmnt_activedetailid` = `echothree`.`documentdetails`.`dcmntdt_documentdetailid`);

