create definer = echothree@`127.0.0.1` view itemkitmembers as
select `echothree`.`itemkitmembers`.`ikm_itemkitmemberid`             AS `ikm_itemkitmemberid`,
       `echothree`.`itemkitmembers`.`ikm_itm_itemid`                  AS `ikm_itm_itemid`,
       `echothree`.`itemkitmembers`.`ikm_invcon_inventoryconditionid` AS `ikm_invcon_inventoryconditionid`,
       `echothree`.`itemkitmembers`.`ikm_uomt_unitofmeasuretypeid`    AS `ikm_uomt_unitofmeasuretypeid`,
       `echothree`.`itemkitmembers`.`ikm_memberitemid`                AS `ikm_memberitemid`,
       `echothree`.`itemkitmembers`.`ikm_memberinventoryconditionid`  AS `ikm_memberinventoryconditionid`,
       `echothree`.`itemkitmembers`.`ikm_memberunitofmeasuretypeid`   AS `ikm_memberunitofmeasuretypeid`,
       `echothree`.`itemkitmembers`.`ikm_quantity`                    AS `ikm_quantity`
from `echothree`.`itemkitmembers`
where (`echothree`.`itemkitmembers`.`ikm_thrutime` = 9223372036854775807);

