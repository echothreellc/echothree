create definer = echothree@`127.0.0.1` view currencydescriptions as
select `echothree`.`currencydescriptions`.`curd_currencydescriptionid` AS `curd_currencydescriptionid`,
       `echothree`.`currencydescriptions`.`curd_cur_currencyid`        AS `curd_cur_currencyid`,
       `echothree`.`currencydescriptions`.`curd_lang_languageid`       AS `curd_lang_languageid`,
       `echothree`.`currencydescriptions`.`curd_description`           AS `curd_description`
from `echothree`.`currencydescriptions`;

