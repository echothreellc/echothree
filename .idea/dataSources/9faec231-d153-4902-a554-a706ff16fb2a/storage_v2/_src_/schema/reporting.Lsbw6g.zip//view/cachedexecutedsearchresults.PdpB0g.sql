create definer = echothree@`127.0.0.1` view cachedexecutedsearchresults as
select `echothree`.`cachedexecutedsearchresults`.`cxsrchr_cachedexecutedsearchresultid`  AS `cxsrchr_cachedexecutedsearchresultid`,
       `echothree`.`cachedexecutedsearchresults`.`cxsrchr_cxsrch_cachedexecutedsearchid` AS `cxsrchr_cxsrch_cachedexecutedsearchid`,
       `echothree`.`cachedexecutedsearchresults`.`cxsrchr_eni_entityinstanceid`          AS `cxsrchr_eni_entityinstanceid`,
       `echothree`.`cachedexecutedsearchresults`.`cxsrchr_sortorder`                     AS `cxsrchr_sortorder`
from `echothree`.`cachedexecutedsearchresults`;

