create definer = echothree@`127.0.0.1` view itemadditionalchargetypedescriptions as
select `echothree`.`itemadditionalchargetypedescriptions`.`itmaddtlctd_itemadditionalchargetypedescriptionid` AS `itmaddtlctd_itemadditionalchargetypedescriptionid`,
       `echothree`.`itemadditionalchargetypedescriptions`.`itmaddtlctd_itmaddtlct_itemadditionalchargetypeid` AS `itmaddtlctd_itmaddtlct_itemadditionalchargetypeid`,
       `echothree`.`itemadditionalchargetypedescriptions`.`itmaddtlctd_lang_languageid`                       AS `itmaddtlctd_lang_languageid`,
       `echothree`.`itemadditionalchargetypedescriptions`.`itmaddtlctd_description`                           AS `itmaddtlctd_description`
from `echothree`.`itemadditionalchargetypedescriptions`
where (`echothree`.`itemadditionalchargetypedescriptions`.`itmaddtlctd_thrutime` = 9223372036854775807);

