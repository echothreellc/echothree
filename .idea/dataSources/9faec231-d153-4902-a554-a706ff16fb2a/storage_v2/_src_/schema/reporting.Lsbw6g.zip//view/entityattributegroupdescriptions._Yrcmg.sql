create definer = echothree@`127.0.0.1` view entityattributegroupdescriptions as
select `echothree`.`entityattributegroupdescriptions`.`enagpd_entityattributegroupdescriptionid` AS `enagpd_entityattributegroupdescriptionid`,
       `echothree`.`entityattributegroupdescriptions`.`enagpd_enagp_entityattributegroupid`      AS `enagpd_enagp_entityattributegroupid`,
       `echothree`.`entityattributegroupdescriptions`.`enagpd_lang_languageid`                   AS `enagpd_lang_languageid`,
       `echothree`.`entityattributegroupdescriptions`.`enagpd_description`                       AS `enagpd_description`
from `echothree`.`entityattributegroupdescriptions`
where (`echothree`.`entityattributegroupdescriptions`.`enagpd_thrutime` = 9223372036854775807);

