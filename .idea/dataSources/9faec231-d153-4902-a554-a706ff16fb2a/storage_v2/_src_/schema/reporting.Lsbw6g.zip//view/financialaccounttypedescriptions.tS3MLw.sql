create definer = echothree@`127.0.0.1` view financialaccounttypedescriptions as
select `echothree`.`financialaccounttypedescriptions`.`fnatypd_financialaccounttypedescriptionid` AS `fnatypd_financialaccounttypedescriptionid`,
       `echothree`.`financialaccounttypedescriptions`.`fnatypd_fnatyp_financialaccounttypeid`     AS `fnatypd_fnatyp_financialaccounttypeid`,
       `echothree`.`financialaccounttypedescriptions`.`fnatypd_lang_languageid`                   AS `fnatypd_lang_languageid`,
       `echothree`.`financialaccounttypedescriptions`.`fnatypd_description`                       AS `fnatypd_description`
from `echothree`.`financialaccounttypedescriptions`
where (`echothree`.`financialaccounttypedescriptions`.`fnatypd_thrutime` = 9223372036854775807);

