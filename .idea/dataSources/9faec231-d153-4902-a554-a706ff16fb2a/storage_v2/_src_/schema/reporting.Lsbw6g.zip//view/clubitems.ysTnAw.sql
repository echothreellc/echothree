create definer = echothree@`127.0.0.1` view clubitems as
select `echothree`.`clubitems`.`clbitm_clubitemid`               AS `clbitm_clubitemid`,
       `echothree`.`clubitems`.`clbitm_clb_clubid`               AS `clbitm_clb_clubid`,
       `echothree`.`clubitems`.`clbitm_clbitmtyp_clubitemtypeid` AS `clbitm_clbitmtyp_clubitemtypeid`,
       `echothree`.`clubitems`.`clbitm_itm_itemid`               AS `clbitm_itm_itemid`,
       `echothree`.`clubitems`.`clbitm_subscriptiontime`         AS `clbitm_subscriptiontime`
from `echothree`.`clubitems`
where (`echothree`.`clubitems`.`clbitm_thrutime` = 9223372036854775807);

