create definer = echothree@`127.0.0.1` view forummessagetypes as
select `echothree`.`forummessagetypes`.`frmmsgtyp_forummessagetypeid`   AS `frmmsgtyp_forummessagetypeid`,
       `echothree`.`forummessagetypes`.`frmmsgtyp_forummessagetypename` AS `frmmsgtyp_forummessagetypename`,
       `echothree`.`forummessagetypes`.`frmmsgtyp_isdefault`            AS `frmmsgtyp_isdefault`,
       `echothree`.`forummessagetypes`.`frmmsgtyp_sortorder`            AS `frmmsgtyp_sortorder`
from `echothree`.`forummessagetypes`;

