create definer = echothree@`127.0.0.1` view financialaccountroletypes as
select `echothree`.`financialaccountroletypes`.`finatyp_financialaccountroletypeid`   AS `finatyp_financialaccountroletypeid`,
       `echothree`.`financialaccountroletypes`.`finatyp_financialaccountroletypename` AS `finatyp_financialaccountroletypename`,
       `echothree`.`financialaccountroletypes`.`finatyp_sortorder`                    AS `finatyp_sortorder`
from `echothree`.`financialaccountroletypes`;

