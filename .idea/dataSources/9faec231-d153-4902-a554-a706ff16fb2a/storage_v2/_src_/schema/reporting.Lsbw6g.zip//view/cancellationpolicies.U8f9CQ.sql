create definer = echothree@`127.0.0.1` view cancellationpolicies as
select `echothree`.`cancellationpolicies`.`cnclplcy_cancellationpolicyid`            AS `cnclplcy_cancellationpolicyid`,
       `echothree`.`cancellationpolicydetails`.`cnclplcydt_cnclk_cancellationkindid` AS `cnclplcydt_cnclk_cancellationkindid`,
       `echothree`.`cancellationpolicydetails`.`cnclplcydt_cancellationpolicyname`   AS `cnclplcydt_cancellationpolicyname`,
       `echothree`.`cancellationpolicydetails`.`cnclplcydt_isdefault`                AS `cnclplcydt_isdefault`,
       `echothree`.`cancellationpolicydetails`.`cnclplcydt_sortorder`                AS `cnclplcydt_sortorder`
from `echothree`.`cancellationpolicies`
         join `echothree`.`cancellationpolicydetails`
where (`echothree`.`cancellationpolicies`.`cnclplcy_activedetailid` =
       `echothree`.`cancellationpolicydetails`.`cnclplcydt_cancellationpolicydetailid`);

