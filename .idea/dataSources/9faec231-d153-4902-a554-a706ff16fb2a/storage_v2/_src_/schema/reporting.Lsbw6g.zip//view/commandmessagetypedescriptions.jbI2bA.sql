create definer = echothree@`127.0.0.1` view commandmessagetypedescriptions as
select `echothree`.`commandmessagetypedescriptions`.`cmdmssgtyd_commandmessagetypedescriptionid` AS `cmdmssgtyd_commandmessagetypedescriptionid`,
       `echothree`.`commandmessagetypedescriptions`.`cmdmssgtyd_cmdmssgty_commandmessagetypeid`  AS `cmdmssgtyd_cmdmssgty_commandmessagetypeid`,
       `echothree`.`commandmessagetypedescriptions`.`cmdmssgtyd_lang_languageid`                 AS `cmdmssgtyd_lang_languageid`,
       `echothree`.`commandmessagetypedescriptions`.`cmdmssgtyd_description`                     AS `cmdmssgtyd_description`
from `echothree`.`commandmessagetypedescriptions`
where (`echothree`.`commandmessagetypedescriptions`.`cmdmssgtyd_thrutime` = 9223372036854775807);

