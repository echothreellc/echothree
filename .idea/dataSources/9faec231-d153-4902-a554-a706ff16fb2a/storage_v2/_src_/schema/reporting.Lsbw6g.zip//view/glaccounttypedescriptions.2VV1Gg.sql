create definer = echothree@`127.0.0.1` view glaccounttypedescriptions as
select `echothree`.`glaccounttypedescriptions`.`glatypd_glaccounttypedescriptionid` AS `glatypd_glaccounttypedescriptionid`,
       `echothree`.`glaccounttypedescriptions`.`glatypd_glatyp_glaccounttypeid`     AS `glatypd_glatyp_glaccounttypeid`,
       `echothree`.`glaccounttypedescriptions`.`glatypd_lang_languageid`            AS `glatypd_lang_languageid`,
       `echothree`.`glaccounttypedescriptions`.`glatypd_description`                AS `glatypd_description`
from `echothree`.`glaccounttypedescriptions`;

