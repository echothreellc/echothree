create definer = echothree@`127.0.0.1` view itemunitpricelimits as
select `echothree`.`itemunitpricelimits`.`iupl_itemunitpricelimitid`        AS `iupl_itemunitpricelimitid`,
       `echothree`.`itemunitpricelimits`.`iupl_itm_itemid`                  AS `iupl_itm_itemid`,
       `echothree`.`itemunitpricelimits`.`iupl_invcon_inventoryconditionid` AS `iupl_invcon_inventoryconditionid`,
       `echothree`.`itemunitpricelimits`.`iupl_uomt_unitofmeasuretypeid`    AS `iupl_uomt_unitofmeasuretypeid`,
       `echothree`.`itemunitpricelimits`.`iupl_cur_currencyid`              AS `iupl_cur_currencyid`,
       `echothree`.`itemunitpricelimits`.`iupl_minimumunitprice`            AS `iupl_minimumunitprice`,
       `echothree`.`itemunitpricelimits`.`iupl_maximumunitprice`            AS `iupl_maximumunitprice`
from `echothree`.`itemunitpricelimits`
where (`echothree`.`itemunitpricelimits`.`iupl_thrutime` = 9223372036854775807);

