create definer = echothree@`127.0.0.1` view entityattributetypedescriptions as
select `echothree`.`entityattributetypedescriptions`.`enatd_entityattributetypedescriptionid` AS `enatd_entityattributetypedescriptionid`,
       `echothree`.`entityattributetypedescriptions`.`enatd_enat_entityattributetypeid`       AS `enatd_enat_entityattributetypeid`,
       `echothree`.`entityattributetypedescriptions`.`enatd_lang_languageid`                  AS `enatd_lang_languageid`,
       `echothree`.`entityattributetypedescriptions`.`enatd_description`                      AS `enatd_description`
from `echothree`.`entityattributetypedescriptions`;

