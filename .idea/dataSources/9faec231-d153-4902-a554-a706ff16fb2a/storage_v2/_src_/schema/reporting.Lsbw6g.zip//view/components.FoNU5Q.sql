create definer = echothree@`127.0.0.1` view components as
select `echothree`.`components`.`cpnt_componentid`                   AS `cpnt_componentid`,
       `echothree`.`componentdetails`.`cpntd_cvnd_componentvendorid` AS `cpntd_cvnd_componentvendorid`,
       `echothree`.`componentdetails`.`cpntd_componentname`          AS `cpntd_componentname`,
       `echothree`.`componentdetails`.`cpntd_description`            AS `cpntd_description`
from `echothree`.`components`
         join `echothree`.`componentdetails`
where (`echothree`.`components`.`cpnt_activedetailid` = `echothree`.`componentdetails`.`cpntd_componentdetailid`);

