create definer = echothree@`127.0.0.1` view communicationeventroletypedescriptions as
select `echothree`.`communicationeventroletypedescriptions`.`cmmnevrtypd_communicationeventroletypedescriptionid` AS `cmmnevrtypd_communicationeventroletypedescriptionid`,
       `echothree`.`communicationeventroletypedescriptions`.`cmmnevrtypd_cmmnevrtyp_communicationeventroletypeid` AS `cmmnevrtypd_cmmnevrtyp_communicationeventroletypeid`,
       `echothree`.`communicationeventroletypedescriptions`.`cmmnevrtypd_lang_languageid`                         AS `cmmnevrtypd_lang_languageid`,
       `echothree`.`communicationeventroletypedescriptions`.`cmmnevrtypd_description`                             AS `cmmnevrtypd_description`
from `echothree`.`communicationeventroletypedescriptions`;

