create definer = echothree@`127.0.0.1` view componentvendors as
select `echothree`.`componentvendors`.`cvnd_componentvendorid`          AS `cvnd_componentvendorid`,
       `echothree`.`componentvendordetails`.`cvndd_componentvendorname` AS `cvndd_componentvendorname`,
       `echothree`.`componentvendordetails`.`cvndd_description`         AS `cvndd_description`
from `echothree`.`componentvendors`
         join `echothree`.`componentvendordetails`
where (`echothree`.`componentvendors`.`cvnd_activedetailid` =
       `echothree`.`componentvendordetails`.`cvndd_componentvendordetailid`);

