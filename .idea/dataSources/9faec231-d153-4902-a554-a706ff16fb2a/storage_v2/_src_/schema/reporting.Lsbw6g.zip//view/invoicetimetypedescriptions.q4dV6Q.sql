create definer = echothree@`127.0.0.1` view invoicetimetypedescriptions as
select `echothree`.`invoicetimetypedescriptions`.`invctimtypd_invoicetimetypedescriptionid` AS `invctimtypd_invoicetimetypedescriptionid`,
       `echothree`.`invoicetimetypedescriptions`.`invctimtypd_invctimtyp_invoicetimetypeid` AS `invctimtypd_invctimtyp_invoicetimetypeid`,
       `echothree`.`invoicetimetypedescriptions`.`invctimtypd_lang_languageid`              AS `invctimtypd_lang_languageid`,
       `echothree`.`invoicetimetypedescriptions`.`invctimtypd_description`                  AS `invctimtypd_description`
from `echothree`.`invoicetimetypedescriptions`
where (`echothree`.`invoicetimetypedescriptions`.`invctimtypd_thrutime` = 9223372036854775807);

