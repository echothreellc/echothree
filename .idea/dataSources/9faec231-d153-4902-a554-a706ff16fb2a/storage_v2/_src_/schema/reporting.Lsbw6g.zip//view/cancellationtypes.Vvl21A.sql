create definer = echothree@`127.0.0.1` view cancellationtypes as
select `echothree`.`cancellationtypes`.`cncltyp_cancellationtypeid`               AS `cncltyp_cancellationtypeid`,
       `echothree`.`cancellationtypedetails`.`cncltypdt_cnclk_cancellationkindid` AS `cncltypdt_cnclk_cancellationkindid`,
       `echothree`.`cancellationtypedetails`.`cncltypdt_cancellationtypename`     AS `cncltypdt_cancellationtypename`,
       `echothree`.`cancellationtypedetails`.`cncltypdt_cancellationsequenceid`   AS `cncltypdt_cancellationsequenceid`,
       `echothree`.`cancellationtypedetails`.`cncltypdt_isdefault`                AS `cncltypdt_isdefault`,
       `echothree`.`cancellationtypedetails`.`cncltypdt_sortorder`                AS `cncltypdt_sortorder`
from `echothree`.`cancellationtypes`
         join `echothree`.`cancellationtypedetails`
where (`echothree`.`cancellationtypes`.`cncltyp_activedetailid` =
       `echothree`.`cancellationtypedetails`.`cncltypdt_cancellationtypedetailid`);

