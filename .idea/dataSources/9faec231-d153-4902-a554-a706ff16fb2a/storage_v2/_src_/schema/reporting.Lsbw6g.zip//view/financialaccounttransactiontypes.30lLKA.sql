create definer = echothree@`127.0.0.1` view financialaccounttransactiontypes as
select `echothree`.`financialaccounttransactiontypes`.`fnatrxtyp_financialaccounttransactiontypeid`               AS `fnatrxtyp_financialaccounttransactiontypeid`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_fnatyp_financialaccounttypeid`           AS `fnatrxtypdt_fnatyp_financialaccounttypeid`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_financialaccounttransactiontypename`     AS `fnatrxtypdt_financialaccounttransactiontypename`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_parentfinancialaccounttransactiontypeid` AS `fnatrxtypdt_parentfinancialaccounttransactiontypeid`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_gla_glaccountid`                         AS `fnatrxtypdt_gla_glaccountid`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_isdefault`                               AS `fnatrxtypdt_isdefault`,
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_sortorder`                               AS `fnatrxtypdt_sortorder`
from `echothree`.`financialaccounttransactiontypes`
         join `echothree`.`financialaccounttransactiontypedetails`
where (`echothree`.`financialaccounttransactiontypes`.`fnatrxtyp_activedetailid` =
       `echothree`.`financialaccounttransactiontypedetails`.`fnatrxtypdt_financialaccounttransactiontypedetailid`);

