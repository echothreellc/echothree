create definer = echothree@`127.0.0.1` view cancellationpolicyreasons as
select `echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_cancellationpolicyreasonid`    AS `cnclplcyrsn_cancellationpolicyreasonid`,
       `echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_cnclplcy_cancellationpolicyid` AS `cnclplcyrsn_cnclplcy_cancellationpolicyid`,
       `echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_cnclrsn_cancellationreasonid`  AS `cnclplcyrsn_cnclrsn_cancellationreasonid`,
       `echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_isdefault`                     AS `cnclplcyrsn_isdefault`,
       `echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_sortorder`                     AS `cnclplcyrsn_sortorder`
from `echothree`.`cancellationpolicyreasons`
where (`echothree`.`cancellationpolicyreasons`.`cnclplcyrsn_thrutime` = 9223372036854775807);

