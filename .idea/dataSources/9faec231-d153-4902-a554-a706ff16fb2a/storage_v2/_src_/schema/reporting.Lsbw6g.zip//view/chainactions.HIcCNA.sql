create definer = echothree@`127.0.0.1` view chainactions as
select `echothree`.`chainactions`.`chnact_chainactionid`                       AS `chnact_chainactionid`,
       `echothree`.`chainactiondetails`.`chnactdt_chnactst_chainactionsetid`   AS `chnactdt_chnactst_chainactionsetid`,
       `echothree`.`chainactiondetails`.`chnactdt_chainactionname`             AS `chnactdt_chainactionname`,
       `echothree`.`chainactiondetails`.`chnactdt_chnacttyp_chainactiontypeid` AS `chnactdt_chnacttyp_chainactiontypeid`,
       `echothree`.`chainactiondetails`.`chnactdt_sortorder`                   AS `chnactdt_sortorder`
from `echothree`.`chainactions`
         join `echothree`.`chainactiondetails`
where (`echothree`.`chainactions`.`chnact_activedetailid` =
       `echothree`.`chainactiondetails`.`chnactdt_chainactiondetailid`);

