create definer = echothree@`127.0.0.1` view itemtaxclassifications as
select `echothree`.`itemtaxclassifications`.`itmtxclsfn_itemtaxclassificationid`             AS `itmtxclsfn_itemtaxclassificationid`,
       `echothree`.`itemtaxclassificationdetails`.`itmtxclsfndt_itm_itemid`                  AS `itmtxclsfndt_itm_itemid`,
       `echothree`.`itemtaxclassificationdetails`.`itmtxclsfndt_countrygeocodeid`            AS `itmtxclsfndt_countrygeocodeid`,
       `echothree`.`itemtaxclassificationdetails`.`itmtxclsfndt_txclsfn_taxclassificationid` AS `itmtxclsfndt_txclsfn_taxclassificationid`
from `echothree`.`itemtaxclassifications`
         join `echothree`.`itemtaxclassificationdetails`
where (`echothree`.`itemtaxclassifications`.`itmtxclsfn_activedetailid` =
       `echothree`.`itemtaxclassificationdetails`.`itmtxclsfndt_itemtaxclassificationdetailid`);

