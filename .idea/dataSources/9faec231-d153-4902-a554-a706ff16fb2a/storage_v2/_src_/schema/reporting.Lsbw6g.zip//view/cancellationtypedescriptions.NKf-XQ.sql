create definer = echothree@`127.0.0.1` view cancellationtypedescriptions as
select `echothree`.`cancellationtypedescriptions`.`cncltypd_cancellationtypedescriptionid` AS `cncltypd_cancellationtypedescriptionid`,
       `echothree`.`cancellationtypedescriptions`.`cncltypd_cncltyp_cancellationtypeid`    AS `cncltypd_cncltyp_cancellationtypeid`,
       `echothree`.`cancellationtypedescriptions`.`cncltypd_lang_languageid`               AS `cncltypd_lang_languageid`,
       `echothree`.`cancellationtypedescriptions`.`cncltypd_description`                   AS `cncltypd_description`
from `echothree`.`cancellationtypedescriptions`
where (`echothree`.`cancellationtypedescriptions`.`cncltypd_thrutime` = 9223372036854775807);

