create definer = echothree@`127.0.0.1` view batchtypeentitytypes as
select `echothree`.`batchtypeentitytypes`.`btchtypent_batchtypeentitytypeid` AS `btchtypent_batchtypeentitytypeid`,
       `echothree`.`batchtypeentitytypes`.`btchtypent_btchtyp_batchtypeid`   AS `btchtypent_btchtyp_batchtypeid`,
       `echothree`.`batchtypeentitytypes`.`btchtypent_ent_entitytypeid`      AS `btchtypent_ent_entitytypeid`
from `echothree`.`batchtypeentitytypes`
where (`echothree`.`batchtypeentitytypes`.`btchtypent_thrutime` = 9223372036854775807);

