create definer = echothree@`127.0.0.1` view commandmessagetypes as
select `echothree`.`commandmessagetypes`.`cmdmssgty_commandmessagetypeid`           AS `cmdmssgty_commandmessagetypeid`,
       `echothree`.`commandmessagetypedetails`.`cmdmssgtydt_commandmessagetypename` AS `cmdmssgtydt_commandmessagetypename`,
       `echothree`.`commandmessagetypedetails`.`cmdmssgtydt_isdefault`              AS `cmdmssgtydt_isdefault`,
       `echothree`.`commandmessagetypedetails`.`cmdmssgtydt_sortorder`              AS `cmdmssgtydt_sortorder`
from `echothree`.`commandmessagetypes`
         join `echothree`.`commandmessagetypedetails`
where (`echothree`.`commandmessagetypes`.`cmdmssgty_activedetailid` =
       `echothree`.`commandmessagetypedetails`.`cmdmssgtydt_commandmessagetypedetailid`);

