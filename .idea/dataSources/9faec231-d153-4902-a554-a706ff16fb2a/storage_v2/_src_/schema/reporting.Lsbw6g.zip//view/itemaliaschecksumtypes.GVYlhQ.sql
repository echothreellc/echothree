create definer = echothree@`127.0.0.1` view itemaliaschecksumtypes as
select `echothree`.`itemaliaschecksumtypes`.`iact_itemaliaschecksumtypeid`   AS `iact_itemaliaschecksumtypeid`,
       `echothree`.`itemaliaschecksumtypes`.`iact_itemaliaschecksumtypename` AS `iact_itemaliaschecksumtypename`,
       `echothree`.`itemaliaschecksumtypes`.`iact_isdefault`                 AS `iact_isdefault`,
       `echothree`.`itemaliaschecksumtypes`.`iact_sortorder`                 AS `iact_sortorder`
from `echothree`.`itemaliaschecksumtypes`;

