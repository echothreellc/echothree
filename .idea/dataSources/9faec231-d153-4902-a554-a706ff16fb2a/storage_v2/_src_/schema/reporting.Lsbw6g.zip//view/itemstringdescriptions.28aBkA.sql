create definer = echothree@`127.0.0.1` view itemstringdescriptions as
select `echothree`.`itemstringdescriptions`.`isdesc_itemstringdescriptionid` AS `isdesc_itemstringdescriptionid`,
       `echothree`.`itemstringdescriptions`.`isdesc_idesc_itemdescriptionid` AS `isdesc_idesc_itemdescriptionid`,
       `echothree`.`itemstringdescriptions`.`isdesc_stringdescription`       AS `isdesc_stringdescription`
from `echothree`.`itemstringdescriptions`
where (`echothree`.`itemstringdescriptions`.`isdesc_thrutime` = 9223372036854775807);

