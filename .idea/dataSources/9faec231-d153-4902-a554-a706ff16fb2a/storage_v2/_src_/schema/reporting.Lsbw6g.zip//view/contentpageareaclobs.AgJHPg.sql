create definer = echothree@`127.0.0.1` view contentpageareaclobs as
select `echothree`.`contentpageareaclobs`.`cntpac_contentpageareaclobid`          AS `cntpac_contentpageareaclobid`,
       `echothree`.`contentpageareaclobs`.`cntpac_cntpad_contentpageareadetailid` AS `cntpac_cntpad_contentpageareadetailid`,
       `echothree`.`contentpageareaclobs`.`cntpac_clob`                           AS `cntpac_clob`
from `echothree`.`contentpageareaclobs`;

