create definer = echothree@`127.0.0.1` view geocodedescriptions as
select `echothree`.`geocodedescriptions`.`geod_geocodedescriptionid` AS `geod_geocodedescriptionid`,
       `echothree`.`geocodedescriptions`.`geod_geo_geocodeid`        AS `geod_geo_geocodeid`,
       `echothree`.`geocodedescriptions`.`geod_lang_languageid`      AS `geod_lang_languageid`,
       `echothree`.`geocodedescriptions`.`geod_description`          AS `geod_description`
from `echothree`.`geocodedescriptions`
where (`echothree`.`geocodedescriptions`.`geod_thrutime` = 9223372036854775807);

