create definer = echothree@`127.0.0.1` view forummessages as
select `echothree`.`forummessages`.`frmmsg_forummessageid`                       AS `frmmsg_forummessageid`,
       `echothree`.`forummessagedetails`.`frmmsgdt_forummessagename`             AS `frmmsgdt_forummessagename`,
       `echothree`.`forummessagedetails`.`frmmsgdt_frmthrd_forumthreadid`        AS `frmmsgdt_frmthrd_forumthreadid`,
       `echothree`.`forummessagedetails`.`frmmsgdt_frmmsgtyp_forummessagetypeid` AS `frmmsgdt_frmmsgtyp_forummessagetypeid`,
       `echothree`.`forummessagedetails`.`frmmsgdt_parentforummessageid`         AS `frmmsgdt_parentforummessageid`,
       `echothree`.`forummessagedetails`.`frmmsgdt_icn_iconid`                   AS `frmmsgdt_icn_iconid`,
       `echothree`.`forummessagedetails`.`frmmsgdt_postedtime`                   AS `frmmsgdt_postedtime`
from `echothree`.`forummessages`
         join `echothree`.`forummessagedetails`
where (`echothree`.`forummessages`.`frmmsg_activedetailid` =
       `echothree`.`forummessagedetails`.`frmmsgdt_forummessagedetailid`);

