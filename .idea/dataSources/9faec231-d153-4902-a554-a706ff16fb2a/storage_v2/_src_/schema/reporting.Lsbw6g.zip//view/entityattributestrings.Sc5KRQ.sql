create definer = echothree@`127.0.0.1` view entityattributestrings as
select `echothree`.`entityattributestrings`.`enas_entityattributestringid` AS `enas_entityattributestringid`,
       `echothree`.`entityattributestrings`.`enas_ena_entityattributeid`   AS `enas_ena_entityattributeid`,
       `echothree`.`entityattributestrings`.`enas_validationpattern`       AS `enas_validationpattern`
from `echothree`.`entityattributestrings`
where (`echothree`.`entityattributestrings`.`enas_thrutime` = 9223372036854775807);

