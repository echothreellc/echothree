create definer = echothree@`127.0.0.1` view leavetypedescriptions as
select `echothree`.`leavetypedescriptions`.`lvtypd_leavetypedescriptionid` AS `lvtypd_leavetypedescriptionid`,
       `echothree`.`leavetypedescriptions`.`lvtypd_lvtyp_leavetypeid`      AS `lvtypd_lvtyp_leavetypeid`,
       `echothree`.`leavetypedescriptions`.`lvtypd_lang_languageid`        AS `lvtypd_lang_languageid`,
       `echothree`.`leavetypedescriptions`.`lvtypd_description`            AS `lvtypd_description`
from `echothree`.`leavetypedescriptions`
where (`echothree`.`leavetypedescriptions`.`lvtypd_thrutime` = 9223372036854775807);

