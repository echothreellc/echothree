create definer = echothree@`127.0.0.1` view inventorylocationgroupvolumes as
select `echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_inventorylocationgroupvolumeid`     AS `invlocgrpvol_inventorylocationgroupvolumeid`,
       `echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_invlocgrp_inventorylocationgroupid` AS `invlocgrpvol_invlocgrp_inventorylocationgroupid`,
       `echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_height`                             AS `invlocgrpvol_height`,
       `echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_width`                              AS `invlocgrpvol_width`,
       `echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_depth`                              AS `invlocgrpvol_depth`
from `echothree`.`inventorylocationgroupvolumes`
where (`echothree`.`inventorylocationgroupvolumes`.`invlocgrpvol_thrutime` = 9223372036854775807);

