create definer = echothree@`127.0.0.1` view freeonboards as
select `echothree`.`freeonboards`.`fob_freeonboardid`           AS `fob_freeonboardid`,
       `echothree`.`freeonboarddetails`.`fobdt_freeonboardname` AS `fobdt_freeonboardname`,
       `echothree`.`freeonboarddetails`.`fobdt_isdefault`       AS `fobdt_isdefault`,
       `echothree`.`freeonboarddetails`.`fobdt_sortorder`       AS `fobdt_sortorder`
from `echothree`.`freeonboards`
         join `echothree`.`freeonboarddetails`
where (`echothree`.`freeonboards`.`fob_activedetailid` = `echothree`.`freeonboarddetails`.`fobdt_freeonboarddetailid`);

