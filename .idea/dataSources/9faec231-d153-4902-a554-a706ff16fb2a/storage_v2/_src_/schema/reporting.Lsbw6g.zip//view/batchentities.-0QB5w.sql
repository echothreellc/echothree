create definer = echothree@`127.0.0.1` view batchentities as
select `echothree`.`batchentities`.`btche_batchentityid`        AS `btche_batchentityid`,
       `echothree`.`batchentities`.`btche_eni_entityinstanceid` AS `btche_eni_entityinstanceid`,
       `echothree`.`batchentities`.`btche_btch_batchid`         AS `btche_btch_batchid`
from `echothree`.`batchentities`
where (`echothree`.`batchentities`.`btche_thrutime` = 9223372036854775807);

