create definer = echothree@`127.0.0.1` view communicationeventpurposes as
select `echothree`.`communicationeventpurposes`.`cmmnevpr_communicationeventpurposeid`           AS `cmmnevpr_communicationeventpurposeid`,
       `echothree`.`communicationeventpurposedetails`.`cmmnevprdt_communicationeventpurposename` AS `cmmnevprdt_communicationeventpurposename`,
       `echothree`.`communicationeventpurposedetails`.`cmmnevprdt_isdefault`                     AS `cmmnevprdt_isdefault`,
       `echothree`.`communicationeventpurposedetails`.`cmmnevprdt_sortorder`                     AS `cmmnevprdt_sortorder`
from `echothree`.`communicationeventpurposes`
         join `echothree`.`communicationeventpurposedetails`
where (`echothree`.`communicationeventpurposes`.`cmmnevpr_activedetailid` =
       `echothree`.`communicationeventpurposedetails`.`cmmnevprdt_communicationeventpurposedetailid`);

