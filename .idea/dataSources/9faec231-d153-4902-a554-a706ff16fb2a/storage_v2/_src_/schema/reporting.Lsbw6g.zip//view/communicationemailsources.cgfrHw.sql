create definer = echothree@`127.0.0.1` view communicationemailsources as
select `echothree`.`communicationemailsources`.`cmmnesrc_communicationemailsourceid`    AS `cmmnesrc_communicationemailsourceid`,
       `echothree`.`communicationemailsources`.`cmmnesrc_cmmnsrc_communicationsourceid` AS `cmmnesrc_cmmnsrc_communicationsourceid`,
       `echothree`.`communicationemailsources`.`cmmnesrc_serv_serverid`                 AS `cmmnesrc_serv_serverid`,
       `echothree`.`communicationemailsources`.`cmmnesrc_username`                      AS `cmmnesrc_username`,
       `echothree`.`communicationemailsources`.`cmmnesrc_password`                      AS `cmmnesrc_password`,
       `echothree`.`communicationemailsources`.`cmmnesrc_receiveworkeffortscopeid`      AS `cmmnesrc_receiveworkeffortscopeid`,
       `echothree`.`communicationemailsources`.`cmmnesrc_sendworkeffortscopeid`         AS `cmmnesrc_sendworkeffortscopeid`,
       `echothree`.`communicationemailsources`.`cmmnesrc_reviewemployeeselectorid`      AS `cmmnesrc_reviewemployeeselectorid`
from `echothree`.`communicationemailsources`
where (`echothree`.`communicationemailsources`.`cmmnesrc_thrutime` = 9223372036854775807);

