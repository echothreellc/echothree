create definer = echothree@`127.0.0.1` view glaccountcategories as
select `echothree`.`glaccountcategories`.`glac_glaccountcategoryid`              AS `glac_glaccountcategoryid`,
       `echothree`.`glaccountcategorydetails`.`glacdt_glaccountcategoryname`     AS `glacdt_glaccountcategoryname`,
       `echothree`.`glaccountcategorydetails`.`glacdt_parentglaccountcategoryid` AS `glacdt_parentglaccountcategoryid`,
       `echothree`.`glaccountcategorydetails`.`glacdt_isdefault`                 AS `glacdt_isdefault`,
       `echothree`.`glaccountcategorydetails`.`glacdt_sortorder`                 AS `glacdt_sortorder`
from `echothree`.`glaccountcategories`
         join `echothree`.`glaccountcategorydetails`
where (`echothree`.`glaccountcategories`.`glac_activedetailid` =
       `echothree`.`glaccountcategorydetails`.`glacdt_glaccountcategorydetailid`);

