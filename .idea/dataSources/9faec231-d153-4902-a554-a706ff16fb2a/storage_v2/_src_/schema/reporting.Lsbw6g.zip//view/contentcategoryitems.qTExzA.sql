create definer = echothree@`127.0.0.1` view contentcategoryitems as
select `echothree`.`contentcategoryitems`.`cntcgi_contentcategoryitemid`       AS `cntcgi_contentcategoryitemid`,
       `echothree`.`contentcategoryitems`.`cntcgi_cntcg_contentcategoryid`     AS `cntcgi_cntcg_contentcategoryid`,
       `echothree`.`contentcategoryitems`.`cntcgi_cntcti_contentcatalogitemid` AS `cntcgi_cntcti_contentcatalogitemid`,
       `echothree`.`contentcategoryitems`.`cntcgi_isdefault`                   AS `cntcgi_isdefault`,
       `echothree`.`contentcategoryitems`.`cntcgi_sortorder`                   AS `cntcgi_sortorder`
from `echothree`.`contentcategoryitems`
where (`echothree`.`contentcategoryitems`.`cntcgi_thrutime` = 9223372036854775807);

