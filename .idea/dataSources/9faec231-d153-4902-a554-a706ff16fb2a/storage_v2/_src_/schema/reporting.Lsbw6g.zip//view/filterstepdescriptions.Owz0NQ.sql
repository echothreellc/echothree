create definer = echothree@`127.0.0.1` view filterstepdescriptions as
select `echothree`.`filterstepdescriptions`.`fltstpd_filterstepdescriptionid` AS `fltstpd_filterstepdescriptionid`,
       `echothree`.`filterstepdescriptions`.`fltstpd_fltstp_filterstepid`     AS `fltstpd_fltstp_filterstepid`,
       `echothree`.`filterstepdescriptions`.`fltstpd_lang_languageid`         AS `fltstpd_lang_languageid`,
       `echothree`.`filterstepdescriptions`.`fltstpd_description`             AS `fltstpd_description`
from `echothree`.`filterstepdescriptions`
where (`echothree`.`filterstepdescriptions`.`fltstpd_thrutime` = 9223372036854775807);

