create definer = echothree@`127.0.0.1` view forummessageparttypes as
select `echothree`.`forummessageparttypes`.`frmmsgprttyp_forummessageparttypeid`     AS `frmmsgprttyp_forummessageparttypeid`,
       `echothree`.`forummessageparttypes`.`frmmsgprttyp_forummessageparttypename`   AS `frmmsgprttyp_forummessageparttypename`,
       `echothree`.`forummessageparttypes`.`frmmsgprttyp_mtyput_mimetypeusagetypeid` AS `frmmsgprttyp_mtyput_mimetypeusagetypeid`,
       `echothree`.`forummessageparttypes`.`frmmsgprttyp_sortorder`                  AS `frmmsgprttyp_sortorder`
from `echothree`.`forummessageparttypes`;

