create definer = echothree@`127.0.0.1` view filteradjustmenttypedescriptions as
select `echothree`.`filteradjustmenttypedescriptions`.`fltatd_filteradjustmenttypedescriptionid` AS `fltatd_filteradjustmenttypedescriptionid`,
       `echothree`.`filteradjustmenttypedescriptions`.`fltatd_fltat_filteradjustmenttypeid`      AS `fltatd_fltat_filteradjustmenttypeid`,
       `echothree`.`filteradjustmenttypedescriptions`.`fltatd_lang_languageid`                   AS `fltatd_lang_languageid`,
       `echothree`.`filteradjustmenttypedescriptions`.`fltatd_description`                       AS `fltatd_description`
from `echothree`.`filteradjustmenttypedescriptions`;

