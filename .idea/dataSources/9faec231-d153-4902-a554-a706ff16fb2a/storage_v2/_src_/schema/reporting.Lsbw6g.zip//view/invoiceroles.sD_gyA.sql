create definer = echothree@`127.0.0.1` view invoiceroles as
select `echothree`.`invoiceroles`.`invcr_invoiceroleid`               AS `invcr_invoiceroleid`,
       `echothree`.`invoiceroles`.`invcr_invc_invoiceid`              AS `invcr_invc_invoiceid`,
       `echothree`.`invoiceroles`.`invcr_par_partyid`                 AS `invcr_par_partyid`,
       `echothree`.`invoiceroles`.`invcr_pcm_partycontactmechanismid` AS `invcr_pcm_partycontactmechanismid`,
       `echothree`.`invoiceroles`.`invcr_invcrtyp_invoiceroletypeid`  AS `invcr_invcrtyp_invoiceroletypeid`
from `echothree`.`invoiceroles`
where (`echothree`.`invoiceroles`.`invcr_thrutime` = 9223372036854775807);

