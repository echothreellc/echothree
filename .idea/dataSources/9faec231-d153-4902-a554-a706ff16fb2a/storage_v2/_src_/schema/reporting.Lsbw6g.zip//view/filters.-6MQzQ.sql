create definer = echothree@`127.0.0.1` view filters as
select `echothree`.`filters`.`flt_filterid`                          AS `flt_filterid`,
       `echothree`.`filterdetails`.`fltdt_flttyp_filtertypeid`       AS `fltdt_flttyp_filtertypeid`,
       `echothree`.`filterdetails`.`fltdt_filtername`                AS `fltdt_filtername`,
       `echothree`.`filterdetails`.`fltdt_initialfilteradjustmentid` AS `fltdt_initialfilteradjustmentid`,
       `echothree`.`filterdetails`.`fltdt_filteritemselectorid`      AS `fltdt_filteritemselectorid`,
       `echothree`.`filterdetails`.`fltdt_isdefault`                 AS `fltdt_isdefault`,
       `echothree`.`filterdetails`.`fltdt_sortorder`                 AS `fltdt_sortorder`
from `echothree`.`filters`
         join `echothree`.`filterdetails`
where (`echothree`.`filters`.`flt_activedetailid` = `echothree`.`filterdetails`.`fltdt_filterdetailid`);

