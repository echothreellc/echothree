create definer = echothree@`127.0.0.1` view chainactiontypedescriptions as
select `echothree`.`chainactiontypedescriptions`.`chnacttypd_chainactiontypedescriptionid` AS `chnacttypd_chainactiontypedescriptionid`,
       `echothree`.`chainactiontypedescriptions`.`chnacttypd_chnacttyp_chainactiontypeid`  AS `chnacttypd_chnacttyp_chainactiontypeid`,
       `echothree`.`chainactiontypedescriptions`.`chnacttypd_lang_languageid`              AS `chnacttypd_lang_languageid`,
       `echothree`.`chainactiontypedescriptions`.`chnacttypd_description`                  AS `chnacttypd_description`
from `echothree`.`chainactiontypedescriptions`
where (`echothree`.`chainactiontypedescriptions`.`chnacttypd_thrutime` = 9223372036854775807);

