create definer = echothree@`127.0.0.1` view campaigntermdescriptions as
select `echothree`.`campaigntermdescriptions`.`cmpgntrmd_campaigntermdescriptionid` AS `cmpgntrmd_campaigntermdescriptionid`,
       `echothree`.`campaigntermdescriptions`.`cmpgntrmd_cmpgntrm_campaigntermid`   AS `cmpgntrmd_cmpgntrm_campaigntermid`,
       `echothree`.`campaigntermdescriptions`.`cmpgntrmd_lang_languageid`           AS `cmpgntrmd_lang_languageid`,
       `echothree`.`campaigntermdescriptions`.`cmpgntrmd_description`               AS `cmpgntrmd_description`
from `echothree`.`campaigntermdescriptions`
where (`echothree`.`campaigntermdescriptions`.`cmpgntrmd_thrutime` = 9223372036854775807);

