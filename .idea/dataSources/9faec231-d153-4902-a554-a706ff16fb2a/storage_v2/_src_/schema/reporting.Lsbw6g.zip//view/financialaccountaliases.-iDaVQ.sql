create definer = echothree@`127.0.0.1` view financialaccountaliases as
select `echothree`.`financialaccountaliases`.`finaal_financialaccountaliasid`            AS `finaal_financialaccountaliasid`,
       `echothree`.`financialaccountaliases`.`finaal_fina_financialaccountid`            AS `finaal_fina_financialaccountid`,
       `echothree`.`financialaccountaliases`.`finaal_finaat_financialaccountaliastypeid` AS `finaal_finaat_financialaccountaliastypeid`,
       `echothree`.`financialaccountaliases`.`finaal_alias`                              AS `finaal_alias`
from `echothree`.`financialaccountaliases`
where (`echothree`.`financialaccountaliases`.`finaal_thrutime` = 9223372036854775807);

