create definer = echothree@`127.0.0.1` view indexfielddescriptions as
select `echothree`.`indexfielddescriptions`.`idxfldd_indexfielddescriptionid` AS `idxfldd_indexfielddescriptionid`,
       `echothree`.`indexfielddescriptions`.`idxfldd_idxfld_indexfieldid`     AS `idxfldd_idxfld_indexfieldid`,
       `echothree`.`indexfielddescriptions`.`idxfldd_lang_languageid`         AS `idxfldd_lang_languageid`,
       `echothree`.`indexfielddescriptions`.`idxfldd_description`             AS `idxfldd_description`
from `echothree`.`indexfielddescriptions`
where (`echothree`.`indexfielddescriptions`.`idxfldd_thrutime` = 9223372036854775807);

