create definer = echothree@`127.0.0.1` view forumforumthreads as
select `echothree`.`forumforumthreads`.`frmfrmthrd_forumforumid`          AS `frmfrmthrd_forumforumid`,
       `echothree`.`forumforumthreads`.`frmfrmthrd_frm_forumid`           AS `frmfrmthrd_frm_forumid`,
       `echothree`.`forumforumthreads`.`frmfrmthrd_frmthrd_forumthreadid` AS `frmfrmthrd_frmthrd_forumthreadid`,
       `echothree`.`forumforumthreads`.`frmfrmthrd_isdefault`             AS `frmfrmthrd_isdefault`,
       `echothree`.`forumforumthreads`.`frmfrmthrd_sortorder`             AS `frmfrmthrd_sortorder`
from `echothree`.`forumforumthreads`
where (`echothree`.`forumforumthreads`.`frmfrmthrd_thrutime` = 9223372036854775807);

