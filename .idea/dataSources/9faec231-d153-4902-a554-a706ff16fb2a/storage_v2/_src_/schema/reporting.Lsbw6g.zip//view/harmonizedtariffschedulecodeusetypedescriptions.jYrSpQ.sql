create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodeusetypedescriptions as
select `echothree`.`harmonizedtariffschedulecodeusetypedescriptions`.`hztscutypd_harmonizedtariffschedulecodeusetypedescriptionid` AS `hztscutypd_harmonizedtariffschedulecodeusetypedescriptionid`,
       `echothree`.`harmonizedtariffschedulecodeusetypedescriptions`.`hztscutypd_hztscutyp_harmonizedtariffschedulecodeusetypeid`  AS `hztscutypd_hztscutyp_harmonizedtariffschedulecodeusetypeid`,
       `echothree`.`harmonizedtariffschedulecodeusetypedescriptions`.`hztscutypd_lang_languageid`                                  AS `hztscutypd_lang_languageid`,
       `echothree`.`harmonizedtariffschedulecodeusetypedescriptions`.`hztscutypd_description`                                      AS `hztscutypd_description`
from `echothree`.`harmonizedtariffschedulecodeusetypedescriptions`
where (`echothree`.`harmonizedtariffschedulecodeusetypedescriptions`.`hztscutypd_thrutime` = 9223372036854775807);

