create definer = echothree@`127.0.0.1` view contactlisttypedescriptions as
select `echothree`.`contactlisttypedescriptions`.`clsttypd_contactlisttypedescriptionid` AS `clsttypd_contactlisttypedescriptionid`,
       `echothree`.`contactlisttypedescriptions`.`clsttypd_clsttyp_contactlisttypeid`    AS `clsttypd_clsttyp_contactlisttypeid`,
       `echothree`.`contactlisttypedescriptions`.`clsttypd_lang_languageid`              AS `clsttypd_lang_languageid`,
       `echothree`.`contactlisttypedescriptions`.`clsttypd_description`                  AS `clsttypd_description`
from `echothree`.`contactlisttypedescriptions`
where (`echothree`.`contactlisttypedescriptions`.`clsttypd_thrutime` = 9223372036854775807);

