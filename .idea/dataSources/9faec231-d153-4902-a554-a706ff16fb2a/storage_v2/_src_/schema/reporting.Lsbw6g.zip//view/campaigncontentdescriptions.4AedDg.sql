create definer = echothree@`127.0.0.1` view campaigncontentdescriptions as
select `echothree`.`campaigncontentdescriptions`.`cmpgncntd_campaigncontentdescriptionid` AS `cmpgncntd_campaigncontentdescriptionid`,
       `echothree`.`campaigncontentdescriptions`.`cmpgncntd_cmpgncnt_campaigncontentid`   AS `cmpgncntd_cmpgncnt_campaigncontentid`,
       `echothree`.`campaigncontentdescriptions`.`cmpgncntd_lang_languageid`              AS `cmpgncntd_lang_languageid`,
       `echothree`.`campaigncontentdescriptions`.`cmpgncntd_description`                  AS `cmpgncntd_description`
from `echothree`.`campaigncontentdescriptions`
where (`echothree`.`campaigncontentdescriptions`.`cmpgncntd_thrutime` = 9223372036854775807);

