create definer = echothree@`127.0.0.1` view itemadditionalcharges as
select `echothree`.`itemadditionalcharges`.`itmaddtlc_itemadditionalchargeid`                AS `itmaddtlc_itemadditionalchargeid`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_itm_itemid`                            AS `itmaddtlc_itm_itemid`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_itmaddtlct_itemadditionalchargetypeid` AS `itmaddtlc_itmaddtlct_itemadditionalchargetypeid`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_uomt_unitofmeasuretypeid`              AS `itmaddtlc_uomt_unitofmeasuretypeid`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_minimumquantity`                       AS `itmaddtlc_minimumquantity`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_maximumquantity`                       AS `itmaddtlc_maximumquantity`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_cur_currencyid`                        AS `itmaddtlc_cur_currencyid`,
       `echothree`.`itemadditionalcharges`.`itmaddtlc_unitprice`                             AS `itmaddtlc_unitprice`
from `echothree`.`itemadditionalcharges`
where (`echothree`.`itemadditionalcharges`.`itmaddtlc_thrutime` = 9223372036854775807);

