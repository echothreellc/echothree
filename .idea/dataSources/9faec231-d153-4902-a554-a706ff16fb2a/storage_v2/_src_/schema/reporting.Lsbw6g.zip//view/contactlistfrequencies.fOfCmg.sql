create definer = echothree@`127.0.0.1` view contactlistfrequencies as
select `echothree`.`contactlistfrequencies`.`clstfrq_contactlistfrequencyid`          AS `clstfrq_contactlistfrequencyid`,
       `echothree`.`contactlistfrequencydetails`.`clstfrqdt_contactlistfrequencyname` AS `clstfrqdt_contactlistfrequencyname`,
       `echothree`.`contactlistfrequencydetails`.`clstfrqdt_isdefault`                AS `clstfrqdt_isdefault`,
       `echothree`.`contactlistfrequencydetails`.`clstfrqdt_sortorder`                AS `clstfrqdt_sortorder`
from `echothree`.`contactlistfrequencies`
         join `echothree`.`contactlistfrequencydetails`
where (`echothree`.`contactlistfrequencies`.`clstfrq_activedetailid` =
       `echothree`.`contactlistfrequencydetails`.`clstfrqdt_contactlistfrequencydetailid`);

