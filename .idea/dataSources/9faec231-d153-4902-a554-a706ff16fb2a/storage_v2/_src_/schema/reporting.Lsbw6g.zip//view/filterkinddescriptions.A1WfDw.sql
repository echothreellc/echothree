create definer = echothree@`127.0.0.1` view filterkinddescriptions as
select `echothree`.`filterkinddescriptions`.`fltkd_filterkinddescriptionid` AS `fltkd_filterkinddescriptionid`,
       `echothree`.`filterkinddescriptions`.`fltkd_fltk_filterkindid`       AS `fltkd_fltk_filterkindid`,
       `echothree`.`filterkinddescriptions`.`fltkd_lang_languageid`         AS `fltkd_lang_languageid`,
       `echothree`.`filterkinddescriptions`.`fltkd_description`             AS `fltkd_description`
from `echothree`.`filterkinddescriptions`
where (`echothree`.`filterkinddescriptions`.`fltkd_thrutime` = 9223372036854775807);

