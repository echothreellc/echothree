create definer = echothree@`127.0.0.1` view itemunitlimits as
select `echothree`.`itemunitlimits`.`iul_itemunitlimitid`             AS `iul_itemunitlimitid`,
       `echothree`.`itemunitlimits`.`iul_itm_itemid`                  AS `iul_itm_itemid`,
       `echothree`.`itemunitlimits`.`iul_invcon_inventoryconditionid` AS `iul_invcon_inventoryconditionid`,
       `echothree`.`itemunitlimits`.`iul_uomt_unitofmeasuretypeid`    AS `iul_uomt_unitofmeasuretypeid`,
       `echothree`.`itemunitlimits`.`iul_minimumquantity`             AS `iul_minimumquantity`,
       `echothree`.`itemunitlimits`.`iul_maximumquantity`             AS `iul_maximumquantity`
from `echothree`.`itemunitlimits`
where (`echothree`.`itemunitlimits`.`iul_thrutime` = 9223372036854775807);

