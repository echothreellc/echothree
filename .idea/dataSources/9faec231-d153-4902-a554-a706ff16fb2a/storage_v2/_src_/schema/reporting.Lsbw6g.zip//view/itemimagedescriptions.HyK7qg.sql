create definer = echothree@`127.0.0.1` view itemimagedescriptions as
select `echothree`.`itemimagedescriptions`.`iimgdesc_itemimagedescriptionid`  AS `iimgdesc_itemimagedescriptionid`,
       `echothree`.`itemimagedescriptions`.`iimgdesc_idesc_itemdescriptionid` AS `iimgdesc_idesc_itemdescriptionid`,
       `echothree`.`itemimagedescriptions`.`iimgdesc_iimgt_itemimagetypeid`   AS `iimgdesc_iimgt_itemimagetypeid`,
       `echothree`.`itemimagedescriptions`.`iimgdesc_height`                  AS `iimgdesc_height`,
       `echothree`.`itemimagedescriptions`.`iimgdesc_width`                   AS `iimgdesc_width`,
       `echothree`.`itemimagedescriptions`.`iimgdesc_scaledfromparent`        AS `iimgdesc_scaledfromparent`
from `echothree`.`itemimagedescriptions`
where (`echothree`.`itemimagedescriptions`.`iimgdesc_thrutime` = 9223372036854775807);

