create definer = echothree@`127.0.0.1` view itemdescriptiontypedescriptions as
select `echothree`.`itemdescriptiontypedescriptions`.`idtd_itemdescriptiontypedescriptionid` AS `idtd_itemdescriptiontypedescriptionid`,
       `echothree`.`itemdescriptiontypedescriptions`.`idtd_idt_itemdescriptiontypeid`        AS `idtd_idt_itemdescriptiontypeid`,
       `echothree`.`itemdescriptiontypedescriptions`.`idtd_lang_languageid`                  AS `idtd_lang_languageid`,
       `echothree`.`itemdescriptiontypedescriptions`.`idtd_description`                      AS `idtd_description`
from `echothree`.`itemdescriptiontypedescriptions`
where (`echothree`.`itemdescriptiontypedescriptions`.`idtd_thrutime` = 9223372036854775807);

