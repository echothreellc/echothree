create definer = echothree@`127.0.0.1` view filteradjustmentdescriptions as
select `echothree`.`filteradjustmentdescriptions`.`fltad_filteradjustmentdescriptionid` AS `fltad_filteradjustmentdescriptionid`,
       `echothree`.`filteradjustmentdescriptions`.`fltad_flta_filteradjustmentid`       AS `fltad_flta_filteradjustmentid`,
       `echothree`.`filteradjustmentdescriptions`.`fltad_lang_languageid`               AS `fltad_lang_languageid`,
       `echothree`.`filteradjustmentdescriptions`.`fltad_description`                   AS `fltad_description`
from `echothree`.`filteradjustmentdescriptions`
where (`echothree`.`filteradjustmentdescriptions`.`fltad_thrutime` = 9223372036854775807);

