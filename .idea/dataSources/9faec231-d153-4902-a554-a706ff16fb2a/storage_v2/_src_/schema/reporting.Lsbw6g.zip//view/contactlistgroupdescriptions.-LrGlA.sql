create definer = echothree@`127.0.0.1` view contactlistgroupdescriptions as
select `echothree`.`contactlistgroupdescriptions`.`clstgrpd_contactlistgroupdescriptionid` AS `clstgrpd_contactlistgroupdescriptionid`,
       `echothree`.`contactlistgroupdescriptions`.`clstgrpd_clstgrp_contactlistgroupid`    AS `clstgrpd_clstgrp_contactlistgroupid`,
       `echothree`.`contactlistgroupdescriptions`.`clstgrpd_lang_languageid`               AS `clstgrpd_lang_languageid`,
       `echothree`.`contactlistgroupdescriptions`.`clstgrpd_description`                   AS `clstgrpd_description`
from `echothree`.`contactlistgroupdescriptions`
where (`echothree`.`contactlistgroupdescriptions`.`clstgrpd_thrutime` = 9223372036854775807);

