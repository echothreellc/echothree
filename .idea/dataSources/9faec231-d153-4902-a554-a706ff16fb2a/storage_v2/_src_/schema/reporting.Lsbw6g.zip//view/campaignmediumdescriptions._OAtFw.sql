create definer = echothree@`127.0.0.1` view campaignmediumdescriptions as
select `echothree`.`campaignmediumdescriptions`.`cmpgnmdmd_campaignmediumdescriptionid` AS `cmpgnmdmd_campaignmediumdescriptionid`,
       `echothree`.`campaignmediumdescriptions`.`cmpgnmdmd_cmpgnmdm_campaignmediumid`   AS `cmpgnmdmd_cmpgnmdm_campaignmediumid`,
       `echothree`.`campaignmediumdescriptions`.`cmpgnmdmd_lang_languageid`             AS `cmpgnmdmd_lang_languageid`,
       `echothree`.`campaignmediumdescriptions`.`cmpgnmdmd_description`                 AS `cmpgnmdmd_description`
from `echothree`.`campaignmediumdescriptions`
where (`echothree`.`campaignmediumdescriptions`.`cmpgnmdmd_thrutime` = 9223372036854775807);

