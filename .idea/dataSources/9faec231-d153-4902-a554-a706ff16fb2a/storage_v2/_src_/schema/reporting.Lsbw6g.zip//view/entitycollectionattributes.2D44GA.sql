create definer = echothree@`127.0.0.1` view entitycollectionattributes as
select `echothree`.`entitycollectionattributes`.`eca_entitycollectionattributeid` AS `eca_entitycollectionattributeid`,
       `echothree`.`entitycollectionattributes`.`eca_ena_entityattributeid`       AS `eca_ena_entityattributeid`,
       `echothree`.`entitycollectionattributes`.`eca_eni_entityinstanceid`        AS `eca_eni_entityinstanceid`,
       `echothree`.`entitycollectionattributes`.`eca_entityinstanceattributeid`   AS `eca_entityinstanceattributeid`
from `echothree`.`entitycollectionattributes`
where (`echothree`.`entitycollectionattributes`.`eca_thrutime` = 9223372036854775807);

