create definer = echothree@`127.0.0.1` view entityattributegroups as
select `echothree`.`entityattributegroups`.`enagp_entityattributegroupid`           AS `enagp_entityattributegroupid`,
       `echothree`.`entityattributegroupdetails`.`enagpdt_entityattributegroupname` AS `enagpdt_entityattributegroupname`,
       `echothree`.`entityattributegroupdetails`.`enagpdt_isdefault`                AS `enagpdt_isdefault`,
       `echothree`.`entityattributegroupdetails`.`enagpdt_sortorder`                AS `enagpdt_sortorder`
from `echothree`.`entityattributegroups`
         join `echothree`.`entityattributegroupdetails`
where (`echothree`.`entityattributegroups`.`enagp_activedetailid` =
       `echothree`.`entityattributegroupdetails`.`enagpdt_entityattributegroupdetailid`);

