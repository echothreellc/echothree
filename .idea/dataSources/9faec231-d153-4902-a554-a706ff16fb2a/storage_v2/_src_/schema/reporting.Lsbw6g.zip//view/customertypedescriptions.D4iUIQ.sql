create definer = echothree@`127.0.0.1` view customertypedescriptions as
select `echothree`.`customertypedescriptions`.`cutyd_customertypedescriptionid` AS `cutyd_customertypedescriptionid`,
       `echothree`.`customertypedescriptions`.`cutyd_cuty_customertypeid`       AS `cutyd_cuty_customertypeid`,
       `echothree`.`customertypedescriptions`.`cutyd_lang_languageid`           AS `cutyd_lang_languageid`,
       `echothree`.`customertypedescriptions`.`cutyd_description`               AS `cutyd_description`
from `echothree`.`customertypedescriptions`
where (`echothree`.`customertypedescriptions`.`cutyd_thrutime` = 9223372036854775807);

