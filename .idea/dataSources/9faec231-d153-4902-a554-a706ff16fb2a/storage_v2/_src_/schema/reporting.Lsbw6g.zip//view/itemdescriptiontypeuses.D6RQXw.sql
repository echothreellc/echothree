create definer = echothree@`127.0.0.1` view itemdescriptiontypeuses as
select `echothree`.`itemdescriptiontypeuses`.`idtu_itemdescriptiontypeuseid`             AS `idtu_itemdescriptiontypeuseid`,
       `echothree`.`itemdescriptiontypeuses`.`idtu_idt_itemdescriptiontypeid`            AS `idtu_idt_itemdescriptiontypeid`,
       `echothree`.`itemdescriptiontypeuses`.`idtu_idtutyp_itemdescriptiontypeusetypeid` AS `idtu_idtutyp_itemdescriptiontypeusetypeid`
from `echothree`.`itemdescriptiontypeuses`
where (`echothree`.`itemdescriptiontypeuses`.`idtu_thrutime` = 9223372036854775807);

