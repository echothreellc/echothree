create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodeunitdescriptions as
select `echothree`.`harmonizedtariffschedulecodeunitdescriptions`.`hztscuntd_harmonizedtariffschedulecodeunitdescriptionid` AS `hztscuntd_harmonizedtariffschedulecodeunitdescriptionid`,
       `echothree`.`harmonizedtariffschedulecodeunitdescriptions`.`hztscuntd_hztscunt_harmonizedtariffschedulecodeunitid`   AS `hztscuntd_hztscunt_harmonizedtariffschedulecodeunitid`,
       `echothree`.`harmonizedtariffschedulecodeunitdescriptions`.`hztscuntd_lang_languageid`                               AS `hztscuntd_lang_languageid`,
       `echothree`.`harmonizedtariffschedulecodeunitdescriptions`.`hztscuntd_description`                                   AS `hztscuntd_description`
from `echothree`.`harmonizedtariffschedulecodeunitdescriptions`
where (`echothree`.`harmonizedtariffschedulecodeunitdescriptions`.`hztscuntd_thrutime` = 9223372036854775807);

