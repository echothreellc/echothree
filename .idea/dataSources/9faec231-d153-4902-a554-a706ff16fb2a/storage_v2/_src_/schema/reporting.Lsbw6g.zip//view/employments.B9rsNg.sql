create definer = echothree@`127.0.0.1` view employments as
select `echothree`.`employments`.`empmnt_employmentid`                        AS `empmnt_employmentid`,
       `echothree`.`employmentdetails`.`empmntdt_employmentname`              AS `empmntdt_employmentname`,
       `echothree`.`employmentdetails`.`empmntdt_par_partyid`                 AS `empmntdt_par_partyid`,
       `echothree`.`employmentdetails`.`empmntdt_companypartyid`              AS `empmntdt_companypartyid`,
       `echothree`.`employmentdetails`.`empmntdt_starttime`                   AS `empmntdt_starttime`,
       `echothree`.`employmentdetails`.`empmntdt_endtime`                     AS `empmntdt_endtime`,
       `echothree`.`employmentdetails`.`empmntdt_trmntyp_terminationtypeid`   AS `empmntdt_trmntyp_terminationtypeid`,
       `echothree`.`employmentdetails`.`empmntdt_trmnrsn_terminationreasonid` AS `empmntdt_trmnrsn_terminationreasonid`
from `echothree`.`employments`
         join `echothree`.`employmentdetails`
where (`echothree`.`employments`.`empmnt_activedetailid` =
       `echothree`.`employmentdetails`.`empmntdt_employmentdetailid`);

