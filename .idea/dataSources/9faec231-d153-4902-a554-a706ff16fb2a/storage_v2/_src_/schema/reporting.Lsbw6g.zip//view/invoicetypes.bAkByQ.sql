create definer = echothree@`127.0.0.1` view invoicetypes as
select `echothree`.`invoicetypes`.`invctyp_invoicetypeid`                 AS `invctyp_invoicetypeid`,
       `echothree`.`invoicetypedetails`.`invctypdt_invoicetypename`       AS `invctypdt_invoicetypename`,
       `echothree`.`invoicetypedetails`.`invctypdt_parentinvoicetypeid`   AS `invctypdt_parentinvoicetypeid`,
       `echothree`.`invoicetypedetails`.`invctypdt_invoicesequencetypeid` AS `invctypdt_invoicesequencetypeid`,
       `echothree`.`invoicetypedetails`.`invctypdt_isdefault`             AS `invctypdt_isdefault`,
       `echothree`.`invoicetypedetails`.`invctypdt_sortorder`             AS `invctypdt_sortorder`
from `echothree`.`invoicetypes`
         join `echothree`.`invoicetypedetails`
where (`echothree`.`invoicetypes`.`invctyp_activedetailid` =
       `echothree`.`invoicetypedetails`.`invctypdt_invoicetypedetailid`);

