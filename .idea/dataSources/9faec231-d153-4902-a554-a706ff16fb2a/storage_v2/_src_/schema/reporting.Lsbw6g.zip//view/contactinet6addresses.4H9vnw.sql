create definer = echothree@`127.0.0.1` view contactinet6addresses as
select `echothree`.`contactinet6addresses`.`cti6a_contactinet6addressid`   AS `cti6a_contactinet6addressid`,
       `echothree`.`contactinet6addresses`.`cti6a_cmch_contactmechanismid` AS `cti6a_cmch_contactmechanismid`,
       `echothree`.`contactinet6addresses`.`cti6a_inet6addresslow`         AS `cti6a_inet6addresslow`,
       `echothree`.`contactinet6addresses`.`cti6a_inet6addresshigh`        AS `cti6a_inet6addresshigh`
from `echothree`.`contactinet6addresses`
where (`echothree`.`contactinet6addresses`.`cti6a_thrutime` = 9223372036854775807);

