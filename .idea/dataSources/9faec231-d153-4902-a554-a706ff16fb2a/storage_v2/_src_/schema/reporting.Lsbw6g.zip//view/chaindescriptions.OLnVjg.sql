create definer = echothree@`127.0.0.1` view chaindescriptions as
select `echothree`.`chaindescriptions`.`chnd_chaindescriptionid` AS `chnd_chaindescriptionid`,
       `echothree`.`chaindescriptions`.`chnd_chn_chainid`        AS `chnd_chn_chainid`,
       `echothree`.`chaindescriptions`.`chnd_lang_languageid`    AS `chnd_lang_languageid`,
       `echothree`.`chaindescriptions`.`chnd_description`        AS `chnd_description`
from `echothree`.`chaindescriptions`
where (`echothree`.`chaindescriptions`.`chnd_thrutime` = 9223372036854775807);

