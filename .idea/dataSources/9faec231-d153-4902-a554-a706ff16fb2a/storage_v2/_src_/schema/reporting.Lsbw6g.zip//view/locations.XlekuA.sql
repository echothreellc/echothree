create definer = echothree@`127.0.0.1` view locations as
select `echothree`.`locations`.`loc_locationid`                                 AS `loc_locationid`,
       `echothree`.`locationdetails`.`locdt_warehousepartyid`                   AS `locdt_warehousepartyid`,
       `echothree`.`locationdetails`.`locdt_locationname`                       AS `locdt_locationname`,
       `echothree`.`locationdetails`.`locdt_loctyp_locationtypeid`              AS `locdt_loctyp_locationtypeid`,
       `echothree`.`locationdetails`.`locdt_locutyp_locationusetypeid`          AS `locdt_locutyp_locationusetypeid`,
       `echothree`.`locationdetails`.`locdt_velocity`                           AS `locdt_velocity`,
       `echothree`.`locationdetails`.`locdt_invlocgrp_inventorylocationgroupid` AS `locdt_invlocgrp_inventorylocationgroupid`
from `echothree`.`locations`
         join `echothree`.`locationdetails`
where (`echothree`.`locations`.`loc_activedetailid` = `echothree`.`locationdetails`.`locdt_locationdetailid`);

