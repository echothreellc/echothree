create definer = echothree@`127.0.0.1` view itemdeliverytypes as
select `echothree`.`itemdeliverytypes`.`idlvrtyp_itemdeliverytypeid`   AS `idlvrtyp_itemdeliverytypeid`,
       `echothree`.`itemdeliverytypes`.`idlvrtyp_itemdeliverytypename` AS `idlvrtyp_itemdeliverytypename`,
       `echothree`.`itemdeliverytypes`.`idlvrtyp_isdefault`            AS `idlvrtyp_isdefault`,
       `echothree`.`itemdeliverytypes`.`idlvrtyp_sortorder`            AS `idlvrtyp_sortorder`
from `echothree`.`itemdeliverytypes`;

