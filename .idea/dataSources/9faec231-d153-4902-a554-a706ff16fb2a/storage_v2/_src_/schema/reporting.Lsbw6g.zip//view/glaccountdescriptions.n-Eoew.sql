create definer = echothree@`127.0.0.1` view glaccountdescriptions as
select `echothree`.`glaccountdescriptions`.`glad_glaccountdescriptionid` AS `glad_glaccountdescriptionid`,
       `echothree`.`glaccountdescriptions`.`glad_gla_glaccountid`        AS `glad_gla_glaccountid`,
       `echothree`.`glaccountdescriptions`.`glad_lang_languageid`        AS `glad_lang_languageid`,
       `echothree`.`glaccountdescriptions`.`glad_description`            AS `glad_description`
from `echothree`.`glaccountdescriptions`
where (`echothree`.`glaccountdescriptions`.`glad_thrutime` = 9223372036854775807);

