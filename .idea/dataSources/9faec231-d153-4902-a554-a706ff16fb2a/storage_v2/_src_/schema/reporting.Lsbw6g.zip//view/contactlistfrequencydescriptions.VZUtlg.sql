create definer = echothree@`127.0.0.1` view contactlistfrequencydescriptions as
select `echothree`.`contactlistfrequencydescriptions`.`clstfrqd_contactlistfrequencydescriptionid` AS `clstfrqd_contactlistfrequencydescriptionid`,
       `echothree`.`contactlistfrequencydescriptions`.`clstfrqd_clstfrq_contactlistfrequencyid`    AS `clstfrqd_clstfrq_contactlistfrequencyid`,
       `echothree`.`contactlistfrequencydescriptions`.`clstfrqd_lang_languageid`                   AS `clstfrqd_lang_languageid`,
       `echothree`.`contactlistfrequencydescriptions`.`clstfrqd_description`                       AS `clstfrqd_description`
from `echothree`.`contactlistfrequencydescriptions`
where (`echothree`.`contactlistfrequencydescriptions`.`clstfrqd_thrutime` = 9223372036854775807);

