create definer = echothree@`127.0.0.1` view filtersteps as
select `echothree`.`filtersteps`.`fltstp_filterstepid`                 AS `fltstp_filterstepid`,
       `echothree`.`filterstepdetails`.`fltstpdt_flt_filterid`         AS `fltstpdt_flt_filterid`,
       `echothree`.`filterstepdetails`.`fltstpdt_filterstepname`       AS `fltstpdt_filterstepname`,
       `echothree`.`filterstepdetails`.`fltstpdt_filteritemselectorid` AS `fltstpdt_filteritemselectorid`
from `echothree`.`filtersteps`
         join `echothree`.`filterstepdetails`
where (`echothree`.`filtersteps`.`fltstp_activedetailid` =
       `echothree`.`filterstepdetails`.`fltstpdt_filterstepdetailid`);

