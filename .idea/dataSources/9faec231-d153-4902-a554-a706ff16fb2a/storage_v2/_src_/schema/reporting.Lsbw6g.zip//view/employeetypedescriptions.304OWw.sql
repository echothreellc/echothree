create definer = echothree@`127.0.0.1` view employeetypedescriptions as
select `echothree`.`employeetypedescriptions`.`emptyd_employeetypedescriptionid` AS `emptyd_employeetypedescriptionid`,
       `echothree`.`employeetypedescriptions`.`emptyd_empty_employeetypeid`      AS `emptyd_empty_employeetypeid`,
       `echothree`.`employeetypedescriptions`.`emptyd_lang_languageid`           AS `emptyd_lang_languageid`,
       `echothree`.`employeetypedescriptions`.`emptyd_description`               AS `emptyd_description`
from `echothree`.`employeetypedescriptions`
where (`echothree`.`employeetypedescriptions`.`emptyd_thrutime` = 9223372036854775807);

