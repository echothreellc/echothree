create definer = echothree@`127.0.0.1` view indexstatuses as
select `echothree`.`indexstatuses`.`idxst_indexstatusid` AS `idxst_indexstatusid`,
       `echothree`.`indexstatuses`.`idxst_idx_indexid`   AS `idxst_idx_indexid`,
       `echothree`.`indexstatuses`.`idxst_createdtime`   AS `idxst_createdtime`
from `echothree`.`indexstatuses`;

