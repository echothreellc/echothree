create definer = echothree@`127.0.0.1` view financialaccounttransactiontypedescriptions as
select `echothree`.`financialaccounttransactiontypedescriptions`.`fnatrxtypd_financialaccounttransactiontypedescriptionid` AS `fnatrxtypd_financialaccounttransactiontypedescriptionid`,
       `echothree`.`financialaccounttransactiontypedescriptions`.`fnatrxtypd_fnatrxtyp_financialaccounttransactiontypeid`  AS `fnatrxtypd_fnatrxtyp_financialaccounttransactiontypeid`,
       `echothree`.`financialaccounttransactiontypedescriptions`.`fnatrxtypd_lang_languageid`                              AS `fnatrxtypd_lang_languageid`,
       `echothree`.`financialaccounttransactiontypedescriptions`.`fnatrxtypd_description`                                  AS `fnatrxtypd_description`
from `echothree`.`financialaccounttransactiontypedescriptions`
where (`echothree`.`financialaccounttransactiontypedescriptions`.`fnatrxtypd_thrutime` = 9223372036854775807);

