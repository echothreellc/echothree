create definer = echothree@`127.0.0.1` view locationnameelementdescriptions as
select `echothree`.`locationnameelementdescriptions`.`locned_locationnameelementdescriptionid` AS `locned_locationnameelementdescriptionid`,
       `echothree`.`locationnameelementdescriptions`.`locned_locne_locationnameelementid`      AS `locned_locne_locationnameelementid`,
       `echothree`.`locationnameelementdescriptions`.`locned_lang_languageid`                  AS `locned_lang_languageid`,
       `echothree`.`locationnameelementdescriptions`.`locned_description`                      AS `locned_description`
from `echothree`.`locationnameelementdescriptions`
where (`echothree`.`locationnameelementdescriptions`.`locned_thrutime` = 9223372036854775807);

