create definer = echothree@`127.0.0.1` view chaintypes as
select `echothree`.`chaintypes`.`chntyp_chaintypeid`              AS `chntyp_chaintypeid`,
       `echothree`.`chaintypedetails`.`chntypdt_chnk_chainkindid` AS `chntypdt_chnk_chainkindid`,
       `echothree`.`chaintypedetails`.`chntypdt_chaintypename`    AS `chntypdt_chaintypename`,
       `echothree`.`chaintypedetails`.`chntypdt_isdefault`        AS `chntypdt_isdefault`,
       `echothree`.`chaintypedetails`.`chntypdt_sortorder`        AS `chntypdt_sortorder`
from `echothree`.`chaintypes`
         join `echothree`.`chaintypedetails`
where (`echothree`.`chaintypes`.`chntyp_activedetailid` = `echothree`.`chaintypedetails`.`chntypdt_chaintypedetailid`);

