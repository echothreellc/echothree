create definer = echothree@`127.0.0.1` view contactmechanismaliastypedescriptions as
select `echothree`.`contactmechanismaliastypedescriptions`.`cmchaltypd_contactmechanismaliastypedescriptionid` AS `cmchaltypd_contactmechanismaliastypedescriptionid`,
       `echothree`.`contactmechanismaliastypedescriptions`.`cmchaltypd_cmchaltyp_contactmechanismaliastypeid`  AS `cmchaltypd_cmchaltyp_contactmechanismaliastypeid`,
       `echothree`.`contactmechanismaliastypedescriptions`.`cmchaltypd_lang_languageid`                        AS `cmchaltypd_lang_languageid`,
       `echothree`.`contactmechanismaliastypedescriptions`.`cmchaltypd_description`                            AS `cmchaltypd_description`
from `echothree`.`contactmechanismaliastypedescriptions`
where (`echothree`.`contactmechanismaliastypedescriptions`.`cmchaltypd_thrutime` = 9223372036854775807);

