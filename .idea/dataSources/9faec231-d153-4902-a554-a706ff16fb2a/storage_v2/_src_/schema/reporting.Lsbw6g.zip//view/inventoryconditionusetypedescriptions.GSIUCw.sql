create definer = echothree@`127.0.0.1` view inventoryconditionusetypedescriptions as
select `echothree`.`inventoryconditionusetypedescriptions`.`invconutd_inventoryconditionusetypedescriptionid` AS `invconutd_inventoryconditionusetypedescriptionid`,
       `echothree`.`inventoryconditionusetypedescriptions`.`invconutd_invconut_inventoryconditionusetypeid`   AS `invconutd_invconut_inventoryconditionusetypeid`,
       `echothree`.`inventoryconditionusetypedescriptions`.`invconutd_lang_languageid`                        AS `invconutd_lang_languageid`,
       `echothree`.`inventoryconditionusetypedescriptions`.`invconutd_description`                            AS `invconutd_description`
from `echothree`.`inventoryconditionusetypedescriptions`;

