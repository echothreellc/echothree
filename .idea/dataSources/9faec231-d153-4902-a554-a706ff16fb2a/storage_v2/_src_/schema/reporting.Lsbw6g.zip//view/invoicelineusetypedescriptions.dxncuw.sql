create definer = echothree@`127.0.0.1` view invoicelineusetypedescriptions as
select `echothree`.`invoicelineusetypedescriptions`.`invclutd_invoicelineusetypedescriptionid` AS `invclutd_invoicelineusetypedescriptionid`,
       `echothree`.`invoicelineusetypedescriptions`.`invclutd_invclut_invoicelineusetypeid`    AS `invclutd_invclut_invoicelineusetypeid`,
       `echothree`.`invoicelineusetypedescriptions`.`invclutd_lang_languageid`                 AS `invclutd_lang_languageid`,
       `echothree`.`invoicelineusetypedescriptions`.`invclutd_description`                     AS `invclutd_description`
from `echothree`.`invoicelineusetypedescriptions`;

