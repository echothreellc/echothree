create definer = echothree@`127.0.0.1` view itemprices as
select `echothree`.`itemprices`.`itmp_itempriceid`                 AS `itmp_itempriceid`,
       `echothree`.`itemprices`.`itmp_itm_itemid`                  AS `itmp_itm_itemid`,
       `echothree`.`itemprices`.`itmp_invcon_inventoryconditionid` AS `itmp_invcon_inventoryconditionid`,
       `echothree`.`itemprices`.`itmp_uomt_unitofmeasuretypeid`    AS `itmp_uomt_unitofmeasuretypeid`,
       `echothree`.`itemprices`.`itmp_cur_currencyid`              AS `itmp_cur_currencyid`
from `echothree`.`itemprices`
where (`echothree`.`itemprices`.`itmp_thrutime` = 9223372036854775807);

