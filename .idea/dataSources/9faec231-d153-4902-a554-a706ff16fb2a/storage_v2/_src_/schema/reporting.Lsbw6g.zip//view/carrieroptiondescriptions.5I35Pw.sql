create definer = echothree@`127.0.0.1` view carrieroptiondescriptions as
select `echothree`.`carrieroptiondescriptions`.`crroptd_carrieroptiondescriptionid` AS `crroptd_carrieroptiondescriptionid`,
       `echothree`.`carrieroptiondescriptions`.`crroptd_crropt_carrieroptionid`     AS `crroptd_crropt_carrieroptionid`,
       `echothree`.`carrieroptiondescriptions`.`crroptd_lang_languageid`            AS `crroptd_lang_languageid`,
       `echothree`.`carrieroptiondescriptions`.`crroptd_description`                AS `crroptd_description`
from `echothree`.`carrieroptiondescriptions`
where (`echothree`.`carrieroptiondescriptions`.`crroptd_thrutime` = 9223372036854775807);

