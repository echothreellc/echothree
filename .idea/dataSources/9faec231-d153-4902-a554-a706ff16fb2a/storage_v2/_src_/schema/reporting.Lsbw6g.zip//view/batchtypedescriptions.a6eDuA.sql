create definer = echothree@`127.0.0.1` view batchtypedescriptions as
select `echothree`.`batchtypedescriptions`.`btchtypd_batchtypedescriptionid` AS `btchtypd_batchtypedescriptionid`,
       `echothree`.`batchtypedescriptions`.`btchtypd_btchtyp_batchtypeid`    AS `btchtypd_btchtyp_batchtypeid`,
       `echothree`.`batchtypedescriptions`.`btchtypd_lang_languageid`        AS `btchtypd_lang_languageid`,
       `echothree`.`batchtypedescriptions`.`btchtypd_description`            AS `btchtypd_description`
from `echothree`.`batchtypedescriptions`
where (`echothree`.`batchtypedescriptions`.`btchtypd_thrutime` = 9223372036854775807);

