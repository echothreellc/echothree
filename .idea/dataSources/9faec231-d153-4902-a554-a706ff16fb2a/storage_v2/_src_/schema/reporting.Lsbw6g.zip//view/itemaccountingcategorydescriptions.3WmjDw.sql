create definer = echothree@`127.0.0.1` view itemaccountingcategorydescriptions as
select `echothree`.`itemaccountingcategorydescriptions`.`iactgcd_itemaccountingcategorydescriptionid` AS `iactgcd_itemaccountingcategorydescriptionid`,
       `echothree`.`itemaccountingcategorydescriptions`.`iactgcd_iactgc_itemaccountingcategoryid`     AS `iactgcd_iactgc_itemaccountingcategoryid`,
       `echothree`.`itemaccountingcategorydescriptions`.`iactgcd_lang_languageid`                     AS `iactgcd_lang_languageid`,
       `echothree`.`itemaccountingcategorydescriptions`.`iactgcd_description`                         AS `iactgcd_description`
from `echothree`.`itemaccountingcategorydescriptions`
where (`echothree`.`itemaccountingcategorydescriptions`.`iactgcd_thrutime` = 9223372036854775807);

