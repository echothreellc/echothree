create definer = echothree@`127.0.0.1` view glaccountcategorydescriptions as
select `echothree`.`glaccountcategorydescriptions`.`glacd_glaccountcategorydescriptionid` AS `glacd_glaccountcategorydescriptionid`,
       `echothree`.`glaccountcategorydescriptions`.`glacd_glac_glaccountcategoryid`       AS `glacd_glac_glaccountcategoryid`,
       `echothree`.`glaccountcategorydescriptions`.`glacd_lang_languageid`                AS `glacd_lang_languageid`,
       `echothree`.`glaccountcategorydescriptions`.`glacd_description`                    AS `glacd_description`
from `echothree`.`glaccountcategorydescriptions`
where (`echothree`.`glaccountcategorydescriptions`.`glacd_thrutime` = 9223372036854775807);

