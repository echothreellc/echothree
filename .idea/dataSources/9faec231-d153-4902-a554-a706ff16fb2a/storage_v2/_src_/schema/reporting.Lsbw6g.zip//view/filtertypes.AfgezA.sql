create definer = echothree@`127.0.0.1` view filtertypes as
select `echothree`.`filtertypes`.`flttyp_filtertypeid`              AS `flttyp_filtertypeid`,
       `echothree`.`filtertypedetails`.`flttypdt_fltk_filterkindid` AS `flttypdt_fltk_filterkindid`,
       `echothree`.`filtertypedetails`.`flttypdt_filtertypename`    AS `flttypdt_filtertypename`,
       `echothree`.`filtertypedetails`.`flttypdt_isdefault`         AS `flttypdt_isdefault`,
       `echothree`.`filtertypedetails`.`flttypdt_sortorder`         AS `flttypdt_sortorder`
from `echothree`.`filtertypes`
         join `echothree`.`filtertypedetails`
where (`echothree`.`filtertypes`.`flttyp_activedetailid` =
       `echothree`.`filtertypedetails`.`flttypdt_filtertypedetailid`);

