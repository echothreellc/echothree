create definer = echothree@`127.0.0.1` view lettersources as
select `echothree`.`lettersources`.`lttrsrc_lettersourceid`                               AS `lttrsrc_lettersourceid`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_lettersourcename`                     AS `lttrsrcdt_lettersourcename`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_companypartyid`                       AS `lttrsrcdt_companypartyid`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_emailaddresspartycontactmechanismid`  AS `lttrsrcdt_emailaddresspartycontactmechanismid`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_postaladdresspartycontactmechanismid` AS `lttrsrcdt_postaladdresspartycontactmechanismid`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_lettersourcepartycontactmechanismid`  AS `lttrsrcdt_lettersourcepartycontactmechanismid`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_isdefault`                            AS `lttrsrcdt_isdefault`,
       `echothree`.`lettersourcedetails`.`lttrsrcdt_sortorder`                            AS `lttrsrcdt_sortorder`
from `echothree`.`lettersources`
         join `echothree`.`lettersourcedetails`
where (`echothree`.`lettersources`.`lttrsrc_activedetailid` =
       `echothree`.`lettersourcedetails`.`lttrsrcdt_lettersourcedetailid`);

