create definer = echothree@`127.0.0.1` view iteminventorytypedescriptions as
select `echothree`.`iteminventorytypedescriptions`.`iinvtypd_iteminventorytypedescriptionid` AS `iinvtypd_iteminventorytypedescriptionid`,
       `echothree`.`iteminventorytypedescriptions`.`iinvtypd_iinvtyp_iteminventorytypeid`    AS `iinvtypd_iinvtyp_iteminventorytypeid`,
       `echothree`.`iteminventorytypedescriptions`.`iinvtypd_lang_languageid`                AS `iinvtypd_lang_languageid`,
       `echothree`.`iteminventorytypedescriptions`.`iinvtypd_description`                    AS `iinvtypd_description`
from `echothree`.`iteminventorytypedescriptions`;

