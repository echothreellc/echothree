create definer = echothree@`127.0.0.1` view campaignterms as
select `echothree`.`campaignterms`.`cmpgntrm_campaigntermid`           AS `cmpgntrm_campaigntermid`,
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_campaigntermname` AS `cmpgntrmdt_campaigntermname`,
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_valuesha1hash`    AS `cmpgntrmdt_valuesha1hash`,
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_value`            AS `cmpgntrmdt_value`,
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_isdefault`        AS `cmpgntrmdt_isdefault`,
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_sortorder`        AS `cmpgntrmdt_sortorder`
from `echothree`.`campaignterms`
         join `echothree`.`campaigntermdetails`
where (`echothree`.`campaignterms`.`cmpgntrm_activedetailid` =
       `echothree`.`campaigntermdetails`.`cmpgntrmdt_campaigntermdetailid`);

