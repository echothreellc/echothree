create definer = echothree@`127.0.0.1` view inventoryconditions as
select `echothree`.`inventoryconditions`.`invcon_inventoryconditionid`           AS `invcon_inventoryconditionid`,
       `echothree`.`inventoryconditiondetails`.`invcondt_inventoryconditionname` AS `invcondt_inventoryconditionname`,
       `echothree`.`inventoryconditiondetails`.`invcondt_isdefault`              AS `invcondt_isdefault`,
       `echothree`.`inventoryconditiondetails`.`invcondt_sortorder`              AS `invcondt_sortorder`
from `echothree`.`inventoryconditions`
         join `echothree`.`inventoryconditiondetails`
where (`echothree`.`inventoryconditions`.`invcon_activedetailid` =
       `echothree`.`inventoryconditiondetails`.`invcondt_inventoryconditiondetailid`);

