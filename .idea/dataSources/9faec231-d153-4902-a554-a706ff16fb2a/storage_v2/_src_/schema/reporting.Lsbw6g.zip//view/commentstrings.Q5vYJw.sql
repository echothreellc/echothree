create definer = echothree@`127.0.0.1` view commentstrings as
select `echothree`.`commentstrings`.`cmnts_commentstringid` AS `cmnts_commentstringid`,
       `echothree`.`commentstrings`.`cmnts_cmnt_commentid`  AS `cmnts_cmnt_commentid`,
       `echothree`.`commentstrings`.`cmnts_string`          AS `cmnts_string`
from `echothree`.`commentstrings`
where (`echothree`.`commentstrings`.`cmnts_thrutime` = 9223372036854775807);

