create definer = echothree@`127.0.0.1` view itemaliastypedescriptions as
select `echothree`.`itemaliastypedescriptions`.`iatd_itemaliastypedescriptionid` AS `iatd_itemaliastypedescriptionid`,
       `echothree`.`itemaliastypedescriptions`.`iatd_iat_itemaliastypeid`        AS `iatd_iat_itemaliastypeid`,
       `echothree`.`itemaliastypedescriptions`.`iatd_lang_languageid`            AS `iatd_lang_languageid`,
       `echothree`.`itemaliastypedescriptions`.`iatd_description`                AS `iatd_description`
from `echothree`.`itemaliastypedescriptions`
where (`echothree`.`itemaliastypedescriptions`.`iatd_thrutime` = 9223372036854775807);

