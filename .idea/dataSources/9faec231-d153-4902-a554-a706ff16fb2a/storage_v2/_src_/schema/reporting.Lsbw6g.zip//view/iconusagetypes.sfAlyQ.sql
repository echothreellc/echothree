create definer = echothree@`127.0.0.1` view iconusagetypes as
select `echothree`.`iconusagetypes`.`icnutyp_iconusagetypeid`           AS `icnutyp_iconusagetypeid`,
       `echothree`.`iconusagetypedetails`.`icnutypdt_iconusagetypename` AS `icnutypdt_iconusagetypename`,
       `echothree`.`iconusagetypedetails`.`icnutypdt_isdefault`         AS `icnutypdt_isdefault`,
       `echothree`.`iconusagetypedetails`.`icnutypdt_sortorder`         AS `icnutypdt_sortorder`
from `echothree`.`iconusagetypes`
         join `echothree`.`iconusagetypedetails`
where (`echothree`.`iconusagetypes`.`icnutyp_activedetailid` =
       `echothree`.`iconusagetypedetails`.`icnutypdt_iconusagetypedetailid`);

