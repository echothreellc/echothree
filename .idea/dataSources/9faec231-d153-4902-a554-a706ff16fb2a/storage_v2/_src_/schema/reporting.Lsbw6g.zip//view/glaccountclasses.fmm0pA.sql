create definer = echothree@`127.0.0.1` view glaccountclasses as
select `echothree`.`glaccountclasses`.`glacls_glaccountclassid`              AS `glacls_glaccountclassid`,
       `echothree`.`glaccountclassdetails`.`glaclsdt_glaccountclassname`     AS `glaclsdt_glaccountclassname`,
       `echothree`.`glaccountclassdetails`.`glaclsdt_parentglaccountclassid` AS `glaclsdt_parentglaccountclassid`,
       `echothree`.`glaccountclassdetails`.`glaclsdt_isdefault`              AS `glaclsdt_isdefault`,
       `echothree`.`glaccountclassdetails`.`glaclsdt_sortorder`              AS `glaclsdt_sortorder`
from `echothree`.`glaccountclasses`
         join `echothree`.`glaccountclassdetails`
where (`echothree`.`glaccountclasses`.`glacls_activedetailid` =
       `echothree`.`glaccountclassdetails`.`glaclsdt_glaccountclassdetailid`);

