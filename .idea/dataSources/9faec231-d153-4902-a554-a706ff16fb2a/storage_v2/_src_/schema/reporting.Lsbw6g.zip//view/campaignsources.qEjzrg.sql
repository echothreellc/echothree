create definer = echothree@`127.0.0.1` view campaignsources as
select `echothree`.`campaignsources`.`cmpgnsrc_campaignsourceid`           AS `cmpgnsrc_campaignsourceid`,
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_campaignsourcename` AS `cmpgnsrcdt_campaignsourcename`,
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_valuesha1hash`      AS `cmpgnsrcdt_valuesha1hash`,
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_value`              AS `cmpgnsrcdt_value`,
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_isdefault`          AS `cmpgnsrcdt_isdefault`,
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_sortorder`          AS `cmpgnsrcdt_sortorder`
from `echothree`.`campaignsources`
         join `echothree`.`campaignsourcedetails`
where (`echothree`.`campaignsources`.`cmpgnsrc_activedetailid` =
       `echothree`.`campaignsourcedetails`.`cmpgnsrcdt_campaignsourcedetailid`);

