create definer = echothree@`127.0.0.1` view entitytimeattributes as
select `echothree`.`entitytimeattributes`.`enta_entitytimeattributeid` AS `enta_entitytimeattributeid`,
       `echothree`.`entitytimeattributes`.`enta_ena_entityattributeid` AS `enta_ena_entityattributeid`,
       `echothree`.`entitytimeattributes`.`enta_eni_entityinstanceid`  AS `enta_eni_entityinstanceid`,
       `echothree`.`entitytimeattributes`.`enta_timeattribute`         AS `enta_timeattribute`
from `echothree`.`entitytimeattributes`
where (`echothree`.`entitytimeattributes`.`enta_thrutime` = 9223372036854775807);

