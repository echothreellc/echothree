create definer = echothree@`127.0.0.1` view forummessageblobattachments as
select `echothree`.`forummessageblobattachments`.`frmmsgbatt_forummessageblobattachmentid`       AS `frmmsgbatt_forummessageblobattachmentid`,
       `echothree`.`forummessageblobattachments`.`frmmsgbatt_frmmsgatt_forummessageattachmentid` AS `frmmsgbatt_frmmsgatt_forummessageattachmentid`,
       `echothree`.`forummessageblobattachments`.`frmmsgbatt_blob`                               AS `frmmsgbatt_blob`
from `echothree`.`forummessageblobattachments`
where (`echothree`.`forummessageblobattachments`.`frmmsgbatt_thrutime` = 9223372036854775807);

