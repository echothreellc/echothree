create definer = echothree@`127.0.0.1` view carrierserviceoptions as
select `echothree`.`carrierserviceoptions`.`crrsrvopt_carrierserviceoptionid`        AS `crrsrvopt_carrierserviceoptionid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_crrsrv_carrierserviceid`       AS `crrsrvopt_crrsrv_carrierserviceid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_crropt_carrieroptionid`        AS `crrsrvopt_crropt_carrieroptionid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_isrecommended`                 AS `crrsrvopt_isrecommended`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_isrequired`                    AS `crrsrvopt_isrequired`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_recommendedgeocodeselectorid`  AS `crrsrvopt_recommendedgeocodeselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_requiredgeocodeselectorid`     AS `crrsrvopt_requiredgeocodeselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_recommendeditemselectorid`     AS `crrsrvopt_recommendeditemselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_requireditemselectorid`        AS `crrsrvopt_requireditemselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_recommendedorderselectorid`    AS `crrsrvopt_recommendedorderselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_requiredorderselectorid`       AS `crrsrvopt_requiredorderselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_recommendedshipmentselectorid` AS `crrsrvopt_recommendedshipmentselectorid`,
       `echothree`.`carrierserviceoptions`.`crrsrvopt_requiredshipmentselectorid`    AS `crrsrvopt_requiredshipmentselectorid`
from `echothree`.`carrierserviceoptions`
where (`echothree`.`carrierserviceoptions`.`crrsrvopt_thrutime` = 9223372036854775807);

