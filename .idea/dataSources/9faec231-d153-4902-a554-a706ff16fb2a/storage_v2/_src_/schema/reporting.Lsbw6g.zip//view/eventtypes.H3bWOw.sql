create definer = echothree@`127.0.0.1` view eventtypes as
select `echothree`.`eventtypes`.`evty_eventtypeid`   AS `evty_eventtypeid`,
       `echothree`.`eventtypes`.`evty_eventtypename` AS `evty_eventtypename`
from `echothree`.`eventtypes`;

