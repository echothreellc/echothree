create definer = echothree@`127.0.0.1` view inventorylocationassignments as
select `echothree`.`inventorylocationassignments`.`invlocasgn_inventorylocationassignmentid` AS `invlocasgn_inventorylocationassignmentid`,
       `echothree`.`inventorylocationassignments`.`invlocasgn_lt_lotid`                      AS `invlocasgn_lt_lotid`,
       `echothree`.`inventorylocationassignments`.`invlocasgn_loc_locationid`                AS `invlocasgn_loc_locationid`,
       `echothree`.`inventorylocationassignments`.`invlocasgn_quantity`                      AS `invlocasgn_quantity`
from `echothree`.`inventorylocationassignments`
where (`echothree`.`inventorylocationassignments`.`invlocasgn_thrutime` = 9223372036854775807);

