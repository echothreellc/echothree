create definer = echothree@`127.0.0.1` view commentclobs as
select `echothree`.`commentclobs`.`cmntc_commentclobid`  AS `cmntc_commentclobid`,
       `echothree`.`commentclobs`.`cmntc_cmnt_commentid` AS `cmntc_cmnt_commentid`,
       `echothree`.`commentclobs`.`cmntc_clob`           AS `cmntc_clob`
from `echothree`.`commentclobs`
where (`echothree`.`commentclobs`.`cmntc_thrutime` = 9223372036854775807);

