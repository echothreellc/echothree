create definer = echothree@`127.0.0.1` view contentwebaddressdescriptions as
select `echothree`.`contentwebaddressdescriptions`.`cntwad_contentwebaddressdescriptionid` AS `cntwad_contentwebaddressdescriptionid`,
       `echothree`.`contentwebaddressdescriptions`.`cntwad_cntwa_contentwebaddressid`      AS `cntwad_cntwa_contentwebaddressid`,
       `echothree`.`contentwebaddressdescriptions`.`cntwad_lang_languageid`                AS `cntwad_lang_languageid`,
       `echothree`.`contentwebaddressdescriptions`.`cntwad_description`                    AS `cntwad_description`
from `echothree`.`contentwebaddressdescriptions`
where (`echothree`.`contentwebaddressdescriptions`.`cntwad_thrutime` = 9223372036854775807);

