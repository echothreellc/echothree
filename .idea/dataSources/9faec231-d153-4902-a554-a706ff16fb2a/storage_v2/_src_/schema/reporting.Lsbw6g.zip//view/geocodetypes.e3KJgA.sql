create definer = echothree@`127.0.0.1` view geocodetypes as
select `echothree`.`geocodetypes`.`geot_geocodetypeid`               AS `geot_geocodetypeid`,
       `echothree`.`geocodetypedetails`.`geotdt_geocodetypename`     AS `geotdt_geocodetypename`,
       `echothree`.`geocodetypedetails`.`geotdt_parentgeocodetypeid` AS `geotdt_parentgeocodetypeid`,
       `echothree`.`geocodetypedetails`.`geotdt_isdefault`           AS `geotdt_isdefault`,
       `echothree`.`geocodetypedetails`.`geotdt_sortorder`           AS `geotdt_sortorder`
from `echothree`.`geocodetypes`
         join `echothree`.`geocodetypedetails`
where (`echothree`.`geocodetypes`.`geot_activedetailid` =
       `echothree`.`geocodetypedetails`.`geotdt_geocodetypedetailid`);

