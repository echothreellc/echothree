create definer = echothree@`127.0.0.1` view carrieroptions as
select `echothree`.`carrieroptions`.`crropt_carrieroptionid`                       AS `crropt_carrieroptionid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_carrierpartyid`                AS `crroptdt_carrierpartyid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_carrieroptionname`             AS `crroptdt_carrieroptionname`,
       `echothree`.`carrieroptiondetails`.`crroptdt_isrecommended`                 AS `crroptdt_isrecommended`,
       `echothree`.`carrieroptiondetails`.`crroptdt_isrequired`                    AS `crroptdt_isrequired`,
       `echothree`.`carrieroptiondetails`.`crroptdt_recommendedgeocodeselectorid`  AS `crroptdt_recommendedgeocodeselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_requiredgeocodeselectorid`     AS `crroptdt_requiredgeocodeselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_recommendeditemselectorid`     AS `crroptdt_recommendeditemselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_requireditemselectorid`        AS `crroptdt_requireditemselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_recommendedorderselectorid`    AS `crroptdt_recommendedorderselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_requiredorderselectorid`       AS `crroptdt_requiredorderselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_recommendedshipmentselectorid` AS `crroptdt_recommendedshipmentselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_requiredshipmentselectorid`    AS `crroptdt_requiredshipmentselectorid`,
       `echothree`.`carrieroptiondetails`.`crroptdt_isdefault`                     AS `crroptdt_isdefault`,
       `echothree`.`carrieroptiondetails`.`crroptdt_sortorder`                     AS `crroptdt_sortorder`
from `echothree`.`carrieroptions`
         join `echothree`.`carrieroptiondetails`
where (`echothree`.`carrieroptions`.`crropt_activedetailid` =
       `echothree`.`carrieroptiondetails`.`crroptdt_carrieroptiondetailid`);

