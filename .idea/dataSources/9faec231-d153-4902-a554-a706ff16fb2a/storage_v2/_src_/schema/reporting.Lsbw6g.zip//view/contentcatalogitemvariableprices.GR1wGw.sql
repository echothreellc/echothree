create definer = echothree@`127.0.0.1` view contentcatalogitemvariableprices as
select `echothree`.`contentcatalogitemvariableprices`.`cntctivp_contentcatalogitemvariablepriceid` AS `cntctivp_contentcatalogitemvariablepriceid`,
       `echothree`.`contentcatalogitemvariableprices`.`cntctivp_cntcti_contentcatalogitemid`       AS `cntctivp_cntcti_contentcatalogitemid`,
       `echothree`.`contentcatalogitemvariableprices`.`cntctivp_minimumunitprice`                  AS `cntctivp_minimumunitprice`,
       `echothree`.`contentcatalogitemvariableprices`.`cntctivp_maximumunitprice`                  AS `cntctivp_maximumunitprice`,
       `echothree`.`contentcatalogitemvariableprices`.`cntctivp_unitpriceincrement`                AS `cntctivp_unitpriceincrement`
from `echothree`.`contentcatalogitemvariableprices`
where (`echothree`.`contentcatalogitemvariableprices`.`cntctivp_thrutime` = 9223372036854775807);

