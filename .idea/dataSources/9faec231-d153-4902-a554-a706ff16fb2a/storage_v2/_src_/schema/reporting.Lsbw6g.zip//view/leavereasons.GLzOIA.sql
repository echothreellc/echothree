create definer = echothree@`127.0.0.1` view leavereasons as
select `echothree`.`leavereasons`.`lvrsn_leavereasonid`           AS `lvrsn_leavereasonid`,
       `echothree`.`leavereasondetails`.`lvrsndt_leavereasonname` AS `lvrsndt_leavereasonname`,
       `echothree`.`leavereasondetails`.`lvrsndt_isdefault`       AS `lvrsndt_isdefault`,
       `echothree`.`leavereasondetails`.`lvrsndt_sortorder`       AS `lvrsndt_sortorder`
from `echothree`.`leavereasons`
         join `echothree`.`leavereasondetails`
where (`echothree`.`leavereasons`.`lvrsn_activedetailid` =
       `echothree`.`leavereasondetails`.`lvrsndt_leavereasondetailid`);

