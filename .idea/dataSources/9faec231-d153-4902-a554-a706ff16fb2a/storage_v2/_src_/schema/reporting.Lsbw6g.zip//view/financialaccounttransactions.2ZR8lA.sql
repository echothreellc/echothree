create definer = echothree@`127.0.0.1` view financialaccounttransactions as
select `echothree`.`financialaccounttransactions`.`finatrx_financialaccounttransactionid`                       AS `finatrx_financialaccounttransactionid`,
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_financialaccounttransactionname`             AS `finatrxdt_financialaccounttransactionname`,
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_fina_financialaccountid`                     AS `finatrxdt_fina_financialaccountid`,
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_fnatrxtyp_financialaccounttransactiontypeid` AS `finatrxdt_fnatrxtyp_financialaccounttransactiontypeid`,
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_amount`                                      AS `finatrxdt_amount`,
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_comment`                                     AS `finatrxdt_comment`
from `echothree`.`financialaccounttransactions`
         join `echothree`.`financialaccounttransactiondetails`
where (`echothree`.`financialaccounttransactions`.`finatrx_activedetailid` =
       `echothree`.`financialaccounttransactiondetails`.`finatrxdt_financialaccounttransactiondetailid`);

