create definer = echothree@`127.0.0.1` view lots as
select `echothree`.`lots`.`lt_lotid`                               AS `lt_lotid`,
       `echothree`.`lotdetails`.`ltdt_lotname`                     AS `ltdt_lotname`,
       `echothree`.`lotdetails`.`ltdt_ownerpartyid`                AS `ltdt_ownerpartyid`,
       `echothree`.`lotdetails`.`ltdt_itm_itemid`                  AS `ltdt_itm_itemid`,
       `echothree`.`lotdetails`.`ltdt_uomt_unitofmeasuretypeid`    AS `ltdt_uomt_unitofmeasuretypeid`,
       `echothree`.`lotdetails`.`ltdt_invcon_inventoryconditionid` AS `ltdt_invcon_inventoryconditionid`,
       `echothree`.`lotdetails`.`ltdt_quantity`                    AS `ltdt_quantity`,
       `echothree`.`lotdetails`.`ltdt_cur_currencyid`              AS `ltdt_cur_currencyid`,
       `echothree`.`lotdetails`.`ltdt_unitcost`                    AS `ltdt_unitcost`
from `echothree`.`lots`
         join `echothree`.`lotdetails`
where (`echothree`.`lots`.`lt_activedetailid` = `echothree`.`lotdetails`.`ltdt_lotdetailid`);

