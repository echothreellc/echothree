create definer = echothree@`127.0.0.1` view lettersourcedescriptions as
select `echothree`.`lettersourcedescriptions`.`lttrsrcd_lettersourcedescriptionid` AS `lttrsrcd_lettersourcedescriptionid`,
       `echothree`.`lettersourcedescriptions`.`lttrsrcd_lttrsrc_lettersourceid`    AS `lttrsrcd_lttrsrc_lettersourceid`,
       `echothree`.`lettersourcedescriptions`.`lttrsrcd_lang_languageid`           AS `lttrsrcd_lang_languageid`,
       `echothree`.`lettersourcedescriptions`.`lttrsrcd_description`               AS `lttrsrcd_description`
from `echothree`.`lettersourcedescriptions`
where (`echothree`.`lettersourcedescriptions`.`lttrsrcd_thrutime` = 9223372036854775807);

