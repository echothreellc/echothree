create definer = echothree@`127.0.0.1` view cacheclobentries as
select `echothree`.`cacheclobentries`.`ccent_cacheclobentryid`  AS `ccent_cacheclobentryid`,
       `echothree`.`cacheclobentries`.`ccent_cent_cacheentryid` AS `ccent_cent_cacheentryid`,
       `echothree`.`cacheclobentries`.`ccent_clob`              AS `ccent_clob`
from `echothree`.`cacheclobentries`;

