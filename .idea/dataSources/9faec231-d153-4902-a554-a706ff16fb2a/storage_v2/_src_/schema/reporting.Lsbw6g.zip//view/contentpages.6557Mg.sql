create definer = echothree@`127.0.0.1` view contentpages as
select `echothree`.`contentpages`.`cntp_contentpageid`                     AS `cntp_contentpageid`,
       `echothree`.`contentpagedetails`.`cntpdt_cnts_contentsectionid`     AS `cntpdt_cnts_contentsectionid`,
       `echothree`.`contentpagedetails`.`cntpdt_contentpagename`           AS `cntpdt_contentpagename`,
       `echothree`.`contentpagedetails`.`cntpdt_cntpl_contentpagelayoutid` AS `cntpdt_cntpl_contentpagelayoutid`,
       `echothree`.`contentpagedetails`.`cntpdt_isdefault`                 AS `cntpdt_isdefault`,
       `echothree`.`contentpagedetails`.`cntpdt_sortorder`                 AS `cntpdt_sortorder`
from `echothree`.`contentpages`
         join `echothree`.`contentpagedetails`
where (`echothree`.`contentpages`.`cntp_activedetailid` =
       `echothree`.`contentpagedetails`.`cntpdt_contentpagedetailid`);

