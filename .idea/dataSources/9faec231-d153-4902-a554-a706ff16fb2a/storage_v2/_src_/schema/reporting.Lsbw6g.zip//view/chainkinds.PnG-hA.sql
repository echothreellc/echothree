create definer = echothree@`127.0.0.1` view chainkinds as
select `echothree`.`chainkinds`.`chnk_chainkindid`           AS `chnk_chainkindid`,
       `echothree`.`chainkinddetails`.`chnkdt_chainkindname` AS `chnkdt_chainkindname`,
       `echothree`.`chainkinddetails`.`chnkdt_isdefault`     AS `chnkdt_isdefault`,
       `echothree`.`chainkinddetails`.`chnkdt_sortorder`     AS `chnkdt_sortorder`
from `echothree`.`chainkinds`
         join `echothree`.`chainkinddetails`
where (`echothree`.`chainkinds`.`chnk_activedetailid` = `echothree`.`chainkinddetails`.`chnkdt_chainkinddetailid`);

