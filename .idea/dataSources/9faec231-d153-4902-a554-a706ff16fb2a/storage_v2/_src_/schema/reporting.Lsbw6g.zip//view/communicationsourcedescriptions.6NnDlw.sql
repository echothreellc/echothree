create definer = echothree@`127.0.0.1` view communicationsourcedescriptions as
select `echothree`.`communicationsourcedescriptions`.`cmmnsrcd_communicationsourcedescriptionid` AS `cmmnsrcd_communicationsourcedescriptionid`,
       `echothree`.`communicationsourcedescriptions`.`cmmnsrcd_cmmnsrc_communicationsourceid`    AS `cmmnsrcd_cmmnsrc_communicationsourceid`,
       `echothree`.`communicationsourcedescriptions`.`cmmnsrcd_lang_languageid`                  AS `cmmnsrcd_lang_languageid`,
       `echothree`.`communicationsourcedescriptions`.`cmmnsrcd_description`                      AS `cmmnsrcd_description`
from `echothree`.`communicationsourcedescriptions`
where (`echothree`.`communicationsourcedescriptions`.`cmmnsrcd_thrutime` = 9223372036854775807);

