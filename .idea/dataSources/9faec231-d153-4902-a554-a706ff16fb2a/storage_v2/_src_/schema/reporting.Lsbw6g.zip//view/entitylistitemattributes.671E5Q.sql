create definer = echothree@`127.0.0.1` view entitylistitemattributes as
select `echothree`.`entitylistitemattributes`.`ela_entitylistitemattributeid` AS `ela_entitylistitemattributeid`,
       `echothree`.`entitylistitemattributes`.`ela_ena_entityattributeid`     AS `ela_ena_entityattributeid`,
       `echothree`.`entitylistitemattributes`.`ela_eni_entityinstanceid`      AS `ela_eni_entityinstanceid`,
       `echothree`.`entitylistitemattributes`.`ela_eli_entitylistitemid`      AS `ela_eli_entitylistitemid`
from `echothree`.`entitylistitemattributes`
where (`echothree`.`entitylistitemattributes`.`ela_thrutime` = 9223372036854775807);

