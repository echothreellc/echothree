create definer = echothree@`127.0.0.1` view geocodescopes as
select `echothree`.`geocodescopes`.`geos_geocodescopeid`           AS `geos_geocodescopeid`,
       `echothree`.`geocodescopedetails`.`geosdt_geocodescopename` AS `geosdt_geocodescopename`,
       `echothree`.`geocodescopedetails`.`geosdt_isdefault`        AS `geosdt_isdefault`,
       `echothree`.`geocodescopedetails`.`geosdt_sortorder`        AS `geosdt_sortorder`
from `echothree`.`geocodescopes`
         join `echothree`.`geocodescopedetails`
where (`echothree`.`geocodescopes`.`geos_activedetailid` =
       `echothree`.`geocodescopedetails`.`geosdt_geocodescopedetailid`);

