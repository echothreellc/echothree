create definer = echothree@`127.0.0.1` view contactmechanisms as
select `echothree`.`contactmechanisms`.`cmch_contactmechanismid`                 AS `cmch_contactmechanismid`,
       `echothree`.`contactmechanismdetails`.`cmchdt_contactmechanismname`       AS `cmchdt_contactmechanismname`,
       `echothree`.`contactmechanismdetails`.`cmchdt_cmt_contactmechanismtypeid` AS `cmchdt_cmt_contactmechanismtypeid`,
       `echothree`.`contactmechanismdetails`.`cmchdt_allowsolicitation`          AS `cmchdt_allowsolicitation`
from `echothree`.`contactmechanisms`
         join `echothree`.`contactmechanismdetails`
where (`echothree`.`contactmechanisms`.`cmch_activedetailid` =
       `echothree`.`contactmechanismdetails`.`cmchdt_contactmechanismdetailid`);

