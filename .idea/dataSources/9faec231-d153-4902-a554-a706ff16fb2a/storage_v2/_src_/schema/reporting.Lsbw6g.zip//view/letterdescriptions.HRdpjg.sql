create definer = echothree@`127.0.0.1` view letterdescriptions as
select `echothree`.`letterdescriptions`.`lttrd_letterdescriptionid` AS `lttrd_letterdescriptionid`,
       `echothree`.`letterdescriptions`.`lttrd_lttr_letterid`       AS `lttrd_lttr_letterid`,
       `echothree`.`letterdescriptions`.`lttrd_lang_languageid`     AS `lttrd_lang_languageid`,
       `echothree`.`letterdescriptions`.`lttrd_description`         AS `lttrd_description`
from `echothree`.`letterdescriptions`
where (`echothree`.`letterdescriptions`.`lttrd_thrutime` = 9223372036854775807);

