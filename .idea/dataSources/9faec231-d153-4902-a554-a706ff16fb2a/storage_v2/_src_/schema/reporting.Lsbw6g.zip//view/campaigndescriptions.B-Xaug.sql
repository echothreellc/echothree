create definer = echothree@`127.0.0.1` view campaigndescriptions as
select `echothree`.`campaigndescriptions`.`cmpgnd_campaigndescriptionid` AS `cmpgnd_campaigndescriptionid`,
       `echothree`.`campaigndescriptions`.`cmpgnd_cmpgn_campaignid`      AS `cmpgnd_cmpgn_campaignid`,
       `echothree`.`campaigndescriptions`.`cmpgnd_lang_languageid`       AS `cmpgnd_lang_languageid`,
       `echothree`.`campaigndescriptions`.`cmpgnd_description`           AS `cmpgnd_description`
from `echothree`.`campaigndescriptions`
where (`echothree`.`campaigndescriptions`.`cmpgnd_thrutime` = 9223372036854775807);

