create definer = echothree@`127.0.0.1` view entityattributeintegers as
select `echothree`.`entityattributeintegers`.`enai_entityattributeintegerid` AS `enai_entityattributeintegerid`,
       `echothree`.`entityattributeintegers`.`enai_ena_entityattributeid`    AS `enai_ena_entityattributeid`,
       `echothree`.`entityattributeintegers`.`enai_upperrangeintegervalue`   AS `enai_upperrangeintegervalue`,
       `echothree`.`entityattributeintegers`.`enai_upperlimitintegervalue`   AS `enai_upperlimitintegervalue`,
       `echothree`.`entityattributeintegers`.`enai_lowerlimitintegervalue`   AS `enai_lowerlimitintegervalue`,
       `echothree`.`entityattributeintegers`.`enai_lowerrangeintegervalue`   AS `enai_lowerrangeintegervalue`
from `echothree`.`entityattributeintegers`
where (`echothree`.`entityattributeintegers`.`enai_thrutime` = 9223372036854775807);

