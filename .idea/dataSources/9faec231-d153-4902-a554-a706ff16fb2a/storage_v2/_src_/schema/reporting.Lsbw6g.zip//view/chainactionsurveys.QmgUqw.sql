create definer = echothree@`127.0.0.1` view chainactionsurveys as
select `echothree`.`chainactionsurveys`.`chnactsrvy_chainactionsurveyid`  AS `chnactsrvy_chainactionsurveyid`,
       `echothree`.`chainactionsurveys`.`chnactsrvy_chnact_chainactionid` AS `chnactsrvy_chnact_chainactionid`,
       `echothree`.`chainactionsurveys`.`chnactsrvy_srvy_surveyid`        AS `chnactsrvy_srvy_surveyid`
from `echothree`.`chainactionsurveys`
where (`echothree`.`chainactionsurveys`.`chnactsrvy_thrutime` = 9223372036854775807);

