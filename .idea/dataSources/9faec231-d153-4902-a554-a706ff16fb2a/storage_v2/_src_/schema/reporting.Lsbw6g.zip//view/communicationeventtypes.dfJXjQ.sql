create definer = echothree@`127.0.0.1` view communicationeventtypes as
select `echothree`.`communicationeventtypes`.`cmmnevtyp_communicationeventtypeid`   AS `cmmnevtyp_communicationeventtypeid`,
       `echothree`.`communicationeventtypes`.`cmmnevtyp_communicationeventtypename` AS `cmmnevtyp_communicationeventtypename`,
       `echothree`.`communicationeventtypes`.`cmmnevtyp_isdefault`                  AS `cmmnevtyp_isdefault`,
       `echothree`.`communicationeventtypes`.`cmmnevtyp_sortorder`                  AS `cmmnevtyp_sortorder`
from `echothree`.`communicationeventtypes`;

