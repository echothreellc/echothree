create definer = echothree@`127.0.0.1` view communicationeventtypedescriptions as
select `echothree`.`communicationeventtypedescriptions`.`cmmnevtypd_communicationeventtypedescriptionid` AS `cmmnevtypd_communicationeventtypedescriptionid`,
       `echothree`.`communicationeventtypedescriptions`.`cmmnevtypd_cmmnevtyp_communicationeventtypeid`  AS `cmmnevtypd_cmmnevtyp_communicationeventtypeid`,
       `echothree`.`communicationeventtypedescriptions`.`cmmnevtypd_lang_languageid`                     AS `cmmnevtypd_lang_languageid`,
       `echothree`.`communicationeventtypedescriptions`.`cmmnevtypd_description`                         AS `cmmnevtypd_description`
from `echothree`.`communicationeventtypedescriptions`;

