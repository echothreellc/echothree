create definer = echothree@`127.0.0.1` view glaccounttypes as
select `echothree`.`glaccounttypes`.`glatyp_glaccounttypeid`   AS `glatyp_glaccounttypeid`,
       `echothree`.`glaccounttypes`.`glatyp_glaccounttypename` AS `glatyp_glaccounttypename`,
       `echothree`.`glaccounttypes`.`glatyp_isdefault`         AS `glatyp_isdefault`,
       `echothree`.`glaccounttypes`.`glatyp_sortorder`         AS `glatyp_sortorder`
from `echothree`.`glaccounttypes`;

