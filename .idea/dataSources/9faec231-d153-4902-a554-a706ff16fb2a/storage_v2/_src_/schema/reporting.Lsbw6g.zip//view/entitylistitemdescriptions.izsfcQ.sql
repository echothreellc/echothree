create definer = echothree@`127.0.0.1` view entitylistitemdescriptions as
select `echothree`.`entitylistitemdescriptions`.`elid_entitylistitemdescriptionid` AS `elid_entitylistitemdescriptionid`,
       `echothree`.`entitylistitemdescriptions`.`elid_eli_entitylistitemid`        AS `elid_eli_entitylistitemid`,
       `echothree`.`entitylistitemdescriptions`.`elid_lang_languageid`             AS `elid_lang_languageid`,
       `echothree`.`entitylistitemdescriptions`.`elid_description`                 AS `elid_description`
from `echothree`.`entitylistitemdescriptions`
where (`echothree`.`entitylistitemdescriptions`.`elid_thrutime` = 9223372036854775807);

