create definer = echothree@`127.0.0.1` view leavetypes as
select `echothree`.`leavetypes`.`lvtyp_leavetypeid`           AS `lvtyp_leavetypeid`,
       `echothree`.`leavetypedetails`.`lvtypdt_leavetypename` AS `lvtypdt_leavetypename`,
       `echothree`.`leavetypedetails`.`lvtypdt_isdefault`     AS `lvtypdt_isdefault`,
       `echothree`.`leavetypedetails`.`lvtypdt_sortorder`     AS `lvtypdt_sortorder`
from `echothree`.`leavetypes`
         join `echothree`.`leavetypedetails`
where (`echothree`.`leavetypes`.`lvtyp_activedetailid` = `echothree`.`leavetypedetails`.`lvtypdt_leavetypedetailid`);

