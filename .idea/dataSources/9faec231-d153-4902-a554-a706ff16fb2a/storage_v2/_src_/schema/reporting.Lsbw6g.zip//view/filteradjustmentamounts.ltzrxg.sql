create definer = echothree@`127.0.0.1` view filteradjustmentamounts as
select `echothree`.`filteradjustmentamounts`.`fltaa_filteradjustmentamountid` AS `fltaa_filteradjustmentamountid`,
       `echothree`.`filteradjustmentamounts`.`fltaa_flta_filteradjustmentid`  AS `fltaa_flta_filteradjustmentid`,
       `echothree`.`filteradjustmentamounts`.`fltaa_uomt_unitofmeasuretypeid` AS `fltaa_uomt_unitofmeasuretypeid`,
       `echothree`.`filteradjustmentamounts`.`fltaa_cur_currencyid`           AS `fltaa_cur_currencyid`,
       `echothree`.`filteradjustmentamounts`.`fltaa_amount`                   AS `fltaa_amount`
from `echothree`.`filteradjustmentamounts`
where (`echothree`.`filteradjustmentamounts`.`fltaa_thrutime` = 9223372036854775807);

