create definer = echothree@`127.0.0.1` view customers as
select `echothree`.`customers`.`cu_customerid`                    AS `cu_customerid`,
       `echothree`.`customers`.`cu_par_partyid`                   AS `cu_par_partyid`,
       `echothree`.`customers`.`cu_customername`                  AS `cu_customername`,
       `echothree`.`customers`.`cu_cuty_customertypeid`           AS `cu_cuty_customertypeid`,
       `echothree`.`customers`.`cu_initialofferuseid`             AS `cu_initialofferuseid`,
       `echothree`.`customers`.`cu_cnclplcy_cancellationpolicyid` AS `cu_cnclplcy_cancellationpolicyid`,
       `echothree`.`customers`.`cu_rtnplcy_returnpolicyid`        AS `cu_rtnplcy_returnpolicyid`,
       `echothree`.`customers`.`cu_arglaccountid`                 AS `cu_arglaccountid`,
       `echothree`.`customers`.`cu_holduntilcomplete`             AS `cu_holduntilcomplete`,
       `echothree`.`customers`.`cu_allowbackorders`               AS `cu_allowbackorders`,
       `echothree`.`customers`.`cu_allowsubstitutions`            AS `cu_allowsubstitutions`,
       `echothree`.`customers`.`cu_allowcombiningshipments`       AS `cu_allowcombiningshipments`,
       `echothree`.`customers`.`cu_requirereference`              AS `cu_requirereference`,
       `echothree`.`customers`.`cu_allowreferenceduplicates`      AS `cu_allowreferenceduplicates`,
       `echothree`.`customers`.`cu_referencevalidationpattern`    AS `cu_referencevalidationpattern`
from `echothree`.`customers`
where (`echothree`.`customers`.`cu_thrutime` = 9223372036854775807);

