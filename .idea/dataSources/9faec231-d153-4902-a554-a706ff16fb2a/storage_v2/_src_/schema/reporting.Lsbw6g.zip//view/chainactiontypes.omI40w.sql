create definer = echothree@`127.0.0.1` view chainactiontypes as
select `echothree`.`chainactiontypes`.`chnacttyp_chainactiontypeid`           AS `chnacttyp_chainactiontypeid`,
       `echothree`.`chainactiontypedetails`.`chnacttypdt_chainactiontypename` AS `chnacttypdt_chainactiontypename`,
       `echothree`.`chainactiontypedetails`.`chnacttypdt_allowmultiple`       AS `chnacttypdt_allowmultiple`,
       `echothree`.`chainactiontypedetails`.`chnacttypdt_isdefault`           AS `chnacttypdt_isdefault`,
       `echothree`.`chainactiontypedetails`.`chnacttypdt_sortorder`           AS `chnacttypdt_sortorder`
from `echothree`.`chainactiontypes`
         join `echothree`.`chainactiontypedetails`
where (`echothree`.`chainactiontypes`.`chnacttyp_activedetailid` =
       `echothree`.`chainactiontypedetails`.`chnacttypdt_chainactiontypedetailid`);

