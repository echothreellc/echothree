create definer = echothree@`127.0.0.1` view entityappearances as
select `echothree`.`entityappearances`.`eniapprnc_entityappearanceid`   AS `eniapprnc_entityappearanceid`,
       `echothree`.`entityappearances`.`eniapprnc_eni_entityinstanceid` AS `eniapprnc_eni_entityinstanceid`,
       `echothree`.`entityappearances`.`eniapprnc_apprnc_appearanceid`  AS `eniapprnc_apprnc_appearanceid`
from `echothree`.`entityappearances`
where (`echothree`.`entityappearances`.`eniapprnc_thrutime` = 9223372036854775807);

