create definer = echothree@`127.0.0.1` view batchaliastypes as
select `echothree`.`batchaliastypes`.`btchat_batchaliastypeid`            AS `btchat_batchaliastypeid`,
       `echothree`.`batchaliastypedetails`.`btchatdt_btchtyp_batchtypeid` AS `btchatdt_btchtyp_batchtypeid`,
       `echothree`.`batchaliastypedetails`.`btchatdt_batchaliastypename`  AS `btchatdt_batchaliastypename`,
       `echothree`.`batchaliastypedetails`.`btchatdt_validationpattern`   AS `btchatdt_validationpattern`,
       `echothree`.`batchaliastypedetails`.`btchatdt_isdefault`           AS `btchatdt_isdefault`,
       `echothree`.`batchaliastypedetails`.`btchatdt_sortorder`           AS `btchatdt_sortorder`
from `echothree`.`batchaliastypes`
         join `echothree`.`batchaliastypedetails`
where (`echothree`.`batchaliastypes`.`btchat_activedetailid` =
       `echothree`.`batchaliastypedetails`.`btchatdt_batchaliastypedetailid`);

