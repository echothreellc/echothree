create definer = echothree@`127.0.0.1` view itemblobdescriptions as
select `echothree`.`itemblobdescriptions`.`ibdesc_itemblobdescriptionid`   AS `ibdesc_itemblobdescriptionid`,
       `echothree`.`itemblobdescriptions`.`ibdesc_idesc_itemdescriptionid` AS `ibdesc_idesc_itemdescriptionid`,
       `echothree`.`itemblobdescriptions`.`ibdesc_blobdescription`         AS `ibdesc_blobdescription`
from `echothree`.`itemblobdescriptions`
where (`echothree`.`itemblobdescriptions`.`ibdesc_thrutime` = 9223372036854775807);

