create definer = echothree@`127.0.0.1` view forumroletypes as
select `echothree`.`forumroletypes`.`frmrtyp_forumroletypeid`   AS `frmrtyp_forumroletypeid`,
       `echothree`.`forumroletypes`.`frmrtyp_forumroletypename` AS `frmrtyp_forumroletypename`,
       `echothree`.`forumroletypes`.`frmrtyp_isdefault`         AS `frmrtyp_isdefault`,
       `echothree`.`forumroletypes`.`frmrtyp_sortorder`         AS `frmrtyp_sortorder`
from `echothree`.`forumroletypes`;

