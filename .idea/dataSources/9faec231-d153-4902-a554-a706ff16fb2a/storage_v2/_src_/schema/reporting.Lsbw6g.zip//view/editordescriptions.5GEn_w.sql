create definer = echothree@`127.0.0.1` view editordescriptions as
select `echothree`.`editordescriptions`.`edtrd_editordescriptionid` AS `edtrd_editordescriptionid`,
       `echothree`.`editordescriptions`.`edtrd_edtr_editorid`       AS `edtrd_edtr_editorid`,
       `echothree`.`editordescriptions`.`edtrd_lang_languageid`     AS `edtrd_lang_languageid`,
       `echothree`.`editordescriptions`.`edtrd_description`         AS `edtrd_description`
from `echothree`.`editordescriptions`
where (`echothree`.`editordescriptions`.`edtrd_thrutime` = 9223372036854775807);

