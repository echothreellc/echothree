create definer = echothree@`127.0.0.1` view inventoryconditionuses as
select `echothree`.`inventoryconditionuses`.`invconu_inventoryconditionuseid`              AS `invconu_inventoryconditionuseid`,
       `echothree`.`inventoryconditionuses`.`invconu_invconut_inventoryconditionusetypeid` AS `invconu_invconut_inventoryconditionusetypeid`,
       `echothree`.`inventoryconditionuses`.`invconu_invcon_inventoryconditionid`          AS `invconu_invcon_inventoryconditionid`,
       `echothree`.`inventoryconditionuses`.`invconu_isdefault`                            AS `invconu_isdefault`
from `echothree`.`inventoryconditionuses`
where (`echothree`.`inventoryconditionuses`.`invconu_thrutime` = 9223372036854775807);

