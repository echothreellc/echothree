create definer = echothree@`127.0.0.1` view financialaccountaliastypedescriptions as
select `echothree`.`financialaccountaliastypedescriptions`.`finaatd_financialaccountaliastypedescriptionid` AS `finaatd_financialaccountaliastypedescriptionid`,
       `echothree`.`financialaccountaliastypedescriptions`.`finaatd_finaat_financialaccountaliastypeid`     AS `finaatd_finaat_financialaccountaliastypeid`,
       `echothree`.`financialaccountaliastypedescriptions`.`finaatd_lang_languageid`                        AS `finaatd_lang_languageid`,
       `echothree`.`financialaccountaliastypedescriptions`.`finaatd_description`                            AS `finaatd_description`
from `echothree`.`financialaccountaliastypedescriptions`
where (`echothree`.`financialaccountaliastypedescriptions`.`finaatd_thrutime` = 9223372036854775807);

