create definer = echothree@`127.0.0.1` view itemimagetypedescriptions as
select `echothree`.`itemimagetypedescriptions`.`iimgtd_itemimagetypedescriptionid` AS `iimgtd_itemimagetypedescriptionid`,
       `echothree`.`itemimagetypedescriptions`.`iimgtd_iimgt_itemimagetypeid`      AS `iimgtd_iimgt_itemimagetypeid`,
       `echothree`.`itemimagetypedescriptions`.`iimgtd_lang_languageid`            AS `iimgtd_lang_languageid`,
       `echothree`.`itemimagetypedescriptions`.`iimgtd_description`                AS `iimgtd_description`
from `echothree`.`itemimagetypedescriptions`
where (`echothree`.`itemimagetypedescriptions`.`iimgtd_thrutime` = 9223372036854775807);

