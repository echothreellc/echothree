create definer = echothree@`127.0.0.1` view itempackcheckrequirements as
select `echothree`.`itempackcheckrequirements`.`ipcr_itempackcheckrequirementid` AS `ipcr_itempackcheckrequirementid`,
       `echothree`.`itempackcheckrequirements`.`ipcr_itm_itemid`                 AS `ipcr_itm_itemid`,
       `echothree`.`itempackcheckrequirements`.`ipcr_uomt_unitofmeasuretypeid`   AS `ipcr_uomt_unitofmeasuretypeid`,
       `echothree`.`itempackcheckrequirements`.`ipcr_minimumquantity`            AS `ipcr_minimumquantity`,
       `echothree`.`itempackcheckrequirements`.`ipcr_maximumquantity`            AS `ipcr_maximumquantity`
from `echothree`.`itempackcheckrequirements`
where (`echothree`.`itempackcheckrequirements`.`ipcr_thrutime` = 9223372036854775807);

