create definer = echothree@`127.0.0.1` view cancellationkinds as
select `echothree`.`cancellationkinds`.`cnclk_cancellationkindid`                 AS `cnclk_cancellationkindid`,
       `echothree`.`cancellationkinddetails`.`cnclkdt_cancellationkindname`       AS `cnclkdt_cancellationkindname`,
       `echothree`.`cancellationkinddetails`.`cnclkdt_cancellationsequencetypeid` AS `cnclkdt_cancellationsequencetypeid`,
       `echothree`.`cancellationkinddetails`.`cnclkdt_isdefault`                  AS `cnclkdt_isdefault`,
       `echothree`.`cancellationkinddetails`.`cnclkdt_sortorder`                  AS `cnclkdt_sortorder`
from `echothree`.`cancellationkinds`
         join `echothree`.`cancellationkinddetails`
where (`echothree`.`cancellationkinds`.`cnclk_activedetailid` =
       `echothree`.`cancellationkinddetails`.`cnclkdt_cancellationkinddetailid`);

