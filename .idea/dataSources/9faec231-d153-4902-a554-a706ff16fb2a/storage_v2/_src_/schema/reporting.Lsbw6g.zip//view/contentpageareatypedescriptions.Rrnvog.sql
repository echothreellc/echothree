create definer = echothree@`127.0.0.1` view contentpageareatypedescriptions as
select `echothree`.`contentpageareatypedescriptions`.`cntpatd_contentpageareatypedescriptionid` AS `cntpatd_contentpageareatypedescriptionid`,
       `echothree`.`contentpageareatypedescriptions`.`cntpatd_cntpat_contentpageareatypeid`     AS `cntpatd_cntpat_contentpageareatypeid`,
       `echothree`.`contentpageareatypedescriptions`.`cntpatd_lang_languageid`                  AS `cntpatd_lang_languageid`,
       `echothree`.`contentpageareatypedescriptions`.`cntpatd_description`                      AS `cntpatd_description`
from `echothree`.`contentpageareatypedescriptions`;

