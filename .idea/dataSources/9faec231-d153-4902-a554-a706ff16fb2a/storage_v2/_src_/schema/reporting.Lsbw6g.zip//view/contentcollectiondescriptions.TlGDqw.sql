create definer = echothree@`127.0.0.1` view contentcollectiondescriptions as
select `echothree`.`contentcollectiondescriptions`.`cntcd_contentcollectiondescriptionid` AS `cntcd_contentcollectiondescriptionid`,
       `echothree`.`contentcollectiondescriptions`.`cntcd_cntc_contentcollectionid`       AS `cntcd_cntc_contentcollectionid`,
       `echothree`.`contentcollectiondescriptions`.`cntcd_lang_languageid`                AS `cntcd_lang_languageid`,
       `echothree`.`contentcollectiondescriptions`.`cntcd_description`                    AS `cntcd_description`
from `echothree`.`contentcollectiondescriptions`
where (`echothree`.`contentcollectiondescriptions`.`cntcd_thrutime` = 9223372036854775807);

