create definer = echothree@`127.0.0.1` view itemcategorydescriptions as
select `echothree`.`itemcategorydescriptions`.`icd_itemcategorydescriptionid` AS `icd_itemcategorydescriptionid`,
       `echothree`.`itemcategorydescriptions`.`icd_ic_itemcategoryid`         AS `icd_ic_itemcategoryid`,
       `echothree`.`itemcategorydescriptions`.`icd_lang_languageid`           AS `icd_lang_languageid`,
       `echothree`.`itemcategorydescriptions`.`icd_description`               AS `icd_description`
from `echothree`.`itemcategorydescriptions`
where (`echothree`.`itemcategorydescriptions`.`icd_thrutime` = 9223372036854775807);

