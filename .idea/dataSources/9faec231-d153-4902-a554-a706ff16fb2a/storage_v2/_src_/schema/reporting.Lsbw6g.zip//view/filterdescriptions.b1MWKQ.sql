create definer = echothree@`127.0.0.1` view filterdescriptions as
select `echothree`.`filterdescriptions`.`fltd_filterdescriptionid` AS `fltd_filterdescriptionid`,
       `echothree`.`filterdescriptions`.`fltd_flt_filterid`        AS `fltd_flt_filterid`,
       `echothree`.`filterdescriptions`.`fltd_lang_languageid`     AS `fltd_lang_languageid`,
       `echothree`.`filterdescriptions`.`fltd_description`         AS `fltd_description`
from `echothree`.`filterdescriptions`
where (`echothree`.`filterdescriptions`.`fltd_thrutime` = 9223372036854775807);

