create definer = echothree@`127.0.0.1` view forummimetypes as
select `echothree`.`forummimetypes`.`frmmtyp_forummimetypeid` AS `frmmtyp_forummimetypeid`,
       `echothree`.`forummimetypes`.`frmmtyp_frm_forumid`     AS `frmmtyp_frm_forumid`,
       `echothree`.`forummimetypes`.`frmmtyp_mtyp_mimetypeid` AS `frmmtyp_mtyp_mimetypeid`,
       `echothree`.`forummimetypes`.`frmmtyp_isdefault`       AS `frmmtyp_isdefault`,
       `echothree`.`forummimetypes`.`frmmtyp_sortorder`       AS `frmmtyp_sortorder`
from `echothree`.`forummimetypes`
where (`echothree`.`forummimetypes`.`frmmtyp_thrutime` = 9223372036854775807);

