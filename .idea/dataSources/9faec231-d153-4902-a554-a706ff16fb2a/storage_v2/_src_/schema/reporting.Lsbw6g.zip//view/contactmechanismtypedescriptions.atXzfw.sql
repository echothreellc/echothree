create definer = echothree@`127.0.0.1` view contactmechanismtypedescriptions as
select `echothree`.`contactmechanismtypedescriptions`.`cmtd_contactmechanismtypedescriptionid` AS `cmtd_contactmechanismtypedescriptionid`,
       `echothree`.`contactmechanismtypedescriptions`.`cmtd_cmt_contactmechanismtypeid`        AS `cmtd_cmt_contactmechanismtypeid`,
       `echothree`.`contactmechanismtypedescriptions`.`cmtd_lang_languageid`                   AS `cmtd_lang_languageid`,
       `echothree`.`contactmechanismtypedescriptions`.`cmtd_description`                       AS `cmtd_description`
from `echothree`.`contactmechanismtypedescriptions`;

