create definer = echothree@`127.0.0.1` view entitygeopointattributes as
select `echothree`.`entitygeopointattributes`.`engeopnta_entitygeopointattributeid` AS `engeopnta_entitygeopointattributeid`,
       `echothree`.`entitygeopointattributes`.`engeopnta_ena_entityattributeid`     AS `engeopnta_ena_entityattributeid`,
       `echothree`.`entitygeopointattributes`.`engeopnta_eni_entityinstanceid`      AS `engeopnta_eni_entityinstanceid`,
       `echothree`.`entitygeopointattributes`.`engeopnta_latitude`                  AS `engeopnta_latitude`,
       `echothree`.`entitygeopointattributes`.`engeopnta_longitude`                 AS `engeopnta_longitude`,
       `echothree`.`entitygeopointattributes`.`engeopnta_elevation`                 AS `engeopnta_elevation`,
       `echothree`.`entitygeopointattributes`.`engeopnta_altitude`                  AS `engeopnta_altitude`
from `echothree`.`entitygeopointattributes`
where (`echothree`.`entitygeopointattributes`.`engeopnta_thrutime` = 9223372036854775807);

