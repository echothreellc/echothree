create definer = echothree@`127.0.0.1` view commentblobs as
select `echothree`.`commentblobs`.`cmntb_commentblobid`  AS `cmntb_commentblobid`,
       `echothree`.`commentblobs`.`cmntb_cmnt_commentid` AS `cmntb_cmnt_commentid`,
       `echothree`.`commentblobs`.`cmntb_blob`           AS `cmntb_blob`
from `echothree`.`commentblobs`
where (`echothree`.`commentblobs`.`cmntb_thrutime` = 9223372036854775807);

