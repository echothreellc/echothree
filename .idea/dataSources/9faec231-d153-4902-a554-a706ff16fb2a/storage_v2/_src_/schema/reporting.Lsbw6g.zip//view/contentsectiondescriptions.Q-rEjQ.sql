create definer = echothree@`127.0.0.1` view contentsectiondescriptions as
select `echothree`.`contentsectiondescriptions`.`cntsd_contentsectiondescriptionid` AS `cntsd_contentsectiondescriptionid`,
       `echothree`.`contentsectiondescriptions`.`cntsd_cnts_contentsectionid`       AS `cntsd_cnts_contentsectionid`,
       `echothree`.`contentsectiondescriptions`.`cntsd_lang_languageid`             AS `cntsd_lang_languageid`,
       `echothree`.`contentsectiondescriptions`.`cntsd_description`                 AS `cntsd_description`
from `echothree`.`contentsectiondescriptions`
where (`echothree`.`contentsectiondescriptions`.`cntsd_thrutime` = 9223372036854775807);

