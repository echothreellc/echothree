create definer = echothree@`127.0.0.1` view eventgroups as
select `echothree`.`eventgroups`.`evgrp_eventgroupid`           AS `evgrp_eventgroupid`,
       `echothree`.`eventgroupdetails`.`evgrpdt_eventgroupname` AS `evgrpdt_eventgroupname`
from `echothree`.`eventgroups`
         join `echothree`.`eventgroupdetails`
where (`echothree`.`eventgroups`.`evgrp_activedetailid` = `echothree`.`eventgroupdetails`.`evgrpdt_eventgroupdetailid`);

