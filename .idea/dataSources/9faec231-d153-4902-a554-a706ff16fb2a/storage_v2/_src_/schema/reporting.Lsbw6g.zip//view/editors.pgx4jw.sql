create definer = echothree@`127.0.0.1` view editors as
select `echothree`.`editors`.`edtr_editorid`              AS `edtr_editorid`,
       `echothree`.`editordetails`.`edtrdt_editorname`    AS `edtrdt_editorname`,
       `echothree`.`editordetails`.`edtrdt_hasdimensions` AS `edtrdt_hasdimensions`,
       `echothree`.`editordetails`.`edtrdt_minimumheight` AS `edtrdt_minimumheight`,
       `echothree`.`editordetails`.`edtrdt_minimumwidth`  AS `edtrdt_minimumwidth`,
       `echothree`.`editordetails`.`edtrdt_maximumheight` AS `edtrdt_maximumheight`,
       `echothree`.`editordetails`.`edtrdt_maximumwidth`  AS `edtrdt_maximumwidth`,
       `echothree`.`editordetails`.`edtrdt_defaultheight` AS `edtrdt_defaultheight`,
       `echothree`.`editordetails`.`edtrdt_defaultwidth`  AS `edtrdt_defaultwidth`,
       `echothree`.`editordetails`.`edtrdt_isdefault`     AS `edtrdt_isdefault`,
       `echothree`.`editordetails`.`edtrdt_sortorder`     AS `edtrdt_sortorder`
from `echothree`.`editors`
         join `echothree`.`editordetails`
where (`echothree`.`editors`.`edtr_activedetailid` = `echothree`.`editordetails`.`edtrdt_editordetailid`);

