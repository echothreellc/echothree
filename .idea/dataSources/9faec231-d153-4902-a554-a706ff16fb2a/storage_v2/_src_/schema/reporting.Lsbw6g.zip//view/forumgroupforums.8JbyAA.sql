create definer = echothree@`127.0.0.1` view forumgroupforums as
select `echothree`.`forumgroupforums`.`frmgrpfrm_forumgroupforumid`   AS `frmgrpfrm_forumgroupforumid`,
       `echothree`.`forumgroupforums`.`frmgrpfrm_frmgrp_forumgroupid` AS `frmgrpfrm_frmgrp_forumgroupid`,
       `echothree`.`forumgroupforums`.`frmgrpfrm_frm_forumid`         AS `frmgrpfrm_frm_forumid`,
       `echothree`.`forumgroupforums`.`frmgrpfrm_isdefault`           AS `frmgrpfrm_isdefault`,
       `echothree`.`forumgroupforums`.`frmgrpfrm_sortorder`           AS `frmgrpfrm_sortorder`
from `echothree`.`forumgroupforums`
where (`echothree`.`forumgroupforums`.`frmgrpfrm_thrutime` = 9223372036854775807);

