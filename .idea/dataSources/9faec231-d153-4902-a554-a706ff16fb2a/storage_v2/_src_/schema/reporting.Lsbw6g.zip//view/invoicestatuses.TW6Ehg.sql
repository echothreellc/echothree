create definer = echothree@`127.0.0.1` view invoicestatuses as
select `echothree`.`invoicestatuses`.`invcst_invoicestatusid`     AS `invcst_invoicestatusid`,
       `echothree`.`invoicestatuses`.`invcst_invc_invoiceid`      AS `invcst_invc_invoiceid`,
       `echothree`.`invoicestatuses`.`invcst_invoicelinesequence` AS `invcst_invoicelinesequence`
from `echothree`.`invoicestatuses`;

