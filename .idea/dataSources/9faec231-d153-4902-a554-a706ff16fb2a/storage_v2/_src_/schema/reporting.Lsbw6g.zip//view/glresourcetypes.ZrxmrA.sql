create definer = echothree@`127.0.0.1` view glresourcetypes as
select `echothree`.`glresourcetypes`.`glrtyp_glresourcetypeid`           AS `glrtyp_glresourcetypeid`,
       `echothree`.`glresourcetypedetails`.`glrtypdt_glresourcetypename` AS `glrtypdt_glresourcetypename`,
       `echothree`.`glresourcetypedetails`.`glrtypdt_isdefault`          AS `glrtypdt_isdefault`,
       `echothree`.`glresourcetypedetails`.`glrtypdt_sortorder`          AS `glrtypdt_sortorder`
from `echothree`.`glresourcetypes`
         join `echothree`.`glresourcetypedetails`
where (`echothree`.`glresourcetypes`.`glrtyp_activedetailid` =
       `echothree`.`glresourcetypedetails`.`glrtypdt_glresourcetypedetailid`);

