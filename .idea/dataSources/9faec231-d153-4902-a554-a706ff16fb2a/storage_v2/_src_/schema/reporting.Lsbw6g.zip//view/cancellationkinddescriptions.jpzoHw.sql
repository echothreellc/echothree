create definer = echothree@`127.0.0.1` view cancellationkinddescriptions as
select `echothree`.`cancellationkinddescriptions`.`cnclkd_cancellationkinddescriptionid` AS `cnclkd_cancellationkinddescriptionid`,
       `echothree`.`cancellationkinddescriptions`.`cnclkd_cnclk_cancellationkindid`      AS `cnclkd_cnclk_cancellationkindid`,
       `echothree`.`cancellationkinddescriptions`.`cnclkd_lang_languageid`               AS `cnclkd_lang_languageid`,
       `echothree`.`cancellationkinddescriptions`.`cnclkd_description`                   AS `cnclkd_description`
from `echothree`.`cancellationkinddescriptions`
where (`echothree`.`cancellationkinddescriptions`.`cnclkd_thrutime` = 9223372036854775807);

