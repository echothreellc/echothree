create definer = echothree@`127.0.0.1` view itemusetypedescriptions as
select `echothree`.`itemusetypedescriptions`.`iutypd_itemusetypedescriptionid` AS `iutypd_itemusetypedescriptionid`,
       `echothree`.`itemusetypedescriptions`.`iutypd_iutyp_itemusetypeid`      AS `iutypd_iutyp_itemusetypeid`,
       `echothree`.`itemusetypedescriptions`.`iutypd_lang_languageid`          AS `iutypd_lang_languageid`,
       `echothree`.`itemusetypedescriptions`.`iutypd_description`              AS `iutypd_description`
from `echothree`.`itemusetypedescriptions`;

