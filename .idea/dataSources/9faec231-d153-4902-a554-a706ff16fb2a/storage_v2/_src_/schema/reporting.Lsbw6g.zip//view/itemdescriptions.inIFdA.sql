create definer = echothree@`127.0.0.1` view itemdescriptions as
select `echothree`.`itemdescriptions`.`idesc_itemdescriptionid`                 AS `idesc_itemdescriptionid`,
       `echothree`.`itemdescriptiondetails`.`idescdt_idt_itemdescriptiontypeid` AS `idescdt_idt_itemdescriptiontypeid`,
       `echothree`.`itemdescriptiondetails`.`idescdt_itm_itemid`                AS `idescdt_itm_itemid`,
       `echothree`.`itemdescriptiondetails`.`idescdt_lang_languageid`           AS `idescdt_lang_languageid`,
       `echothree`.`itemdescriptiondetails`.`idescdt_mtyp_mimetypeid`           AS `idescdt_mtyp_mimetypeid`
from `echothree`.`itemdescriptions`
         join `echothree`.`itemdescriptiondetails`
where (`echothree`.`itemdescriptions`.`idesc_activedetailid` =
       `echothree`.`itemdescriptiondetails`.`idescdt_itemdescriptiondetailid`);

