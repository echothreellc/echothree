create definer = echothree@`127.0.0.1` view invoicelinetypedescriptions as
select `echothree`.`invoicelinetypedescriptions`.`invcltypd_invoicelinetypedescriptionid` AS `invcltypd_invoicelinetypedescriptionid`,
       `echothree`.`invoicelinetypedescriptions`.`invcltypd_invcltyp_invoicelinetypeid`   AS `invcltypd_invcltyp_invoicelinetypeid`,
       `echothree`.`invoicelinetypedescriptions`.`invcltypd_lang_languageid`              AS `invcltypd_lang_languageid`,
       `echothree`.`invoicelinetypedescriptions`.`invcltypd_description`                  AS `invcltypd_description`
from `echothree`.`invoicelinetypedescriptions`
where (`echothree`.`invoicelinetypedescriptions`.`invcltypd_thrutime` = 9223372036854775807);

