create definer = echothree@`127.0.0.1` view contactmechanismaliases as
select `echothree`.`contactmechanismaliases`.`cmchal_contactmechanismaliasid`               AS `cmchal_contactmechanismaliasid`,
       `echothree`.`contactmechanismaliases`.`cmchal_cmch_contactmechanismid`               AS `cmchal_cmch_contactmechanismid`,
       `echothree`.`contactmechanismaliases`.`cmchal_cmchaltyp_contactmechanismaliastypeid` AS `cmchal_cmchaltyp_contactmechanismaliastypeid`,
       `echothree`.`contactmechanismaliases`.`cmchal_alias`                                 AS `cmchal_alias`
from `echothree`.`contactmechanismaliases`
where (`echothree`.`contactmechanismaliases`.`cmchal_thrutime` = 9223372036854775807);

