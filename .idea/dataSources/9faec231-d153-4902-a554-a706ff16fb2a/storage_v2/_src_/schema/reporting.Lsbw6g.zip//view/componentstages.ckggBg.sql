create definer = echothree@`127.0.0.1` view componentstages as
select `echothree`.`componentstages`.`cstg_componentstageid`   AS `cstg_componentstageid`,
       `echothree`.`componentstages`.`cstg_componentstagename` AS `cstg_componentstagename`,
       `echothree`.`componentstages`.`cstg_description`        AS `cstg_description`,
       `echothree`.`componentstages`.`cstg_relativeage`        AS `cstg_relativeage`
from `echothree`.`componentstages`;

