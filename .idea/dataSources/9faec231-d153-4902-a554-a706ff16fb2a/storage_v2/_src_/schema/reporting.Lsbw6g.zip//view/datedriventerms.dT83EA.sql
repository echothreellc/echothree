create definer = echothree@`127.0.0.1` view datedriventerms as
select `echothree`.`datedriventerms`.`ddtrm_datedriventermid`         AS `ddtrm_datedriventermid`,
       `echothree`.`datedriventerms`.`ddtrm_trm_termid`               AS `ddtrm_trm_termid`,
       `echothree`.`datedriventerms`.`ddtrm_netduedayofmonth`         AS `ddtrm_netduedayofmonth`,
       `echothree`.`datedriventerms`.`ddtrm_duenextmonthdays`         AS `ddtrm_duenextmonthdays`,
       `echothree`.`datedriventerms`.`ddtrm_discountpercentage`       AS `ddtrm_discountpercentage`,
       `echothree`.`datedriventerms`.`ddtrm_discountbeforedayofmonth` AS `ddtrm_discountbeforedayofmonth`
from `echothree`.`datedriventerms`
where (`echothree`.`datedriventerms`.`ddtrm_thrutime` = 9223372036854775807);

