create definer = echothree@`127.0.0.1` view locationusetypes as
select `echothree`.`locationusetypes`.`locutyp_locationusetypeid`   AS `locutyp_locationusetypeid`,
       `echothree`.`locationusetypes`.`locutyp_locationusetypename` AS `locutyp_locationusetypename`,
       `echothree`.`locationusetypes`.`locutyp_allowmultiple`       AS `locutyp_allowmultiple`,
       `echothree`.`locationusetypes`.`locutyp_isdefault`           AS `locutyp_isdefault`,
       `echothree`.`locationusetypes`.`locutyp_sortorder`           AS `locutyp_sortorder`
from `echothree`.`locationusetypes`;

