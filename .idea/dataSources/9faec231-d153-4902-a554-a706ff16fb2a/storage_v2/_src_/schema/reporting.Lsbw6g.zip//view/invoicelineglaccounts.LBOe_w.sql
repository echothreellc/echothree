create definer = echothree@`127.0.0.1` view invoicelineglaccounts as
select `echothree`.`invoicelineglaccounts`.`invclgla_invoicelineglaccountid` AS `invclgla_invoicelineglaccountid`,
       `echothree`.`invoicelineglaccounts`.`invclgla_invcl_invoicelineid`    AS `invclgla_invcl_invoicelineid`,
       `echothree`.`invoicelineglaccounts`.`invclgla_gla_glaccountid`        AS `invclgla_gla_glaccountid`
from `echothree`.`invoicelineglaccounts`
where (`echothree`.`invoicelineglaccounts`.`invclgla_thrutime` = 9223372036854775807);

