create definer = echothree@`127.0.0.1` view entityattributedescriptions as
select `echothree`.`entityattributedescriptions`.`enad_entityattributedescriptionid` AS `enad_entityattributedescriptionid`,
       `echothree`.`entityattributedescriptions`.`enad_ena_entityattributeid`        AS `enad_ena_entityattributeid`,
       `echothree`.`entityattributedescriptions`.`enad_lang_languageid`              AS `enad_lang_languageid`,
       `echothree`.`entityattributedescriptions`.`enad_description`                  AS `enad_description`
from `echothree`.`entityattributedescriptions`
where (`echothree`.`entityattributedescriptions`.`enad_thrutime` = 9223372036854775807);

