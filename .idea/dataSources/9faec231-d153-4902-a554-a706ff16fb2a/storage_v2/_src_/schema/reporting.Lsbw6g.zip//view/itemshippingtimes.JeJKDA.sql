create definer = echothree@`127.0.0.1` view itemshippingtimes as
select `echothree`.`itemshippingtimes`.`istim_itemshippingtimeid`  AS `istim_itemshippingtimeid`,
       `echothree`.`itemshippingtimes`.`istim_itm_itemid`          AS `istim_itm_itemid`,
       `echothree`.`itemshippingtimes`.`istim_cuty_customertypeid` AS `istim_cuty_customertypeid`,
       `echothree`.`itemshippingtimes`.`istim_shippingstarttime`   AS `istim_shippingstarttime`,
       `echothree`.`itemshippingtimes`.`istim_shippingendtime`     AS `istim_shippingendtime`
from `echothree`.`itemshippingtimes`
where (`echothree`.`itemshippingtimes`.`istim_thrutime` = 9223372036854775807);

