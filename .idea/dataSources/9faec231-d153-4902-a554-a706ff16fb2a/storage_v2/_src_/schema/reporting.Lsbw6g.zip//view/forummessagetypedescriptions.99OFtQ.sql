create definer = echothree@`127.0.0.1` view forummessagetypedescriptions as
select `echothree`.`forummessagetypedescriptions`.`frmmsgtypd_forummessagetypedescriptionid` AS `frmmsgtypd_forummessagetypedescriptionid`,
       `echothree`.`forummessagetypedescriptions`.`frmmsgtypd_frmmsgtyp_forummessagetypeid`  AS `frmmsgtypd_frmmsgtyp_forummessagetypeid`,
       `echothree`.`forummessagetypedescriptions`.`frmmsgtypd_lang_languageid`               AS `frmmsgtypd_lang_languageid`,
       `echothree`.`forummessagetypedescriptions`.`frmmsgtypd_description`                   AS `frmmsgtypd_description`
from `echothree`.`forummessagetypedescriptions`;

