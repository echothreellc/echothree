create definer = echothree@`127.0.0.1` view forumclobmessageparts as
select `echothree`.`forumclobmessageparts`.`frmcmsgprt_forumclobmessagepartid`       AS `frmcmsgprt_forumclobmessagepartid`,
       `echothree`.`forumclobmessageparts`.`frmcmsgprt_frmmsgprt_forummessagepartid` AS `frmcmsgprt_frmmsgprt_forummessagepartid`,
       `echothree`.`forumclobmessageparts`.`frmcmsgprt_clob`                         AS `frmcmsgprt_clob`
from `echothree`.`forumclobmessageparts`
where (`echothree`.`forumclobmessageparts`.`frmcmsgprt_thrutime` = 9223372036854775807);

