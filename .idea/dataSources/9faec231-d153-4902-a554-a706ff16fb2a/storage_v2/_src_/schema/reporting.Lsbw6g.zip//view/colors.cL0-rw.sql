create definer = echothree@`127.0.0.1` view colors as
select `echothree`.`colors`.`clr_colorid`           AS `clr_colorid`,
       `echothree`.`colordetails`.`clrdt_colorname` AS `clrdt_colorname`,
       `echothree`.`colordetails`.`clrdt_red`       AS `clrdt_red`,
       `echothree`.`colordetails`.`clrdt_green`     AS `clrdt_green`,
       `echothree`.`colordetails`.`clrdt_blue`      AS `clrdt_blue`,
       `echothree`.`colordetails`.`clrdt_isdefault` AS `clrdt_isdefault`,
       `echothree`.`colordetails`.`clrdt_sortorder` AS `clrdt_sortorder`
from `echothree`.`colors`
         join `echothree`.`colordetails`
where (`echothree`.`colors`.`clr_activedetailid` = `echothree`.`colordetails`.`clrdt_colordetailid`);

