create definer = echothree@`127.0.0.1` view filteradjustmenttypes as
select `echothree`.`filteradjustmenttypes`.`fltat_filteradjustmenttypeid`   AS `fltat_filteradjustmenttypeid`,
       `echothree`.`filteradjustmenttypes`.`fltat_filteradjustmenttypename` AS `fltat_filteradjustmenttypename`,
       `echothree`.`filteradjustmenttypes`.`fltat_isdefault`                AS `fltat_isdefault`,
       `echothree`.`filteradjustmenttypes`.`fltat_sortorder`                AS `fltat_sortorder`
from `echothree`.`filteradjustmenttypes`;

