create definer = echothree@`127.0.0.1` view commandmessages as
select `echothree`.`commandmessages`.`cmdmssg_commandmessageid`                       AS `cmdmssg_commandmessageid`,
       `echothree`.`commandmessagedetails`.`cmdmssgdt_cmdmssgty_commandmessagetypeid` AS `cmdmssgdt_cmdmssgty_commandmessagetypeid`,
       `echothree`.`commandmessagedetails`.`cmdmssgdt_commandmessagekey`              AS `cmdmssgdt_commandmessagekey`
from `echothree`.`commandmessages`
         join `echothree`.`commandmessagedetails`
where (`echothree`.`commandmessages`.`cmdmssg_activedetailid` =
       `echothree`.`commandmessagedetails`.`cmdmssgdt_commandmessagedetailid`);

