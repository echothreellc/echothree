create definer = echothree@`127.0.0.1` view indexes as
select `echothree`.`indexes`.`idx_indexid`                 AS `idx_indexid`,
       `echothree`.`indexdetails`.`idxdt_indexname`        AS `idxdt_indexname`,
       `echothree`.`indexdetails`.`idxdt_idxt_indextypeid` AS `idxdt_idxt_indextypeid`,
       `echothree`.`indexdetails`.`idxdt_lang_languageid`  AS `idxdt_lang_languageid`,
       `echothree`.`indexdetails`.`idxdt_directory`        AS `idxdt_directory`,
       `echothree`.`indexdetails`.`idxdt_isdefault`        AS `idxdt_isdefault`,
       `echothree`.`indexdetails`.`idxdt_sortorder`        AS `idxdt_sortorder`
from `echothree`.`indexes`
         join `echothree`.`indexdetails`
where (`echothree`.`indexes`.`idx_activedetailid` = `echothree`.`indexdetails`.`idxdt_indexdetailid`);

