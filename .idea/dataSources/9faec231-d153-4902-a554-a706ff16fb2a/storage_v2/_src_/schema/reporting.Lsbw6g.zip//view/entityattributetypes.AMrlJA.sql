create definer = echothree@`127.0.0.1` view entityattributetypes as
select `echothree`.`entityattributetypes`.`enat_entityattributetypeid`   AS `enat_entityattributetypeid`,
       `echothree`.`entityattributetypes`.`enat_entityattributetypename` AS `enat_entityattributetypename`
from `echothree`.`entityattributetypes`;

