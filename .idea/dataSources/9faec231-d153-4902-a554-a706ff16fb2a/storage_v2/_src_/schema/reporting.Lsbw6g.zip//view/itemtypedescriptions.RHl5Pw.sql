create definer = echothree@`127.0.0.1` view itemtypedescriptions as
select `echothree`.`itemtypedescriptions`.`itypd_itemtypedescriptionid` AS `itypd_itemtypedescriptionid`,
       `echothree`.`itemtypedescriptions`.`itypd_ityp_itemtypeid`       AS `itypd_ityp_itemtypeid`,
       `echothree`.`itemtypedescriptions`.`itypd_lang_languageid`       AS `itypd_lang_languageid`,
       `echothree`.`itemtypedescriptions`.`itypd_description`           AS `itypd_description`
from `echothree`.`itemtypedescriptions`;

