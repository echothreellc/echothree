create definer = echothree@`127.0.0.1` view invoicetimetypes as
select `echothree`.`invoicetimetypes`.`invctimtyp_invoicetimetypeid`             AS `invctimtyp_invoicetimetypeid`,
       `echothree`.`invoicetimetypedetails`.`invctimtypdt_invctyp_invoicetypeid` AS `invctimtypdt_invctyp_invoicetypeid`,
       `echothree`.`invoicetimetypedetails`.`invctimtypdt_invoicetimetypename`   AS `invctimtypdt_invoicetimetypename`,
       `echothree`.`invoicetimetypedetails`.`invctimtypdt_isdefault`             AS `invctimtypdt_isdefault`,
       `echothree`.`invoicetimetypedetails`.`invctimtypdt_sortorder`             AS `invctimtypdt_sortorder`
from `echothree`.`invoicetimetypes`
         join `echothree`.`invoicetimetypedetails`
where (`echothree`.`invoicetimetypes`.`invctimtyp_activedetailid` =
       `echothree`.`invoicetimetypedetails`.`invctimtypdt_invoicetimetypedetailid`);

