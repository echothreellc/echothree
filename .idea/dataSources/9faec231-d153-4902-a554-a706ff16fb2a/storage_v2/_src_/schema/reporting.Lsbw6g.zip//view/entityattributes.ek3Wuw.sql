create definer = echothree@`127.0.0.1` view entityattributes as
select `echothree`.`entityattributes`.`ena_entityattributeid`                  AS `ena_entityattributeid`,
       `echothree`.`entityattributedetails`.`enadt_ent_entitytypeid`           AS `enadt_ent_entitytypeid`,
       `echothree`.`entityattributedetails`.`enadt_entityattributename`        AS `enadt_entityattributename`,
       `echothree`.`entityattributedetails`.`enadt_enat_entityattributetypeid` AS `enadt_enat_entityattributetypeid`,
       `echothree`.`entityattributedetails`.`enadt_trackrevisions`             AS `enadt_trackrevisions`,
       `echothree`.`entityattributedetails`.`enadt_sortorder`                  AS `enadt_sortorder`
from `echothree`.`entityattributes`
         join `echothree`.`entityattributedetails`
where (`echothree`.`entityattributes`.`ena_activedetailid` =
       `echothree`.`entityattributedetails`.`enadt_entityattributedetailid`);

