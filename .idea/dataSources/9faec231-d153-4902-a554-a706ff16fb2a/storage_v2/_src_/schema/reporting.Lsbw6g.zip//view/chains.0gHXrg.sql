create definer = echothree@`127.0.0.1` view chains as
select `echothree`.`chains`.`chn_chainid`                         AS `chn_chainid`,
       `echothree`.`chaindetails`.`chndt_chntyp_chaintypeid`      AS `chndt_chntyp_chaintypeid`,
       `echothree`.`chaindetails`.`chndt_chainname`               AS `chndt_chainname`,
       `echothree`.`chaindetails`.`chndt_chaininstancesequenceid` AS `chndt_chaininstancesequenceid`,
       `echothree`.`chaindetails`.`chndt_isdefault`               AS `chndt_isdefault`,
       `echothree`.`chaindetails`.`chndt_sortorder`               AS `chndt_sortorder`
from `echothree`.`chains`
         join `echothree`.`chaindetails`
where (`echothree`.`chains`.`chn_activedetailid` = `echothree`.`chaindetails`.`chndt_chaindetailid`);

