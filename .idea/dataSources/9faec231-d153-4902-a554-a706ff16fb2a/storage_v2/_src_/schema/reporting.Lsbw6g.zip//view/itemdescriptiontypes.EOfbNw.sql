create definer = echothree@`127.0.0.1` view itemdescriptiontypes as
select `echothree`.`itemdescriptiontypes`.`idt_itemdescriptiontypeid`               AS `idt_itemdescriptiontypeid`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_itemdescriptiontypename`     AS `idtdt_itemdescriptiontypename`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_parentitemdescriptiontypeid` AS `idtdt_parentitemdescriptiontypeid`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_useparentifmissing`          AS `idtdt_useparentifmissing`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_mtyput_mimetypeusagetypeid`  AS `idtdt_mtyput_mimetypeusagetypeid`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_checkcontentwebaddress`      AS `idtdt_checkcontentwebaddress`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_includeinindex`              AS `idtdt_includeinindex`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_indexdefault`                AS `idtdt_indexdefault`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_isdefault`                   AS `idtdt_isdefault`,
       `echothree`.`itemdescriptiontypedetails`.`idtdt_sortorder`                   AS `idtdt_sortorder`
from `echothree`.`itemdescriptiontypes`
         join `echothree`.`itemdescriptiontypedetails`
where (`echothree`.`itemdescriptiontypes`.`idt_activedetailid` =
       `echothree`.`itemdescriptiontypedetails`.`idtdt_itemdescriptiontypedetailid`);

