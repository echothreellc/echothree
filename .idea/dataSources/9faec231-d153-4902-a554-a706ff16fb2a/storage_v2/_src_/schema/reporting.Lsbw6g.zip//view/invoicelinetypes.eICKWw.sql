create definer = echothree@`127.0.0.1` view invoicelinetypes as
select `echothree`.`invoicelinetypes`.`invcltyp_invoicelinetypeid`               AS `invcltyp_invoicelinetypeid`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_invctyp_invoicetypeid`   AS `invcltypdt_invctyp_invoicetypeid`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_invoicelinetypename`     AS `invcltypdt_invoicelinetypename`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_parentinvoicelinetypeid` AS `invcltypdt_parentinvoicelinetypeid`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_defaultglaccountid`      AS `invcltypdt_defaultglaccountid`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_isdefault`               AS `invcltypdt_isdefault`,
       `echothree`.`invoicelinetypedetails`.`invcltypdt_sortorder`               AS `invcltypdt_sortorder`
from `echothree`.`invoicelinetypes`
         join `echothree`.`invoicelinetypedetails`
where (`echothree`.`invoicelinetypes`.`invcltyp_activedetailid` =
       `echothree`.`invoicelinetypedetails`.`invcltypdt_invoicelinetypedetailid`);

