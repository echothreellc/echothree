create definer = echothree@`127.0.0.1` view inventoryconditionglaccounts as
select `echothree`.`inventoryconditionglaccounts`.`invcongla_inventoryconditionglaccountid`   AS `invcongla_inventoryconditionglaccountid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_invcon_inventoryconditionid`     AS `invcongla_invcon_inventoryconditionid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_iactgc_itemaccountingcategoryid` AS `invcongla_iactgc_itemaccountingcategoryid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_inventoryglaccountid`            AS `invcongla_inventoryglaccountid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_salesglaccountid`                AS `invcongla_salesglaccountid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_returnsglaccountid`              AS `invcongla_returnsglaccountid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_cogsglaccountid`                 AS `invcongla_cogsglaccountid`,
       `echothree`.`inventoryconditionglaccounts`.`invcongla_returnscogsglaccountid`          AS `invcongla_returnscogsglaccountid`
from `echothree`.`inventoryconditionglaccounts`
where (`echothree`.`inventoryconditionglaccounts`.`invcongla_thrutime` = 9223372036854775807);

