create definer = echothree@`127.0.0.1` view applicationeditors as
select `echothree`.`applicationeditors`.`appledtr_applicationeditorid`        AS `appledtr_applicationeditorid`,
       `echothree`.`applicationeditordetails`.`appledtrdt_appl_applicationid` AS `appledtrdt_appl_applicationid`,
       `echothree`.`applicationeditordetails`.`appledtrdt_edtr_editorid`      AS `appledtrdt_edtr_editorid`,
       `echothree`.`applicationeditordetails`.`appledtrdt_isdefault`          AS `appledtrdt_isdefault`,
       `echothree`.`applicationeditordetails`.`appledtrdt_sortorder`          AS `appledtrdt_sortorder`
from `echothree`.`applicationeditors`
         join `echothree`.`applicationeditordetails`
where (`echothree`.`applicationeditors`.`appledtr_activedetailid` =
       `echothree`.`applicationeditordetails`.`appledtrdt_applicationeditordetailid`);

