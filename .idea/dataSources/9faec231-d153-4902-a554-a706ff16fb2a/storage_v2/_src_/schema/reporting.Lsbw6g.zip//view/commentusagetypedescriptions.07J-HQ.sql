create definer = echothree@`127.0.0.1` view commentusagetypedescriptions as
select `echothree`.`commentusagetypedescriptions`.`cmntutypd_commentusagetypedescriptionid` AS `cmntutypd_commentusagetypedescriptionid`,
       `echothree`.`commentusagetypedescriptions`.`cmntutypd_cmntutyp_commentusagetypeid`   AS `cmntutypd_cmntutyp_commentusagetypeid`,
       `echothree`.`commentusagetypedescriptions`.`cmntutypd_lang_languageid`               AS `cmntutypd_lang_languageid`,
       `echothree`.`commentusagetypedescriptions`.`cmntutypd_description`                   AS `cmntutypd_description`
from `echothree`.`commentusagetypedescriptions`
where (`echothree`.`commentusagetypedescriptions`.`cmntutypd_thrutime` = 9223372036854775807);

