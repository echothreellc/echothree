create definer = echothree@`127.0.0.1` view entityclobattributes as
select `echothree`.`entityclobattributes`.`enca_entityclobattributeid` AS `enca_entityclobattributeid`,
       `echothree`.`entityclobattributes`.`enca_ena_entityattributeid` AS `enca_ena_entityattributeid`,
       `echothree`.`entityclobattributes`.`enca_eni_entityinstanceid`  AS `enca_eni_entityinstanceid`,
       `echothree`.`entityclobattributes`.`enca_lang_languageid`       AS `enca_lang_languageid`,
       `echothree`.`entityclobattributes`.`enca_clobattribute`         AS `enca_clobattribute`,
       `echothree`.`entityclobattributes`.`enca_mtyp_mimetypeid`       AS `enca_mtyp_mimetypeid`
from `echothree`.`entityclobattributes`
where (`echothree`.`entityclobattributes`.`enca_thrutime` = 9223372036854775807);

