create definer = echothree@`127.0.0.1` view associateprogramdescriptions as
select `echothree`.`associateprogramdescriptions`.`ascprgmd_associateprogramdescriptionid` AS `ascprgmd_associateprogramdescriptionid`,
       `echothree`.`associateprogramdescriptions`.`ascprgmd_ascprgm_associateprogramid`    AS `ascprgmd_ascprgm_associateprogramid`,
       `echothree`.`associateprogramdescriptions`.`ascprgmd_lang_languageid`               AS `ascprgmd_lang_languageid`,
       `echothree`.`associateprogramdescriptions`.`ascprgmd_description`                   AS `ascprgmd_description`
from `echothree`.`associateprogramdescriptions`
where (`echothree`.`associateprogramdescriptions`.`ascprgmd_thrutime` = 9223372036854775807);

