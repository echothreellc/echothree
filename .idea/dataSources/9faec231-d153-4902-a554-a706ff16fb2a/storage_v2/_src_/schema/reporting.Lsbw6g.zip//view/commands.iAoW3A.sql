create definer = echothree@`127.0.0.1` view commands as
select `echothree`.`commands`.`cmd_commandid`                      AS `cmd_commandid`,
       `echothree`.`commanddetails`.`cmddt_cvnd_componentvendorid` AS `cmddt_cvnd_componentvendorid`,
       `echothree`.`commanddetails`.`cmddt_commandname`            AS `cmddt_commandname`,
       `echothree`.`commanddetails`.`cmddt_sortorder`              AS `cmddt_sortorder`
from `echothree`.`commands`
         join `echothree`.`commanddetails`
where (`echothree`.`commands`.`cmd_activedetailid` = `echothree`.`commanddetails`.`cmddt_commanddetailid`);

