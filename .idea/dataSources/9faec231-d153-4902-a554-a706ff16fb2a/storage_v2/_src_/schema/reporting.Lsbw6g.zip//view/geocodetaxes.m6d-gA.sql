create definer = echothree@`127.0.0.1` view geocodetaxes as
select `echothree`.`geocodetaxes`.`geotx_geocodetaxid`  AS `geotx_geocodetaxid`,
       `echothree`.`geocodetaxes`.`geotx_geo_geocodeid` AS `geotx_geo_geocodeid`,
       `echothree`.`geocodetaxes`.`geotx_tx_taxid`      AS `geotx_tx_taxid`
from `echothree`.`geocodetaxes`
where (`echothree`.`geocodetaxes`.`geotx_thrutime` = 9223372036854775807);

