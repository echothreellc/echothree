create definer = echothree@`127.0.0.1` view filterstepelementdescriptions as
select `echothree`.`filterstepelementdescriptions`.`fltstped_filterstepelementdescriptionid` AS `fltstped_filterstepelementdescriptionid`,
       `echothree`.`filterstepelementdescriptions`.`fltstped_fltstpe_filterstepelementid`    AS `fltstped_fltstpe_filterstepelementid`,
       `echothree`.`filterstepelementdescriptions`.`fltstped_lang_languageid`                AS `fltstped_lang_languageid`,
       `echothree`.`filterstepelementdescriptions`.`fltstped_description`                    AS `fltstped_description`
from `echothree`.`filterstepelementdescriptions`
where (`echothree`.`filterstepelementdescriptions`.`fltstped_thrutime` = 9223372036854775807);

