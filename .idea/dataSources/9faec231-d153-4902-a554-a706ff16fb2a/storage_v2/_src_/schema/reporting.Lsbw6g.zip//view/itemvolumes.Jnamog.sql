create definer = echothree@`127.0.0.1` view itemvolumes as
select `echothree`.`itemvolumes`.`ivol_itemvolumeid`             AS `ivol_itemvolumeid`,
       `echothree`.`itemvolumes`.`ivol_itm_itemid`               AS `ivol_itm_itemid`,
       `echothree`.`itemvolumes`.`ivol_uomt_unitofmeasuretypeid` AS `ivol_uomt_unitofmeasuretypeid`,
       `echothree`.`itemvolumes`.`ivol_height`                   AS `ivol_height`,
       `echothree`.`itemvolumes`.`ivol_width`                    AS `ivol_width`,
       `echothree`.`itemvolumes`.`ivol_depth`                    AS `ivol_depth`
from `echothree`.`itemvolumes`
where (`echothree`.`itemvolumes`.`ivol_thrutime` = 9223372036854775807);

