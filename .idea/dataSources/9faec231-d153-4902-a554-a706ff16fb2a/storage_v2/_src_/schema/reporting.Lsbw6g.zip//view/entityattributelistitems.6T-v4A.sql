create definer = echothree@`127.0.0.1` view entityattributelistitems as
select `echothree`.`entityattributelistitems`.`enali_entityattributelistitemid` AS `enali_entityattributelistitemid`,
       `echothree`.`entityattributelistitems`.`enali_ena_entityattributeid`     AS `enali_ena_entityattributeid`,
       `echothree`.`entityattributelistitems`.`enali_entitylistitemsequenceid`  AS `enali_entitylistitemsequenceid`
from `echothree`.`entityattributelistitems`
where (`echothree`.`entityattributelistitems`.`enali_thrutime` = 9223372036854775807);

