create definer = echothree@`127.0.0.1` view genders as
select `echothree`.`genders`.`gndr_genderid`           AS `gndr_genderid`,
       `echothree`.`genderdetails`.`gndrdt_gendername` AS `gndrdt_gendername`,
       `echothree`.`genderdetails`.`gndrdt_isdefault`  AS `gndrdt_isdefault`,
       `echothree`.`genderdetails`.`gndrdt_sortorder`  AS `gndrdt_sortorder`
from `echothree`.`genders`
         join `echothree`.`genderdetails`
where (`echothree`.`genders`.`gndr_activedetailid` = `echothree`.`genderdetails`.`gndrdt_genderdetailid`);

