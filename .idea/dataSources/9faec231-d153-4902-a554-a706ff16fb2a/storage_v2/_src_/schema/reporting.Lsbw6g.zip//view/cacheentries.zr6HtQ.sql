create definer = echothree@`127.0.0.1` view cacheentries as
select `echothree`.`cacheentries`.`cent_cacheentryid`    AS `cent_cacheentryid`,
       `echothree`.`cacheentries`.`cent_cacheentrykey`   AS `cent_cacheentrykey`,
       `echothree`.`cacheentries`.`cent_mtyp_mimetypeid` AS `cent_mtyp_mimetypeid`,
       `echothree`.`cacheentries`.`cent_createdtime`     AS `cent_createdtime`,
       `echothree`.`cacheentries`.`cent_validuntiltime`  AS `cent_validuntiltime`
from `echothree`.`cacheentries`;

