create definer = echothree@`127.0.0.1` view itemcategories as
select `echothree`.`itemcategories`.`ic_itemcategoryid`              AS `ic_itemcategoryid`,
       `echothree`.`itemcategorydetails`.`icdt_itemcategoryname`     AS `icdt_itemcategoryname`,
       `echothree`.`itemcategorydetails`.`icdt_parentitemcategoryid` AS `icdt_parentitemcategoryid`,
       `echothree`.`itemcategorydetails`.`icdt_itemsequenceid`       AS `icdt_itemsequenceid`,
       `echothree`.`itemcategorydetails`.`icdt_isdefault`            AS `icdt_isdefault`,
       `echothree`.`itemcategorydetails`.`icdt_sortorder`            AS `icdt_sortorder`
from `echothree`.`itemcategories`
         join `echothree`.`itemcategorydetails`
where (`echothree`.`itemcategories`.`ic_activedetailid` =
       `echothree`.`itemcategorydetails`.`icdt_itemcategorydetailid`);

