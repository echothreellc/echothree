create definer = echothree@`127.0.0.1` view appearancetexttransformations as
select `echothree`.`appearancetexttransformations`.`apprntxttrns_appearancetexttransformationid` AS `apprntxttrns_appearancetexttransformationid`,
       `echothree`.`appearancetexttransformations`.`apprntxttrns_apprnc_appearanceid`            AS `apprntxttrns_apprnc_appearanceid`,
       `echothree`.`appearancetexttransformations`.`apprntxttrns_txttrns_texttransformationid`   AS `apprntxttrns_txttrns_texttransformationid`
from `echothree`.`appearancetexttransformations`
where (`echothree`.`appearancetexttransformations`.`apprntxttrns_thrutime` = 9223372036854775807);

