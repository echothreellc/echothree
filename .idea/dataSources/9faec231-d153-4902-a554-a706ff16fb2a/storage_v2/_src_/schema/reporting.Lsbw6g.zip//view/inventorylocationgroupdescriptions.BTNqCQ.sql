create definer = echothree@`127.0.0.1` view inventorylocationgroupdescriptions as
select `echothree`.`inventorylocationgroupdescriptions`.`invlocgrpd_inventorylocationgroupdescriptionid` AS `invlocgrpd_inventorylocationgroupdescriptionid`,
       `echothree`.`inventorylocationgroupdescriptions`.`invlocgrpd_invlocgrp_inventorylocationgroupid`  AS `invlocgrpd_invlocgrp_inventorylocationgroupid`,
       `echothree`.`inventorylocationgroupdescriptions`.`invlocgrpd_lang_languageid`                     AS `invlocgrpd_lang_languageid`,
       `echothree`.`inventorylocationgroupdescriptions`.`invlocgrpd_description`                         AS `invlocgrpd_description`
from `echothree`.`inventorylocationgroupdescriptions`
where (`echothree`.`inventorylocationgroupdescriptions`.`invlocgrpd_thrutime` = 9223372036854775807);

