create definer = echothree@`127.0.0.1` view contactpostaladdresses as
select `echothree`.`contactpostaladdresses`.`ctpa_contactpostaladdressid`  AS `ctpa_contactpostaladdressid`,
       `echothree`.`contactpostaladdresses`.`ctpa_cmch_contactmechanismid` AS `ctpa_cmch_contactmechanismid`,
       `echothree`.`contactpostaladdresses`.`ctpa_pert_personaltitleid`    AS `ctpa_pert_personaltitleid`,
       `echothree`.`contactpostaladdresses`.`ctpa_firstname`               AS `ctpa_firstname`,
       `echothree`.`contactpostaladdresses`.`ctpa_firstnamesdx`            AS `ctpa_firstnamesdx`,
       `echothree`.`contactpostaladdresses`.`ctpa_middlename`              AS `ctpa_middlename`,
       `echothree`.`contactpostaladdresses`.`ctpa_middlenamesdx`           AS `ctpa_middlenamesdx`,
       `echothree`.`contactpostaladdresses`.`ctpa_lastname`                AS `ctpa_lastname`,
       `echothree`.`contactpostaladdresses`.`ctpa_lastnamesdx`             AS `ctpa_lastnamesdx`,
       `echothree`.`contactpostaladdresses`.`ctpa_nsfx_namesuffixid`       AS `ctpa_nsfx_namesuffixid`,
       `echothree`.`contactpostaladdresses`.`ctpa_companyname`             AS `ctpa_companyname`,
       `echothree`.`contactpostaladdresses`.`ctpa_attention`               AS `ctpa_attention`,
       `echothree`.`contactpostaladdresses`.`ctpa_address1`                AS `ctpa_address1`,
       `echothree`.`contactpostaladdresses`.`ctpa_address2`                AS `ctpa_address2`,
       `echothree`.`contactpostaladdresses`.`ctpa_address3`                AS `ctpa_address3`,
       `echothree`.`contactpostaladdresses`.`ctpa_city`                    AS `ctpa_city`,
       `echothree`.`contactpostaladdresses`.`ctpa_citygeocodeid`           AS `ctpa_citygeocodeid`,
       `echothree`.`contactpostaladdresses`.`ctpa_countygeocodeid`         AS `ctpa_countygeocodeid`,
       `echothree`.`contactpostaladdresses`.`ctpa_state`                   AS `ctpa_state`,
       `echothree`.`contactpostaladdresses`.`ctpa_stategeocodeid`          AS `ctpa_stategeocodeid`,
       `echothree`.`contactpostaladdresses`.`ctpa_postalcode`              AS `ctpa_postalcode`,
       `echothree`.`contactpostaladdresses`.`ctpa_postalcodegeocodeid`     AS `ctpa_postalcodegeocodeid`,
       `echothree`.`contactpostaladdresses`.`ctpa_countrygeocodeid`        AS `ctpa_countrygeocodeid`,
       `echothree`.`contactpostaladdresses`.`ctpa_iscommercial`            AS `ctpa_iscommercial`
from `echothree`.`contactpostaladdresses`
where (`echothree`.`contactpostaladdresses`.`ctpa_thrutime` = 9223372036854775807);

