create definer = echothree@`127.0.0.1` view forumthreads as
select `echothree`.`forumthreads`.`frmthrd_forumthreadid`           AS `frmthrd_forumthreadid`,
       `echothree`.`forumthreaddetails`.`frmthrddt_forumthreadname` AS `frmthrddt_forumthreadname`,
       `echothree`.`forumthreaddetails`.`frmthrddt_icn_iconid`      AS `frmthrddt_icn_iconid`,
       `echothree`.`forumthreaddetails`.`frmthrddt_postedtime`      AS `frmthrddt_postedtime`,
       `echothree`.`forumthreaddetails`.`frmthrddt_sortorder`       AS `frmthrddt_sortorder`
from `echothree`.`forumthreads`
         join `echothree`.`forumthreaddetails`
where (`echothree`.`forumthreads`.`frmthrd_activedetailid` =
       `echothree`.`forumthreaddetails`.`frmthrddt_forumthreaddetailid`);

