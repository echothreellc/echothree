create definer = echothree@`127.0.0.1` view entitydateattributes as
select `echothree`.`entitydateattributes`.`enda_entitydateattributeid` AS `enda_entitydateattributeid`,
       `echothree`.`entitydateattributes`.`enda_ena_entityattributeid` AS `enda_ena_entityattributeid`,
       `echothree`.`entitydateattributes`.`enda_eni_entityinstanceid`  AS `enda_eni_entityinstanceid`,
       `echothree`.`entitydateattributes`.`enda_dateattribute`         AS `enda_dateattribute`
from `echothree`.`entitydateattributes`
where (`echothree`.`entitydateattributes`.`enda_thrutime` = 9223372036854775807);

