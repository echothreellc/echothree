create definer = echothree@`127.0.0.1` view contentpageareas as
select `echothree`.`contentpageareas`.`cntpa_contentpageareaid`                     AS `cntpa_contentpageareaid`,
       `echothree`.`contentpageareadetails`.`cntpad_cntp_contentpageid`             AS `cntpad_cntp_contentpageid`,
       `echothree`.`contentpageareadetails`.`cntpad_cntpla_contentpagelayoutareaid` AS `cntpad_cntpla_contentpagelayoutareaid`,
       `echothree`.`contentpageareadetails`.`cntpad_lang_languageid`                AS `cntpad_lang_languageid`,
       `echothree`.`contentpageareadetails`.`cntpad_mtyp_mimetypeid`                AS `cntpad_mtyp_mimetypeid`
from `echothree`.`contentpageareas`
         join `echothree`.`contentpageareadetails`
where (`echothree`.`contentpageareas`.`cntpa_activedetailid` =
       `echothree`.`contentpageareadetails`.`cntpad_contentpageareadetailid`);

