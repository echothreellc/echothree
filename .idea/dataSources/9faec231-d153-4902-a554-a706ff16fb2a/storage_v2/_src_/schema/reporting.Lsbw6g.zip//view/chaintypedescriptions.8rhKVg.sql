create definer = echothree@`127.0.0.1` view chaintypedescriptions as
select `echothree`.`chaintypedescriptions`.`chntypd_chaintypedescriptionid` AS `chntypd_chaintypedescriptionid`,
       `echothree`.`chaintypedescriptions`.`chntypd_chntyp_chaintypeid`     AS `chntypd_chntyp_chaintypeid`,
       `echothree`.`chaintypedescriptions`.`chntypd_lang_languageid`        AS `chntypd_lang_languageid`,
       `echothree`.`chaintypedescriptions`.`chntypd_description`            AS `chntypd_description`
from `echothree`.`chaintypedescriptions`
where (`echothree`.`chaintypedescriptions`.`chntypd_thrutime` = 9223372036854775807);

