create definer = echothree@`127.0.0.1` view iteminventorytypes as
select `echothree`.`iteminventorytypes`.`iinvtyp_iteminventorytypeid`   AS `iinvtyp_iteminventorytypeid`,
       `echothree`.`iteminventorytypes`.`iinvtyp_iteminventorytypename` AS `iinvtyp_iteminventorytypename`,
       `echothree`.`iteminventorytypes`.`iinvtyp_isdefault`             AS `iinvtyp_isdefault`,
       `echothree`.`iteminventorytypes`.`iinvtyp_sortorder`             AS `iinvtyp_sortorder`
from `echothree`.`iteminventorytypes`;

