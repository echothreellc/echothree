create definer = echothree@`127.0.0.1` view documenttypeusagetypes as
select `echothree`.`documenttypeusagetypes`.`dcmnttyputyp_documenttypeusagetypeid`           AS `dcmnttyputyp_documenttypeusagetypeid`,
       `echothree`.`documenttypeusagetypedetails`.`dcmnttyputypdt_documenttypeusagetypename` AS `dcmnttyputypdt_documenttypeusagetypename`,
       `echothree`.`documenttypeusagetypedetails`.`dcmnttyputypdt_isdefault`                 AS `dcmnttyputypdt_isdefault`,
       `echothree`.`documenttypeusagetypedetails`.`dcmnttyputypdt_sortorder`                 AS `dcmnttyputypdt_sortorder`
from `echothree`.`documenttypeusagetypes`
         join `echothree`.`documenttypeusagetypedetails`
where (`echothree`.`documenttypeusagetypes`.`dcmnttyputyp_activedetailid` =
       `echothree`.`documenttypeusagetypedetails`.`dcmnttyputypdt_documenttypeusagetypedetailid`);

