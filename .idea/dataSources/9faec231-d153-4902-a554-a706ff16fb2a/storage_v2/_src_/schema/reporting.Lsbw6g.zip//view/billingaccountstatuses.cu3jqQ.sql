create definer = echothree@`127.0.0.1` view billingaccountstatuses as
select `echothree`.`billingaccountstatuses`.`bllactst_billingaccountstatusid`  AS `bllactst_billingaccountstatusid`,
       `echothree`.`billingaccountstatuses`.`bllactst_bllact_billingaccountid` AS `bllactst_bllact_billingaccountid`,
       `echothree`.`billingaccountstatuses`.`bllactst_creditlimit`             AS `bllactst_creditlimit`,
       `echothree`.`billingaccountstatuses`.`bllactst_potentialcreditlimit`    AS `bllactst_potentialcreditlimit`
from `echothree`.`billingaccountstatuses`;

