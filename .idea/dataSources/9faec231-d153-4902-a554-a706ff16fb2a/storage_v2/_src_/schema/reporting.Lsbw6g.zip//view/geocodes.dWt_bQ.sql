create definer = echothree@`127.0.0.1` view geocodes as
select `echothree`.`geocodes`.`geo_geocodeid`                   AS `geo_geocodeid`,
       `echothree`.`geocodedetails`.`geodt_geocodename`         AS `geodt_geocodename`,
       `echothree`.`geocodedetails`.`geodt_geot_geocodetypeid`  AS `geodt_geot_geocodetypeid`,
       `echothree`.`geocodedetails`.`geodt_geos_geocodescopeid` AS `geodt_geos_geocodescopeid`,
       `echothree`.`geocodedetails`.`geodt_isdefault`           AS `geodt_isdefault`,
       `echothree`.`geocodedetails`.`geodt_sortorder`           AS `geodt_sortorder`
from `echothree`.`geocodes`
         join `echothree`.`geocodedetails`
where (`echothree`.`geocodes`.`geo_activedetailid` = `echothree`.`geocodedetails`.`geodt_geocodedetailid`);

