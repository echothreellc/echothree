create definer = echothree@`127.0.0.1` view documenttypes as
select `echothree`.`documenttypes`.`dcmnttyp_documenttypeid`                     AS `dcmnttyp_documenttypeid`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_documenttypename`           AS `dcmnttypdt_documenttypename`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_parentdocumenttypeid`       AS `dcmnttypdt_parentdocumenttypeid`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_mtyput_mimetypeusagetypeid` AS `dcmnttypdt_mtyput_mimetypeusagetypeid`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_maximumpages`               AS `dcmnttypdt_maximumpages`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_isdefault`                  AS `dcmnttypdt_isdefault`,
       `echothree`.`documenttypedetails`.`dcmnttypdt_sortorder`                  AS `dcmnttypdt_sortorder`
from `echothree`.`documenttypes`
         join `echothree`.`documenttypedetails`
where (`echothree`.`documenttypes`.`dcmnttyp_activedetailid` =
       `echothree`.`documenttypedetails`.`dcmnttypdt_documenttypedetailid`);

