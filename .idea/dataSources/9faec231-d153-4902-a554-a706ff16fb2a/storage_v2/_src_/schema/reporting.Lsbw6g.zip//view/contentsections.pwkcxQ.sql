create definer = echothree@`127.0.0.1` view contentsections as
select `echothree`.`contentsections`.`cnts_contentsectionid`                 AS `cnts_contentsectionid`,
       `echothree`.`contentsectiondetails`.`cntsdt_cntc_contentcollectionid` AS `cntsdt_cntc_contentcollectionid`,
       `echothree`.`contentsectiondetails`.`cntsdt_contentsectionname`       AS `cntsdt_contentsectionname`,
       `echothree`.`contentsectiondetails`.`cntsdt_parentcontentsectionid`   AS `cntsdt_parentcontentsectionid`,
       `echothree`.`contentsectiondetails`.`cntsdt_isdefault`                AS `cntsdt_isdefault`,
       `echothree`.`contentsectiondetails`.`cntsdt_sortorder`                AS `cntsdt_sortorder`
from `echothree`.`contentsections`
         join `echothree`.`contentsectiondetails`
where (`echothree`.`contentsections`.`cnts_activedetailid` =
       `echothree`.`contentsectiondetails`.`cntsdt_contentsectiondetailid`);

