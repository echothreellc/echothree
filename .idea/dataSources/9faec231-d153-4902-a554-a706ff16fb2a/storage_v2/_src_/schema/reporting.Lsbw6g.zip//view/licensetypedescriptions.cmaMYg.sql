create definer = echothree@`127.0.0.1` view licensetypedescriptions as
select `echothree`.`licensetypedescriptions`.`lcnstypd_licensetypedescriptionid` AS `lcnstypd_licensetypedescriptionid`,
       `echothree`.`licensetypedescriptions`.`lcnstypd_lcnstyp_licensetypeid`    AS `lcnstypd_lcnstyp_licensetypeid`,
       `echothree`.`licensetypedescriptions`.`lcnstypd_lang_languageid`          AS `lcnstypd_lang_languageid`,
       `echothree`.`licensetypedescriptions`.`lcnstypd_description`              AS `lcnstypd_description`
from `echothree`.`licensetypedescriptions`
where (`echothree`.`licensetypedescriptions`.`lcnstypd_thrutime` = 9223372036854775807);

