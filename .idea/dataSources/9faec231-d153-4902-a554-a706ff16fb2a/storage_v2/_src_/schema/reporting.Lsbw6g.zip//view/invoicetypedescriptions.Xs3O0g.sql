create definer = echothree@`127.0.0.1` view invoicetypedescriptions as
select `echothree`.`invoicetypedescriptions`.`invctypd_invoicetypedescriptionid` AS `invctypd_invoicetypedescriptionid`,
       `echothree`.`invoicetypedescriptions`.`invctypd_invctyp_invoicetypeid`    AS `invctypd_invctyp_invoicetypeid`,
       `echothree`.`invoicetypedescriptions`.`invctypd_lang_languageid`          AS `invctypd_lang_languageid`,
       `echothree`.`invoicetypedescriptions`.`invctypd_description`              AS `invctypd_description`
from `echothree`.`invoicetypedescriptions`
where (`echothree`.`invoicetypedescriptions`.`invctypd_thrutime` = 9223372036854775807);

