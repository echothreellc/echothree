create definer = echothree@`127.0.0.1` view contentpageareaurls as
select `echothree`.`contentpageareaurls`.`cntpau_contentpagearealinkid`          AS `cntpau_contentpagearealinkid`,
       `echothree`.`contentpageareaurls`.`cntpau_cntpad_contentpageareadetailid` AS `cntpau_cntpad_contentpageareadetailid`,
       `echothree`.`contentpageareaurls`.`cntpau_url`                            AS `cntpau_url`
from `echothree`.`contentpageareaurls`;

