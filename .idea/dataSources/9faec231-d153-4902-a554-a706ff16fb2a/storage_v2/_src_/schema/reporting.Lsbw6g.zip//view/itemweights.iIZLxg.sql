create definer = echothree@`127.0.0.1` view itemweights as
select `echothree`.`itemweights`.`iwght_itemweightid`             AS `iwght_itemweightid`,
       `echothree`.`itemweights`.`iwght_itm_itemid`               AS `iwght_itm_itemid`,
       `echothree`.`itemweights`.`iwght_uomt_unitofmeasuretypeid` AS `iwght_uomt_unitofmeasuretypeid`,
       `echothree`.`itemweights`.`iwght_weight`                   AS `iwght_weight`
from `echothree`.`itemweights`
where (`echothree`.`itemweights`.`iwght_thrutime` = 9223372036854775807);

