create definer = echothree@`127.0.0.1` view documenttypedescriptions as
select `echothree`.`documenttypedescriptions`.`dcmnttypd_documenttypedescriptionid` AS `dcmnttypd_documenttypedescriptionid`,
       `echothree`.`documenttypedescriptions`.`dcmnttypd_dcmnttyp_documenttypeid`   AS `dcmnttypd_dcmnttyp_documenttypeid`,
       `echothree`.`documenttypedescriptions`.`dcmnttypd_lang_languageid`           AS `dcmnttypd_lang_languageid`,
       `echothree`.`documenttypedescriptions`.`dcmnttypd_description`               AS `dcmnttypd_description`
from `echothree`.`documenttypedescriptions`
where (`echothree`.`documenttypedescriptions`.`dcmnttypd_thrutime` = 9223372036854775807);

