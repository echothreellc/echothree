create definer = echothree@`127.0.0.1` view customertypecontactlists as
select `echothree`.`customertypecontactlists`.`cutyclst_customertypecontactlistid` AS `cutyclst_customertypecontactlistid`,
       `echothree`.`customertypecontactlists`.`cutyclst_cuty_customertypeid`       AS `cutyclst_cuty_customertypeid`,
       `echothree`.`customertypecontactlists`.`cutyclst_clst_contactlistid`        AS `cutyclst_clst_contactlistid`,
       `echothree`.`customertypecontactlists`.`cutyclst_addwhencreated`            AS `cutyclst_addwhencreated`
from `echothree`.`customertypecontactlists`
where (`echothree`.`customertypecontactlists`.`cutyclst_thrutime` = 9223372036854775807);

