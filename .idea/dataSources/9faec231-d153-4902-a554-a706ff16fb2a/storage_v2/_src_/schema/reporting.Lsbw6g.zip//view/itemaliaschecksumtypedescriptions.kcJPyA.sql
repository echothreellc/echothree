create definer = echothree@`127.0.0.1` view itemaliaschecksumtypedescriptions as
select `echothree`.`itemaliaschecksumtypedescriptions`.`iactd_itemaliaschecksumtypedescriptionid` AS `iactd_itemaliaschecksumtypedescriptionid`,
       `echothree`.`itemaliaschecksumtypedescriptions`.`iactd_iact_itemaliaschecksumtypeid`       AS `iactd_iact_itemaliaschecksumtypeid`,
       `echothree`.`itemaliaschecksumtypedescriptions`.`iactd_lang_languageid`                    AS `iactd_lang_languageid`,
       `echothree`.`itemaliaschecksumtypedescriptions`.`iactd_description`                        AS `iactd_description`
from `echothree`.`itemaliaschecksumtypedescriptions`;

