create definer = echothree@`127.0.0.1` view contentcatalogdescriptions as
select `echothree`.`contentcatalogdescriptions`.`cntctd_contentcatalogdescriptionid` AS `cntctd_contentcatalogdescriptionid`,
       `echothree`.`contentcatalogdescriptions`.`cntctd_cntct_contentcatalogid`      AS `cntctd_cntct_contentcatalogid`,
       `echothree`.`contentcatalogdescriptions`.`cntctd_lang_languageid`             AS `cntctd_lang_languageid`,
       `echothree`.`contentcatalogdescriptions`.`cntctd_description`                 AS `cntctd_description`
from `echothree`.`contentcatalogdescriptions`
where (`echothree`.`contentcatalogdescriptions`.`cntctd_thrutime` = 9223372036854775807);

