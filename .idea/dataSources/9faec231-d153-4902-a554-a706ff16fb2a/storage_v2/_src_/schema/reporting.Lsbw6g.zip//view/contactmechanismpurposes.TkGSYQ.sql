create definer = echothree@`127.0.0.1` view contactmechanismpurposes as
select `echothree`.`contactmechanismpurposes`.`cmpr_contactmechanismpurposeid`   AS `cmpr_contactmechanismpurposeid`,
       `echothree`.`contactmechanismpurposes`.`cmpr_contactmechanismpurposename` AS `cmpr_contactmechanismpurposename`,
       `echothree`.`contactmechanismpurposes`.`cmpr_cmt_contactmechanismtypeid`  AS `cmpr_cmt_contactmechanismtypeid`,
       `echothree`.`contactmechanismpurposes`.`cmpr_eventsubscriber`             AS `cmpr_eventsubscriber`,
       `echothree`.`contactmechanismpurposes`.`cmpr_isdefault`                   AS `cmpr_isdefault`,
       `echothree`.`contactmechanismpurposes`.`cmpr_sortorder`                   AS `cmpr_sortorder`
from `echothree`.`contactmechanismpurposes`;

