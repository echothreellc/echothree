create definer = echothree@`127.0.0.1` view filteradjustments as
select `echothree`.`filteradjustments`.`flta_filteradjustmentid`                     AS `flta_filteradjustmentid`,
       `echothree`.`filteradjustmentdetails`.`fltadt_fltk_filterkindid`              AS `fltadt_fltk_filterkindid`,
       `echothree`.`filteradjustmentdetails`.`fltadt_filteradjustmentname`           AS `fltadt_filteradjustmentname`,
       `echothree`.`filteradjustmentdetails`.`fltadt_fltas_filteradjustmentsourceid` AS `fltadt_fltas_filteradjustmentsourceid`,
       `echothree`.`filteradjustmentdetails`.`fltadt_fltat_filteradjustmenttypeid`   AS `fltadt_fltat_filteradjustmenttypeid`,
       `echothree`.`filteradjustmentdetails`.`fltadt_isdefault`                      AS `fltadt_isdefault`,
       `echothree`.`filteradjustmentdetails`.`fltadt_sortorder`                      AS `fltadt_sortorder`
from `echothree`.`filteradjustments`
         join `echothree`.`filteradjustmentdetails`
where (`echothree`.`filteradjustments`.`flta_activedetailid` =
       `echothree`.`filteradjustmentdetails`.`fltadt_filteradjustmentdetailid`);

