create definer = echothree@`127.0.0.1` view entitystringattributes as
select `echothree`.`entitystringattributes`.`ensa_entitystringattributeid` AS `ensa_entitystringattributeid`,
       `echothree`.`entitystringattributes`.`ensa_ena_entityattributeid`   AS `ensa_ena_entityattributeid`,
       `echothree`.`entitystringattributes`.`ensa_eni_entityinstanceid`    AS `ensa_eni_entityinstanceid`,
       `echothree`.`entitystringattributes`.`ensa_lang_languageid`         AS `ensa_lang_languageid`,
       `echothree`.`entitystringattributes`.`ensa_stringattribute`         AS `ensa_stringattribute`
from `echothree`.`entitystringattributes`
where (`echothree`.`entitystringattributes`.`ensa_thrutime` = 9223372036854775807);

