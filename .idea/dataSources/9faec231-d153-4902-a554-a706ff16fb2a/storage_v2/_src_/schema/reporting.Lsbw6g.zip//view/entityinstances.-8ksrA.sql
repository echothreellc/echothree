create definer = echothree@`127.0.0.1` view entityinstances as
select `echothree`.`entityinstances`.`eni_entityinstanceid` AS `eni_entityinstanceid`,
       `echothree`.`entityinstances`.`eni_ent_entitytypeid` AS `eni_ent_entitytypeid`,
       `echothree`.`entityinstances`.`eni_entityuniqueid`   AS `eni_entityuniqueid`,
       `echothree`.`entityinstances`.`eni_key`              AS `eni_key`,
       `echothree`.`entityinstances`.`eni_guid`             AS `eni_guid`,
       `echothree`.`entityinstances`.`eni_ulid`             AS `eni_ulid`
from `echothree`.`entityinstances`;

