create definer = echothree@`127.0.0.1` view events as
select `echothree`.`events`.`ev_eventid`                 AS `ev_eventid`,
       `echothree`.`events`.`ev_evgrp_eventgroupid`      AS `ev_evgrp_eventgroupid`,
       `echothree`.`events`.`ev_eventtime`               AS `ev_eventtime`,
       `echothree`.`events`.`ev_eventtimesequence`       AS `ev_eventtimesequence`,
       `echothree`.`events`.`ev_eni_entityinstanceid`    AS `ev_eni_entityinstanceid`,
       `echothree`.`events`.`ev_evty_eventtypeid`        AS `ev_evty_eventtypeid`,
       `echothree`.`events`.`ev_relatedentityinstanceid` AS `ev_relatedentityinstanceid`,
       `echothree`.`events`.`ev_relatedeventtypeid`      AS `ev_relatedeventtypeid`,
       `echothree`.`events`.`ev_createdbyid`             AS `ev_createdbyid`
from `echothree`.`events`;

