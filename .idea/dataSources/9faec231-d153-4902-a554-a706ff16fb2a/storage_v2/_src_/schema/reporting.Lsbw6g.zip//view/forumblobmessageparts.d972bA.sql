create definer = echothree@`127.0.0.1` view forumblobmessageparts as
select `echothree`.`forumblobmessageparts`.`frmbmsgprt_forumblobmessagepartid`       AS `frmbmsgprt_forumblobmessagepartid`,
       `echothree`.`forumblobmessageparts`.`frmbmsgprt_frmmsgprt_forummessagepartid` AS `frmbmsgprt_frmmsgprt_forummessagepartid`,
       `echothree`.`forumblobmessageparts`.`frmbmsgprt_blob`                         AS `frmbmsgprt_blob`
from `echothree`.`forumblobmessageparts`
where (`echothree`.`forumblobmessageparts`.`frmbmsgprt_thrutime` = 9223372036854775807);

