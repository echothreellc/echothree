create definer = echothree@`127.0.0.1` view communicationeventroles as
select `echothree`.`communicationeventroles`.`cmmnevr_communicationeventroleid`                AS `cmmnevr_communicationeventroleid`,
       `echothree`.`communicationeventroles`.`cmmnevr_cmmnev_communicationeventid`             AS `cmmnevr_cmmnev_communicationeventid`,
       `echothree`.`communicationeventroles`.`cmmnevr_par_partyid`                             AS `cmmnevr_par_partyid`,
       `echothree`.`communicationeventroles`.`cmmnevr_cmmnevrtyp_communicationeventroletypeid` AS `cmmnevr_cmmnevrtyp_communicationeventroletypeid`
from `echothree`.`communicationeventroles`
where (`echothree`.`communicationeventroles`.`cmmnevr_thrutime` = 9223372036854775807);

