create definer = echothree@`127.0.0.1` view itemadditionalchargetypes as
select `echothree`.`itemadditionalchargetypes`.`itmaddtlct_itemadditionalchargetypeid`           AS `itmaddtlct_itemadditionalchargetypeid`,
       `echothree`.`itemadditionalchargetypedetails`.`itmaddtlctdt_itemadditionalchargetypename` AS `itmaddtlctdt_itemadditionalchargetypename`,
       `echothree`.`itemadditionalchargetypedetails`.`itmaddtlctdt_isdefault`                    AS `itmaddtlctdt_isdefault`,
       `echothree`.`itemadditionalchargetypedetails`.`itmaddtlctdt_sortorder`                    AS `itmaddtlctdt_sortorder`
from `echothree`.`itemadditionalchargetypes`
         join `echothree`.`itemadditionalchargetypedetails`
where (`echothree`.`itemadditionalchargetypes`.`itmaddtlct_activedetailid` =
       `echothree`.`itemadditionalchargetypedetails`.`itmaddtlctdt_itemadditionalchargetypedetailid`);

