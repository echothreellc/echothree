create definer = echothree@`127.0.0.1` view lotaliastypes as
select `echothree`.`lotaliastypes`.`ltaltyp_lotaliastypeid`            AS `ltaltyp_lotaliastypeid`,
       `echothree`.`lotaliastypedetails`.`ltaltypdt_lotaliastypename`  AS `ltaltypdt_lotaliastypename`,
       `echothree`.`lotaliastypedetails`.`ltaltypdt_validationpattern` AS `ltaltypdt_validationpattern`,
       `echothree`.`lotaliastypedetails`.`ltaltypdt_isdefault`         AS `ltaltypdt_isdefault`,
       `echothree`.`lotaliastypedetails`.`ltaltypdt_sortorder`         AS `ltaltypdt_sortorder`
from `echothree`.`lotaliastypes`
         join `echothree`.`lotaliastypedetails`
where (`echothree`.`lotaliastypes`.`ltaltyp_activedetailid` =
       `echothree`.`lotaliastypedetails`.`ltaltypdt_lotaliastypedetailid`);

