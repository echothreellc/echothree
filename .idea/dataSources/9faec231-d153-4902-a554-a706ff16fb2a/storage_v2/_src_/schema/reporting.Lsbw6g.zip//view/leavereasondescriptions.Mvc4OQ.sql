create definer = echothree@`127.0.0.1` view leavereasondescriptions as
select `echothree`.`leavereasondescriptions`.`lvrsnd_leavereasondescriptionid` AS `lvrsnd_leavereasondescriptionid`,
       `echothree`.`leavereasondescriptions`.`lvrsnd_lvrsn_leavereasonid`      AS `lvrsnd_lvrsn_leavereasonid`,
       `echothree`.`leavereasondescriptions`.`lvrsnd_lang_languageid`          AS `lvrsnd_lang_languageid`,
       `echothree`.`leavereasondescriptions`.`lvrsnd_description`              AS `lvrsnd_description`
from `echothree`.`leavereasondescriptions`
where (`echothree`.`leavereasondescriptions`.`lvrsnd_thrutime` = 9223372036854775807);

