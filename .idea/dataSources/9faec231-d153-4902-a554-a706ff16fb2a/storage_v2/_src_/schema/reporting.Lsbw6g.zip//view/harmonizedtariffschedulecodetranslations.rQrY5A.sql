create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodetranslations as
select `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_harmonizedtariffschedulecodetranslationid` AS `hztsctr_harmonizedtariffschedulecodetranslationid`,
       `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_hztsc_harmonizedtariffschedulecodeid`      AS `hztsctr_hztsc_harmonizedtariffschedulecodeid`,
       `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_lang_languageid`                           AS `hztsctr_lang_languageid`,
       `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_description`                               AS `hztsctr_description`,
       `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_overviewmimetypeid`                        AS `hztsctr_overviewmimetypeid`,
       `echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_overview`                                  AS `hztsctr_overview`
from `echothree`.`harmonizedtariffschedulecodetranslations`
where (`echothree`.`harmonizedtariffschedulecodetranslations`.`hztsctr_thrutime` = 9223372036854775807);

