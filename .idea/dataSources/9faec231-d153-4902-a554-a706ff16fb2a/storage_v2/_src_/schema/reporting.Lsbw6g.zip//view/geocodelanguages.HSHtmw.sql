create definer = echothree@`127.0.0.1` view geocodelanguages as
select `echothree`.`geocodelanguages`.`geol_geocodelanguageid` AS `geol_geocodelanguageid`,
       `echothree`.`geocodelanguages`.`geol_geo_geocodeid`     AS `geol_geo_geocodeid`,
       `echothree`.`geocodelanguages`.`geol_lang_languageid`   AS `geol_lang_languageid`,
       `echothree`.`geocodelanguages`.`geol_isdefault`         AS `geol_isdefault`,
       `echothree`.`geocodelanguages`.`geol_sortorder`         AS `geol_sortorder`
from `echothree`.`geocodelanguages`
where (`echothree`.`geocodelanguages`.`geol_thrutime` = 9223372036854775807);

