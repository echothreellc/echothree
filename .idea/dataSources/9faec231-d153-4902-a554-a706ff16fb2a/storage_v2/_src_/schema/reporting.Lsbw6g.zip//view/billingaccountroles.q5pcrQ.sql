create definer = echothree@`127.0.0.1` view billingaccountroles as
select `echothree`.`billingaccountroles`.`bllactr_billingaccountroleid`                AS `bllactr_billingaccountroleid`,
       `echothree`.`billingaccountroles`.`bllactr_bllact_billingaccountid`             AS `bllactr_bllact_billingaccountid`,
       `echothree`.`billingaccountroles`.`bllactr_par_partyid`                         AS `bllactr_par_partyid`,
       `echothree`.`billingaccountroles`.`bllactr_pcm_partycontactmechanismid`         AS `bllactr_pcm_partycontactmechanismid`,
       `echothree`.`billingaccountroles`.`bllactr_bllactrtyp_billingaccountroletypeid` AS `bllactr_bllactrtyp_billingaccountroletypeid`
from `echothree`.`billingaccountroles`
where (`echothree`.`billingaccountroles`.`bllactr_thrutime` = 9223372036854775807);

