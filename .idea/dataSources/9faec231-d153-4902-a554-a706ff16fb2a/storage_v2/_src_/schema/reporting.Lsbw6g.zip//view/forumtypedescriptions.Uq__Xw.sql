create definer = echothree@`127.0.0.1` view forumtypedescriptions as
select `echothree`.`forumtypedescriptions`.`frmtypd_forumtypedescriptionid` AS `frmtypd_forumtypedescriptionid`,
       `echothree`.`forumtypedescriptions`.`frmtypd_frmtyp_forumtypeid`     AS `frmtypd_frmtyp_forumtypeid`,
       `echothree`.`forumtypedescriptions`.`frmtypd_lang_languageid`        AS `frmtypd_lang_languageid`,
       `echothree`.`forumtypedescriptions`.`frmtypd_description`            AS `frmtypd_description`
from `echothree`.`forumtypedescriptions`;

