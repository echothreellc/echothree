create definer = echothree@`127.0.0.1` view carriers as
select `echothree`.`carriers`.`crr_carrierid`                AS `crr_carrierid`,
       `echothree`.`carriers`.`crr_par_partyid`              AS `crr_par_partyid`,
       `echothree`.`carriers`.`crr_carriername`              AS `crr_carriername`,
       `echothree`.`carriers`.`crr_crrtyp_carriertypeid`     AS `crr_crrtyp_carriertypeid`,
       `echothree`.`carriers`.`crr_geocodeselectorid`        AS `crr_geocodeselectorid`,
       `echothree`.`carriers`.`crr_itemselectorid`           AS `crr_itemselectorid`,
       `echothree`.`carriers`.`crr_accountvalidationpattern` AS `crr_accountvalidationpattern`,
       `echothree`.`carriers`.`crr_isdefault`                AS `crr_isdefault`,
       `echothree`.`carriers`.`crr_sortorder`                AS `crr_sortorder`
from `echothree`.`carriers`
where (`echothree`.`carriers`.`crr_thrutime` = 9223372036854775807);

