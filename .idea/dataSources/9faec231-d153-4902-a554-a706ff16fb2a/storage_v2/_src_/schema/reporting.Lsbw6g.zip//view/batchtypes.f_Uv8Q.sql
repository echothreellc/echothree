create definer = echothree@`127.0.0.1` view batchtypes as
select `echothree`.`batchtypes`.`btchtyp_batchtypeid`                     AS `btchtyp_batchtypeid`,
       `echothree`.`batchtypedetails`.`btchtypdt_batchtypename`           AS `btchtypdt_batchtypename`,
       `echothree`.`batchtypedetails`.`btchtypdt_parentbatchtypeid`       AS `btchtypdt_parentbatchtypeid`,
       `echothree`.`batchtypedetails`.`btchtypdt_batchsequencetypeid`     AS `btchtypdt_batchsequencetypeid`,
       `echothree`.`batchtypedetails`.`btchtypdt_batchworkflowid`         AS `btchtypdt_batchworkflowid`,
       `echothree`.`batchtypedetails`.`btchtypdt_batchworkflowentranceid` AS `btchtypdt_batchworkflowentranceid`,
       `echothree`.`batchtypedetails`.`btchtypdt_isdefault`               AS `btchtypdt_isdefault`,
       `echothree`.`batchtypedetails`.`btchtypdt_sortorder`               AS `btchtypdt_sortorder`
from `echothree`.`batchtypes`
         join `echothree`.`batchtypedetails`
where (`echothree`.`batchtypes`.`btchtyp_activedetailid` =
       `echothree`.`batchtypedetails`.`btchtypdt_batchtypedetailid`);

