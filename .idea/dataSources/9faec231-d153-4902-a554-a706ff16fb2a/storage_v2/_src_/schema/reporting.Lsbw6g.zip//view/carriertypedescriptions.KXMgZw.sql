create definer = echothree@`127.0.0.1` view carriertypedescriptions as
select `echothree`.`carriertypedescriptions`.`crrtypd_carriertypedescriptionid` AS `crrtypd_carriertypedescriptionid`,
       `echothree`.`carriertypedescriptions`.`crrtypd_crrtyp_carriertypeid`     AS `crrtypd_crrtyp_carriertypeid`,
       `echothree`.`carriertypedescriptions`.`crrtypd_lang_languageid`          AS `crrtypd_lang_languageid`,
       `echothree`.`carriertypedescriptions`.`crrtypd_description`              AS `crrtypd_description`
from `echothree`.`carriertypedescriptions`
where (`echothree`.`carriertypedescriptions`.`crrtypd_thrutime` = 9223372036854775807);

