create definer = echothree@`127.0.0.1` view contentcategorydescriptions as
select `echothree`.`contentcategorydescriptions`.`cntcgd_contentcategorydescriptionid` AS `cntcgd_contentcategorydescriptionid`,
       `echothree`.`contentcategorydescriptions`.`cntcgd_cntcg_contentcategoryid`      AS `cntcgd_cntcg_contentcategoryid`,
       `echothree`.`contentcategorydescriptions`.`cntcgd_lang_languageid`              AS `cntcgd_lang_languageid`,
       `echothree`.`contentcategorydescriptions`.`cntcgd_description`                  AS `cntcgd_description`
from `echothree`.`contentcategorydescriptions`
where (`echothree`.`contentcategorydescriptions`.`cntcgd_thrutime` = 9223372036854775807);

