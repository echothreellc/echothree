create definer = echothree@`127.0.0.1` view currencies as
select `echothree`.`currencies`.`cur_currencyid`              AS `cur_currencyid`,
       `echothree`.`currencies`.`cur_currencyisoname`         AS `cur_currencyisoname`,
       `echothree`.`currencies`.`cur_symbol`                  AS `cur_symbol`,
       `echothree`.`currencies`.`cur_sympos_symbolpositionid` AS `cur_sympos_symbolpositionid`,
       `echothree`.`currencies`.`cur_symbolonliststart`       AS `cur_symbolonliststart`,
       `echothree`.`currencies`.`cur_symbolonlistmember`      AS `cur_symbolonlistmember`,
       `echothree`.`currencies`.`cur_symbolonsubtotal`        AS `cur_symbolonsubtotal`,
       `echothree`.`currencies`.`cur_symbolontotal`           AS `cur_symbolontotal`,
       `echothree`.`currencies`.`cur_groupingseparator`       AS `cur_groupingseparator`,
       `echothree`.`currencies`.`cur_groupingsize`            AS `cur_groupingsize`,
       `echothree`.`currencies`.`cur_fractionseparator`       AS `cur_fractionseparator`,
       `echothree`.`currencies`.`cur_defaultfractiondigits`   AS `cur_defaultfractiondigits`,
       `echothree`.`currencies`.`cur_priceunitfractiondigits` AS `cur_priceunitfractiondigits`,
       `echothree`.`currencies`.`cur_pricelinefractiondigits` AS `cur_pricelinefractiondigits`,
       `echothree`.`currencies`.`cur_costunitfractiondigits`  AS `cur_costunitfractiondigits`,
       `echothree`.`currencies`.`cur_costlinefractiondigits`  AS `cur_costlinefractiondigits`,
       `echothree`.`currencies`.`cur_minussign`               AS `cur_minussign`,
       `echothree`.`currencies`.`cur_isdefault`               AS `cur_isdefault`,
       `echothree`.`currencies`.`cur_sortorder`               AS `cur_sortorder`
from `echothree`.`currencies`;

