create definer = echothree@`127.0.0.1` view filteradjustmentfixedamounts as
select `echothree`.`filteradjustmentfixedamounts`.`fltafa_filteradjustmentfixedamountid` AS `fltafa_filteradjustmentfixedamountid`,
       `echothree`.`filteradjustmentfixedamounts`.`fltafa_flta_filteradjustmentid`       AS `fltafa_flta_filteradjustmentid`,
       `echothree`.`filteradjustmentfixedamounts`.`fltafa_uomt_unitofmeasuretypeid`      AS `fltafa_uomt_unitofmeasuretypeid`,
       `echothree`.`filteradjustmentfixedamounts`.`fltafa_cur_currencyid`                AS `fltafa_cur_currencyid`,
       `echothree`.`filteradjustmentfixedamounts`.`fltafa_unitamount`                    AS `fltafa_unitamount`
from `echothree`.`filteradjustmentfixedamounts`
where (`echothree`.`filteradjustmentfixedamounts`.`fltafa_thrutime` = 9223372036854775807);

