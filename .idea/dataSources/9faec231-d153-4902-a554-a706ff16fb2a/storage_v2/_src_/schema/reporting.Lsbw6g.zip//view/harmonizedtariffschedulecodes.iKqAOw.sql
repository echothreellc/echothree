create definer = echothree@`127.0.0.1` view harmonizedtariffschedulecodes as
select `echothree`.`harmonizedtariffschedulecodes`.`hztsc_harmonizedtariffschedulecodeid`                   AS `hztsc_harmonizedtariffschedulecodeid`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_countrygeocodeid`                         AS `hztscdt_countrygeocodeid`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_harmonizedtariffschedulecodename`         AS `hztscdt_harmonizedtariffschedulecodename`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_firstharmonizedtariffschedulecodeunitid`  AS `hztscdt_firstharmonizedtariffschedulecodeunitid`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_secondharmonizedtariffschedulecodeunitid` AS `hztscdt_secondharmonizedtariffschedulecodeunitid`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_isdefault`                                AS `hztscdt_isdefault`,
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_sortorder`                                AS `hztscdt_sortorder`
from `echothree`.`harmonizedtariffschedulecodes`
         join `echothree`.`harmonizedtariffschedulecodedetails`
where (`echothree`.`harmonizedtariffschedulecodes`.`hztsc_activedetailid` =
       `echothree`.`harmonizedtariffschedulecodedetails`.`hztscdt_harmonizedtariffschedulecodedetailid`);

