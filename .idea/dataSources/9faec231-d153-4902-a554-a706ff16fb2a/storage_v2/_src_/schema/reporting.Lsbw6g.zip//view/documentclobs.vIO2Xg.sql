create definer = echothree@`127.0.0.1` view documentclobs as
select `echothree`.`documentclobs`.`dcmntc_documentclobid`   AS `dcmntc_documentclobid`,
       `echothree`.`documentclobs`.`dcmntc_dcmnt_documentid` AS `dcmntc_dcmnt_documentid`,
       `echothree`.`documentclobs`.`dcmntc_clob`             AS `dcmntc_clob`
from `echothree`.`documentclobs`
where (`echothree`.`documentclobs`.`dcmntc_thrutime` = 9223372036854775807);

