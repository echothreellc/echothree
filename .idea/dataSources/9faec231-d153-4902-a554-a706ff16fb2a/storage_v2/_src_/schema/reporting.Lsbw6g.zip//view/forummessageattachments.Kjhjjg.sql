create definer = echothree@`127.0.0.1` view forummessageattachments as
select `echothree`.`forummessageattachments`.`frmmsgatt_forummessageattachmentid`               AS `frmmsgatt_forummessageattachmentid`,
       `echothree`.`forummessageattachmentdetails`.`frmmsgattdt_frmmsg_forummessageid`          AS `frmmsgattdt_frmmsg_forummessageid`,
       `echothree`.`forummessageattachmentdetails`.`frmmsgattdt_forummessageattachmentsequence` AS `frmmsgattdt_forummessageattachmentsequence`,
       `echothree`.`forummessageattachmentdetails`.`frmmsgattdt_mtyp_mimetypeid`                AS `frmmsgattdt_mtyp_mimetypeid`
from `echothree`.`forummessageattachments`
         join `echothree`.`forummessageattachmentdetails`
where (`echothree`.`forummessageattachments`.`frmmsgatt_activedetailid` =
       `echothree`.`forummessageattachmentdetails`.`frmmsgattdt_forummessageattachmentdetailid`);

