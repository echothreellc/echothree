create definer = echothree@`127.0.0.1` view itemaccountingcategories as
select `echothree`.`itemaccountingcategories`.`iactgc_itemaccountingcategoryid`              AS `iactgc_itemaccountingcategoryid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_itemaccountingcategoryname`     AS `iactgcdt_itemaccountingcategoryname`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_parentitemaccountingcategoryid` AS `iactgcdt_parentitemaccountingcategoryid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_inventoryglaccountid`           AS `iactgcdt_inventoryglaccountid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_salesglaccountid`               AS `iactgcdt_salesglaccountid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_returnsglaccountid`             AS `iactgcdt_returnsglaccountid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_cogsglaccountid`                AS `iactgcdt_cogsglaccountid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_returnscogsglaccountid`         AS `iactgcdt_returnscogsglaccountid`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_isdefault`                      AS `iactgcdt_isdefault`,
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_sortorder`                      AS `iactgcdt_sortorder`
from `echothree`.`itemaccountingcategories`
         join `echothree`.`itemaccountingcategorydetails`
where (`echothree`.`itemaccountingcategories`.`iactgc_activedetailid` =
       `echothree`.`itemaccountingcategorydetails`.`iactgcdt_itemaccountingcategorydetailid`);

