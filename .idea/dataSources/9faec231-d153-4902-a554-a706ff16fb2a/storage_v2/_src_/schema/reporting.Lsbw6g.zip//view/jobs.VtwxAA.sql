create definer = echothree@`127.0.0.1` view jobs as
select `echothree`.`jobs`.`jb_jobid`                AS `jb_jobid`,
       `echothree`.`jobdetails`.`jbdt_jobname`      AS `jbdt_jobname`,
       `echothree`.`jobdetails`.`jbdt_runaspartyid` AS `jbdt_runaspartyid`,
       `echothree`.`jobdetails`.`jbdt_sortorder`    AS `jbdt_sortorder`
from `echothree`.`jobs`
         join `echothree`.`jobdetails`
where (`echothree`.`jobs`.`jb_activedetailid` = `echothree`.`jobdetails`.`jbdt_jobdetailid`);

