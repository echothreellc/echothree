create definer = echothree@`127.0.0.1` view forumdescriptions as
select `echothree`.`forumdescriptions`.`frmd_forumdescriptionid` AS `frmd_forumdescriptionid`,
       `echothree`.`forumdescriptions`.`frmd_frm_forumid`        AS `frmd_frm_forumid`,
       `echothree`.`forumdescriptions`.`frmd_lang_languageid`    AS `frmd_lang_languageid`,
       `echothree`.`forumdescriptions`.`frmd_description`        AS `frmd_description`
from `echothree`.`forumdescriptions`
where (`echothree`.`forumdescriptions`.`frmd_thrutime` = 9223372036854775807);

