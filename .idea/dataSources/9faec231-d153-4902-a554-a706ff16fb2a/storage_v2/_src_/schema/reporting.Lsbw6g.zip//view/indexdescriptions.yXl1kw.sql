create definer = echothree@`127.0.0.1` view indexdescriptions as
select `echothree`.`indexdescriptions`.`idxd_indexdescriptionid` AS `idxd_indexdescriptionid`,
       `echothree`.`indexdescriptions`.`idxd_idx_indexid`        AS `idxd_idx_indexid`,
       `echothree`.`indexdescriptions`.`idxd_lang_languageid`    AS `idxd_lang_languageid`,
       `echothree`.`indexdescriptions`.`idxd_description`        AS `idxd_description`
from `echothree`.`indexdescriptions`
where (`echothree`.`indexdescriptions`.`idxd_thrutime` = 9223372036854775807);

