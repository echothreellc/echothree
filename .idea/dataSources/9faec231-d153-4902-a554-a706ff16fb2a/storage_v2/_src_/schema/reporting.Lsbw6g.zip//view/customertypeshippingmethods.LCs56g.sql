create definer = echothree@`127.0.0.1` view customertypeshippingmethods as
select `echothree`.`customertypeshippingmethods`.`cutyshm_customertypeshippingmethodid` AS `cutyshm_customertypeshippingmethodid`,
       `echothree`.`customertypeshippingmethods`.`cutyshm_cuty_customertypeid`          AS `cutyshm_cuty_customertypeid`,
       `echothree`.`customertypeshippingmethods`.`cutyshm_shm_shippingmethodid`         AS `cutyshm_shm_shippingmethodid`,
       `echothree`.`customertypeshippingmethods`.`cutyshm_defaultselectionpriority`     AS `cutyshm_defaultselectionpriority`,
       `echothree`.`customertypeshippingmethods`.`cutyshm_isdefault`                    AS `cutyshm_isdefault`,
       `echothree`.`customertypeshippingmethods`.`cutyshm_sortorder`                    AS `cutyshm_sortorder`
from `echothree`.`customertypeshippingmethods`
where (`echothree`.`customertypeshippingmethods`.`cutyshm_thrutime` = 9223372036854775807);

