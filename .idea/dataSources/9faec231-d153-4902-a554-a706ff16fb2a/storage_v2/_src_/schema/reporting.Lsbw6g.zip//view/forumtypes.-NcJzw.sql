create definer = echothree@`127.0.0.1` view forumtypes as
select `echothree`.`forumtypes`.`frmtyp_forumtypeid`   AS `frmtyp_forumtypeid`,
       `echothree`.`forumtypes`.`frmtyp_forumtypename` AS `frmtyp_forumtypename`,
       `echothree`.`forumtypes`.`frmtyp_isdefault`     AS `frmtyp_isdefault`,
       `echothree`.`forumtypes`.`frmtyp_sortorder`     AS `frmtyp_sortorder`
from `echothree`.`forumtypes`;

