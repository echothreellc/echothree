create definer = echothree@`127.0.0.1` view cacheblobentries as
select `echothree`.`cacheblobentries`.`cbent_cacheblobentryid`  AS `cbent_cacheblobentryid`,
       `echothree`.`cacheblobentries`.`cbent_cent_cacheentryid` AS `cbent_cent_cacheentryid`,
       `echothree`.`cacheblobentries`.`cbent_blob`              AS `cbent_blob`
from `echothree`.`cacheblobentries`;

