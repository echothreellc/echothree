create definer = echothree@`127.0.0.1` view languages as
select `echothree`.`languages`.`lang_languageid`      AS `lang_languageid`,
       `echothree`.`languages`.`lang_languageisoname` AS `lang_languageisoname`,
       `echothree`.`languages`.`lang_isdefault`       AS `lang_isdefault`,
       `echothree`.`languages`.`lang_sortorder`       AS `lang_sortorder`
from `echothree`.`languages`;

