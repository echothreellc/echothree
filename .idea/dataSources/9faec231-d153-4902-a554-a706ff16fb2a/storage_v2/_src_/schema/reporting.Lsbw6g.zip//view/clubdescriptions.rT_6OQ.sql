create definer = echothree@`127.0.0.1` view clubdescriptions as
select `echothree`.`clubdescriptions`.`clbd_clubdescriptionid` AS `clbd_clubdescriptionid`,
       `echothree`.`clubdescriptions`.`clbd_clb_clubid`        AS `clbd_clb_clubid`,
       `echothree`.`clubdescriptions`.`clbd_lang_languageid`   AS `clbd_lang_languageid`,
       `echothree`.`clubdescriptions`.`clbd_description`       AS `clbd_description`
from `echothree`.`clubdescriptions`
where (`echothree`.`clubdescriptions`.`clbd_thrutime` = 9223372036854775807);

