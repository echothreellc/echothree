create definer = echothree@`127.0.0.1` view cachedexecutedsearches as
select `echothree`.`cachedexecutedsearches`.`cxsrch_cachedexecutedsearchid` AS `cxsrch_cachedexecutedsearchid`,
       `echothree`.`cachedexecutedsearches`.`cxsrch_csrch_cachedsearchid`   AS `cxsrch_csrch_cachedsearchid`
from `echothree`.`cachedexecutedsearches`
where (`echothree`.`cachedexecutedsearches`.`cxsrch_thrutime` = 9223372036854775807);

