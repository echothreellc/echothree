create definer = echothree@`127.0.0.1` view geocodecountries as
select `echothree`.`geocodecountries`.`geoc_geocodecountryid`              AS `geoc_geocodecountryid`,
       `echothree`.`geocodecountries`.`geoc_geo_geocodeid`                 AS `geoc_geo_geocodeid`,
       `echothree`.`geocodecountries`.`geoc_telephonecode`                 AS `geoc_telephonecode`,
       `echothree`.`geocodecountries`.`geoc_areacodepattern`               AS `geoc_areacodepattern`,
       `echothree`.`geocodecountries`.`geoc_areacoderequired`              AS `geoc_areacoderequired`,
       `echothree`.`geocodecountries`.`geoc_areacodeexample`               AS `geoc_areacodeexample`,
       `echothree`.`geocodecountries`.`geoc_telephonenumberpattern`        AS `geoc_telephonenumberpattern`,
       `echothree`.`geocodecountries`.`geoc_telephonenumberexample`        AS `geoc_telephonenumberexample`,
       `echothree`.`geocodecountries`.`geoc_pstafmt_postaladdressformatid` AS `geoc_pstafmt_postaladdressformatid`,
       `echothree`.`geocodecountries`.`geoc_cityrequired`                  AS `geoc_cityrequired`,
       `echothree`.`geocodecountries`.`geoc_citygeocoderequired`           AS `geoc_citygeocoderequired`,
       `echothree`.`geocodecountries`.`geoc_staterequired`                 AS `geoc_staterequired`,
       `echothree`.`geocodecountries`.`geoc_stategeocoderequired`          AS `geoc_stategeocoderequired`,
       `echothree`.`geocodecountries`.`geoc_postalcodepattern`             AS `geoc_postalcodepattern`,
       `echothree`.`geocodecountries`.`geoc_postalcoderequired`            AS `geoc_postalcoderequired`,
       `echothree`.`geocodecountries`.`geoc_postalcodegeocoderequired`     AS `geoc_postalcodegeocoderequired`,
       `echothree`.`geocodecountries`.`geoc_postalcodelength`              AS `geoc_postalcodelength`,
       `echothree`.`geocodecountries`.`geoc_postalcodegeocodelength`       AS `geoc_postalcodegeocodelength`,
       `echothree`.`geocodecountries`.`geoc_postalcodeexample`             AS `geoc_postalcodeexample`
from `echothree`.`geocodecountries`
where (`echothree`.`geocodecountries`.`geoc_thrutime` = 9223372036854775807);

