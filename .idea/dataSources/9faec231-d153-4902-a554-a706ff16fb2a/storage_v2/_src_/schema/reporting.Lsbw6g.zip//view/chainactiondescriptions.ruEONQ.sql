create definer = echothree@`127.0.0.1` view chainactiondescriptions as
select `echothree`.`chainactiondescriptions`.`chnactd_chainactiondescriptionid` AS `chnactd_chainactiondescriptionid`,
       `echothree`.`chainactiondescriptions`.`chnactd_chnact_chainactionid`     AS `chnactd_chnact_chainactionid`,
       `echothree`.`chainactiondescriptions`.`chnactd_lang_languageid`          AS `chnactd_lang_languageid`,
       `echothree`.`chainactiondescriptions`.`chnactd_description`              AS `chnactd_description`
from `echothree`.`chainactiondescriptions`
where (`echothree`.`chainactiondescriptions`.`chnactd_thrutime` = 9223372036854775807);

