create definer = echothree@`127.0.0.1` view contactemailaddresses as
select `echothree`.`contactemailaddresses`.`ctea_contactemailaddressid`   AS `ctea_contactemailaddressid`,
       `echothree`.`contactemailaddresses`.`ctea_cmch_contactmechanismid` AS `ctea_cmch_contactmechanismid`,
       `echothree`.`contactemailaddresses`.`ctea_emailaddress`            AS `ctea_emailaddress`
from `echothree`.`contactemailaddresses`
where (`echothree`.`contactemailaddresses`.`ctea_thrutime` = 9223372036854775807);

