create definer = echothree@`127.0.0.1` view chaininstances as
select `echothree`.`chaininstances`.`chni_chaininstanceid`           AS `chni_chaininstanceid`,
       `echothree`.`chaininstancedetails`.`chnidt_chaininstancename` AS `chnidt_chaininstancename`,
       `echothree`.`chaininstancedetails`.`chnidt_chn_chainid`       AS `chnidt_chn_chainid`
from `echothree`.`chaininstances`
         join `echothree`.`chaininstancedetails`
where (`echothree`.`chaininstances`.`chni_activedetailid` =
       `echothree`.`chaininstancedetails`.`chnidt_chaininstancedetailid`);

