create definer = echothree@`127.0.0.1` view locationtypedescriptions as
select `echothree`.`locationtypedescriptions`.`loctypd_locationtypedescriptionid` AS `loctypd_locationtypedescriptionid`,
       `echothree`.`locationtypedescriptions`.`loctypd_loctyp_locationtypeid`     AS `loctypd_loctyp_locationtypeid`,
       `echothree`.`locationtypedescriptions`.`loctypd_lang_languageid`           AS `loctypd_lang_languageid`,
       `echothree`.`locationtypedescriptions`.`loctypd_description`               AS `loctypd_description`
from `echothree`.`locationtypedescriptions`
where (`echothree`.`locationtypedescriptions`.`loctypd_thrutime` = 9223372036854775807);

