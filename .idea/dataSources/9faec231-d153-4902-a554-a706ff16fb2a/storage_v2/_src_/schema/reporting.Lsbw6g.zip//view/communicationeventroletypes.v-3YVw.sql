create definer = echothree@`127.0.0.1` view communicationeventroletypes as
select `echothree`.`communicationeventroletypes`.`cmmnevrtyp_communicationeventroletypeid`   AS `cmmnevrtyp_communicationeventroletypeid`,
       `echothree`.`communicationeventroletypes`.`cmmnevrtyp_communicationeventroletypename` AS `cmmnevrtyp_communicationeventroletypename`,
       `echothree`.`communicationeventroletypes`.`cmmnevrtyp_sortorder`                      AS `cmmnevrtyp_sortorder`
from `echothree`.`communicationeventroletypes`;

