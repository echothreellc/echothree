create definer = echothree@`127.0.0.1` view datetimeformatdescriptions as
select `echothree`.`datetimeformatdescriptions`.`dtfd_datetimeformatdescriptionid` AS `dtfd_datetimeformatdescriptionid`,
       `echothree`.`datetimeformatdescriptions`.`dtfd_dtf_datetimeformatid`        AS `dtfd_dtf_datetimeformatid`,
       `echothree`.`datetimeformatdescriptions`.`dtfd_lang_languageid`             AS `dtfd_lang_languageid`,
       `echothree`.`datetimeformatdescriptions`.`dtfd_description`                 AS `dtfd_description`
from `echothree`.`datetimeformatdescriptions`
where (`echothree`.`datetimeformatdescriptions`.`dtfd_thrutime` = 9223372036854775807);

