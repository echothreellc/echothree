create definer = echothree@`127.0.0.1` view entitytimes as
select `echothree`.`entitytimes`.`etim_entitytimeid`         AS `etim_entitytimeid`,
       `echothree`.`entitytimes`.`etim_eni_entityinstanceid` AS `etim_eni_entityinstanceid`,
       `echothree`.`entitytimes`.`etim_createdtime`          AS `etim_createdtime`,
       `echothree`.`entitytimes`.`etim_modifiedtime`         AS `etim_modifiedtime`,
       `echothree`.`entitytimes`.`etim_deletedtime`          AS `etim_deletedtime`
from `echothree`.`entitytimes`;

