create definer = echothree@`127.0.0.1` view forumgroups as
select `echothree`.`forumgroups`.`frmgrp_forumgroupid`           AS `frmgrp_forumgroupid`,
       `echothree`.`forumgroupdetails`.`frmgrpdt_forumgroupname` AS `frmgrpdt_forumgroupname`,
       `echothree`.`forumgroupdetails`.`frmgrpdt_icn_iconid`     AS `frmgrpdt_icn_iconid`,
       `echothree`.`forumgroupdetails`.`frmgrpdt_sortorder`      AS `frmgrpdt_sortorder`
from `echothree`.`forumgroups`
         join `echothree`.`forumgroupdetails`
where (`echothree`.`forumgroups`.`frmgrp_activedetailid` =
       `echothree`.`forumgroupdetails`.`frmgrpdt_forumgroupdetailid`);

