create definer = echothree@`127.0.0.1` view glaccountclassdescriptions as
select `echothree`.`glaccountclassdescriptions`.`glaclsd_glaccountclassdescriptionid` AS `glaclsd_glaccountclassdescriptionid`,
       `echothree`.`glaccountclassdescriptions`.`glaclsd_glacls_glaccountclassid`     AS `glaclsd_glacls_glaccountclassid`,
       `echothree`.`glaccountclassdescriptions`.`glaclsd_lang_languageid`             AS `glaclsd_lang_languageid`,
       `echothree`.`glaccountclassdescriptions`.`glaclsd_description`                 AS `glaclsd_description`
from `echothree`.`glaccountclassdescriptions`
where (`echothree`.`glaccountclassdescriptions`.`glaclsd_thrutime` = 9223372036854775807);

