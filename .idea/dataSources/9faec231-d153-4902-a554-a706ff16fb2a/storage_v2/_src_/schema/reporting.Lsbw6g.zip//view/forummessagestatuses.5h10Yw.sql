create definer = echothree@`127.0.0.1` view forummessagestatuses as
select `echothree`.`forummessagestatuses`.`frmmsgst_forummessagestatusid`           AS `frmmsgst_forummessagestatusid`,
       `echothree`.`forummessagestatuses`.`frmmsgst_frmmsg_forummessageid`          AS `frmmsgst_frmmsg_forummessageid`,
       `echothree`.`forummessagestatuses`.`frmmsgst_forummessageattachmentsequence` AS `frmmsgst_forummessageattachmentsequence`
from `echothree`.`forummessagestatuses`;

