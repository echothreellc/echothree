create definer = echothree@`127.0.0.1` view contentcatalogitems as
select `echothree`.`contentcatalogitems`.`cntcti_contentcatalogitemid`        AS `cntcti_contentcatalogitemid`,
       `echothree`.`contentcatalogitems`.`cntcti_cntct_contentcatalogid`      AS `cntcti_cntct_contentcatalogid`,
       `echothree`.`contentcatalogitems`.`cntcti_itm_itemid`                  AS `cntcti_itm_itemid`,
       `echothree`.`contentcatalogitems`.`cntcti_invcon_inventoryconditionid` AS `cntcti_invcon_inventoryconditionid`,
       `echothree`.`contentcatalogitems`.`cntcti_uomt_unitofmeasuretypeid`    AS `cntcti_uomt_unitofmeasuretypeid`,
       `echothree`.`contentcatalogitems`.`cntcti_cur_currencyid`              AS `cntcti_cur_currencyid`
from `echothree`.`contentcatalogitems`
where (`echothree`.`contentcatalogitems`.`cntcti_thrutime` = 9223372036854775807);

