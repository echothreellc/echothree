create definer = echothree@`127.0.0.1` view contentpagelayoutareas as
select `echothree`.`contentpagelayoutareas`.`cntpla_contentpagelayoutareaid`      AS `cntpla_contentpagelayoutareaid`,
       `echothree`.`contentpagelayoutareas`.`cntpla_cntpl_contentpagelayoutid`    AS `cntpla_cntpl_contentpagelayoutid`,
       `echothree`.`contentpagelayoutareas`.`cntpla_cntpat_contentpageareatypeid` AS `cntpla_cntpat_contentpageareatypeid`,
       `echothree`.`contentpagelayoutareas`.`cntpla_showdescriptionfield`         AS `cntpla_showdescriptionfield`,
       `echothree`.`contentpagelayoutareas`.`cntpla_sortorder`                    AS `cntpla_sortorder`
from `echothree`.`contentpagelayoutareas`;

