create definer = echothree@`127.0.0.1` view chainactionsetdescriptions as
select `echothree`.`chainactionsetdescriptions`.`chnactstd_chainactionsetdescriptionid` AS `chnactstd_chainactionsetdescriptionid`,
       `echothree`.`chainactionsetdescriptions`.`chnactstd_chnactst_chainactionsetid`   AS `chnactstd_chnactst_chainactionsetid`,
       `echothree`.`chainactionsetdescriptions`.`chnactstd_lang_languageid`             AS `chnactstd_lang_languageid`,
       `echothree`.`chainactionsetdescriptions`.`chnactstd_description`                 AS `chnactstd_description`
from `echothree`.`chainactionsetdescriptions`
where (`echothree`.`chainactionsetdescriptions`.`chnactstd_thrutime` = 9223372036854775807);

