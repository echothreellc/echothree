create definer = echothree@`127.0.0.1` view contactinet4addresses as
select `echothree`.`contactinet4addresses`.`cti4a_contactinet4addressid`   AS `cti4a_contactinet4addressid`,
       `echothree`.`contactinet4addresses`.`cti4a_cmch_contactmechanismid` AS `cti4a_cmch_contactmechanismid`,
       `echothree`.`contactinet4addresses`.`cti4a_inet4address`            AS `cti4a_inet4address`
from `echothree`.`contactinet4addresses`
where (`echothree`.`contactinet4addresses`.`cti4a_thrutime` = 9223372036854775807);

