create definer = echothree@`127.0.0.1` view forummessageroles as
select `echothree`.`forummessageroles`.`frmmsgr_forummessageroleid`      AS `frmmsgr_forummessageroleid`,
       `echothree`.`forummessageroles`.`frmmsgr_frmmsg_forummessageid`   AS `frmmsgr_frmmsg_forummessageid`,
       `echothree`.`forummessageroles`.`frmmsgr_frmrtyp_forumroletypeid` AS `frmmsgr_frmrtyp_forumroletypeid`,
       `echothree`.`forummessageroles`.`frmmsgr_par_partyid`             AS `frmmsgr_par_partyid`
from `echothree`.`forummessageroles`
where (`echothree`.`forummessageroles`.`frmmsgr_thrutime` = 9223372036854775807);

