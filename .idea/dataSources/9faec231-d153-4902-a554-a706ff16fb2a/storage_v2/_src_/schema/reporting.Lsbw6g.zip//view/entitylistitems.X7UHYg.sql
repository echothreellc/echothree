create definer = echothree@`127.0.0.1` view entitylistitems as
select `echothree`.`entitylistitems`.`eli_entitylistitemid`              AS `eli_entitylistitemid`,
       `echothree`.`entitylistitemdetails`.`elidt_ena_entityattributeid` AS `elidt_ena_entityattributeid`,
       `echothree`.`entitylistitemdetails`.`elidt_entitylistitemname`    AS `elidt_entitylistitemname`,
       `echothree`.`entitylistitemdetails`.`elidt_isdefault`             AS `elidt_isdefault`,
       `echothree`.`entitylistitemdetails`.`elidt_sortorder`             AS `elidt_sortorder`
from `echothree`.`entitylistitems`
         join `echothree`.`entitylistitemdetails`
where (`echothree`.`entitylistitems`.`eli_activedetailid` =
       `echothree`.`entitylistitemdetails`.`elidt_entitylistitemdetailid`);

