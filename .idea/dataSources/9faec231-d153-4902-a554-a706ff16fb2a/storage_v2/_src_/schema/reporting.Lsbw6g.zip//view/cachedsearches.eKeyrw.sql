create definer = echothree@`127.0.0.1` view cachedsearches as
select `echothree`.`cachedsearches`.`csrch_cachedsearchid`                    AS `csrch_cachedsearchid`,
       `echothree`.`cachedsearches`.`csrch_idx_indexid`                       AS `csrch_idx_indexid`,
       `echothree`.`cachedsearches`.`csrch_querysha1hash`                     AS `csrch_querysha1hash`,
       `echothree`.`cachedsearches`.`csrch_query`                             AS `csrch_query`,
       `echothree`.`cachedsearches`.`csrch_parsedquerysha1hash`               AS `csrch_parsedquerysha1hash`,
       `echothree`.`cachedsearches`.`csrch_parsedquery`                       AS `csrch_parsedquery`,
       `echothree`.`cachedsearches`.`csrch_srchdefop_searchdefaultoperatorid` AS `csrch_srchdefop_searchdefaultoperatorid`,
       `echothree`.`cachedsearches`.`csrch_srchsrtord_searchsortorderid`      AS `csrch_srchsrtord_searchsortorderid`,
       `echothree`.`cachedsearches`.`csrch_srchsrtdir_searchsortdirectionid`  AS `csrch_srchsrtdir_searchsortdirectionid`
from `echothree`.`cachedsearches`
where (`echothree`.`cachedsearches`.`csrch_thrutime` = 9223372036854775807);

