create definer = echothree@`127.0.0.1` view invoicealiastypes as
select `echothree`.`invoicealiastypes`.`invcaltyp_invoicealiastypeid`            AS `invcaltyp_invoicealiastypeid`,
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_invctyp_invoicetypeid` AS `invcaltypdt_invctyp_invoicetypeid`,
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_invoicealiastypename`  AS `invcaltypdt_invoicealiastypename`,
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_validationpattern`     AS `invcaltypdt_validationpattern`,
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_isdefault`             AS `invcaltypdt_isdefault`,
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_sortorder`             AS `invcaltypdt_sortorder`
from `echothree`.`invoicealiastypes`
         join `echothree`.`invoicealiastypedetails`
where (`echothree`.`invoicealiastypes`.`invcaltyp_activedetailid` =
       `echothree`.`invoicealiastypedetails`.`invcaltypdt_invoicealiastypedetailid`);

