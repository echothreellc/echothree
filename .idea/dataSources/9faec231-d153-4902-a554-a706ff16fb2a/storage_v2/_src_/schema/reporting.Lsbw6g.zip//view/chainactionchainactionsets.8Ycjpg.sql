create definer = echothree@`127.0.0.1` view chainactionchainactionsets as
select `echothree`.`chainactionchainactionsets`.`chnactchnactst_chainactionchainactionsetid` AS `chnactchnactst_chainactionchainactionsetid`,
       `echothree`.`chainactionchainactionsets`.`chnactchnactst_chnact_chainactionid`        AS `chnactchnactst_chnact_chainactionid`,
       `echothree`.`chainactionchainactionsets`.`chnactchnactst_nextchainactionsetid`        AS `chnactchnactst_nextchainactionsetid`,
       `echothree`.`chainactionchainactionsets`.`chnactchnactst_delaytime`                   AS `chnactchnactst_delaytime`
from `echothree`.`chainactionchainactionsets`
where (`echothree`.`chainactionchainactionsets`.`chnactchnactst_thrutime` = 9223372036854775807);

