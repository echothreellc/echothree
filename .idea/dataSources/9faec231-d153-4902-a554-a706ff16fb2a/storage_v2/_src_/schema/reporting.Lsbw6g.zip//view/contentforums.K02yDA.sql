create definer = echothree@`127.0.0.1` view contentforums as
select `echothree`.`contentforums`.`cntfrm_contentforumid`                   AS `cntfrm_contentforumid`,
       `echothree`.`contentforumdetails`.`cntfrmdt_cntc_contentcollectionid` AS `cntfrmdt_cntc_contentcollectionid`,
       `echothree`.`contentforumdetails`.`cntfrmdt_frm_forumid`              AS `cntfrmdt_frm_forumid`,
       `echothree`.`contentforumdetails`.`cntfrmdt_isdefault`                AS `cntfrmdt_isdefault`
from `echothree`.`contentforums`
         join `echothree`.`contentforumdetails`
where (`echothree`.`contentforums`.`cntfrm_activedetailid` =
       `echothree`.`contentforumdetails`.`cntfrmdt_contentforumdetailid`);

