create definer = echothree@`127.0.0.1` view forumgroupdescriptions as
select `echothree`.`forumgroupdescriptions`.`frmgrpd_forumgroupdescriptionid` AS `frmgrpd_forumgroupdescriptionid`,
       `echothree`.`forumgroupdescriptions`.`frmgrpd_frmgrp_forumgroupid`     AS `frmgrpd_frmgrp_forumgroupid`,
       `echothree`.`forumgroupdescriptions`.`frmgrpd_lang_languageid`         AS `frmgrpd_lang_languageid`,
       `echothree`.`forumgroupdescriptions`.`frmgrpd_description`             AS `frmgrpd_description`
from `echothree`.`forumgroupdescriptions`
where (`echothree`.`forumgroupdescriptions`.`frmgrpd_thrutime` = 9223372036854775807);

