create definer = echothree@`127.0.0.1` view contactmechanismaliastypes as
select `echothree`.`contactmechanismaliastypes`.`cmchaltyp_contactmechanismaliastypeid`           AS `cmchaltyp_contactmechanismaliastypeid`,
       `echothree`.`contactmechanismaliastypedetails`.`cmchaltypdt_contactmechanismaliastypename` AS `cmchaltypdt_contactmechanismaliastypename`,
       `echothree`.`contactmechanismaliastypedetails`.`cmchaltypdt_validationpattern`             AS `cmchaltypdt_validationpattern`,
       `echothree`.`contactmechanismaliastypedetails`.`cmchaltypdt_isdefault`                     AS `cmchaltypdt_isdefault`,
       `echothree`.`contactmechanismaliastypedetails`.`cmchaltypdt_sortorder`                     AS `cmchaltypdt_sortorder`
from `echothree`.`contactmechanismaliastypes`
         join `echothree`.`contactmechanismaliastypedetails`
where (`echothree`.`contactmechanismaliastypes`.`cmchaltyp_activedetailid` =
       `echothree`.`contactmechanismaliastypedetails`.`cmchaltypdt_contactmechanismaliastypedetailid`);

