create definer = echothree@`127.0.0.1` view customertypecontactlistgroups as
select `echothree`.`customertypecontactlistgroups`.`cutyclstgrp_customertypecontactlistgroupid` AS `cutyclstgrp_customertypecontactlistgroupid`,
       `echothree`.`customertypecontactlistgroups`.`cutyclstgrp_cuty_customertypeid`            AS `cutyclstgrp_cuty_customertypeid`,
       `echothree`.`customertypecontactlistgroups`.`cutyclstgrp_clstgrp_contactlistgroupid`     AS `cutyclstgrp_clstgrp_contactlistgroupid`,
       `echothree`.`customertypecontactlistgroups`.`cutyclstgrp_addwhencreated`                 AS `cutyclstgrp_addwhencreated`
from `echothree`.`customertypecontactlistgroups`
where (`echothree`.`customertypecontactlistgroups`.`cutyclstgrp_thrutime` = 9223372036854775807);

