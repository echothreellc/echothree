create definer = echothree@`127.0.0.1` view invoicelineitems as
select `echothree`.`invoicelineitems`.`invclitm_invoicelineitemid`           AS `invclitm_invoicelineitemid`,
       `echothree`.`invoicelineitems`.`invclitm_invcl_invoicelineid`         AS `invclitm_invcl_invoicelineid`,
       `echothree`.`invoicelineitems`.`invclitm_itm_itemid`                  AS `invclitm_itm_itemid`,
       `echothree`.`invoicelineitems`.`invclitm_invcon_inventoryconditionid` AS `invclitm_invcon_inventoryconditionid`,
       `echothree`.`invoicelineitems`.`invclitm_uomt_unitofmeasuretypeid`    AS `invclitm_uomt_unitofmeasuretypeid`,
       `echothree`.`invoicelineitems`.`invclitm_quantity`                    AS `invclitm_quantity`
from `echothree`.`invoicelineitems`
where (`echothree`.`invoicelineitems`.`invclitm_thrutime` = 9223372036854775807);

