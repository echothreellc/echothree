create definer = echothree@`127.0.0.1` view billingaccountroletypes as
select `echothree`.`billingaccountroletypes`.`bllactrtyp_billingaccountroletypeid`   AS `bllactrtyp_billingaccountroletypeid`,
       `echothree`.`billingaccountroletypes`.`bllactrtyp_billingaccountroletypename` AS `bllactrtyp_billingaccountroletypename`,
       `echothree`.`billingaccountroletypes`.`bllactrtyp_sortorder`                  AS `bllactrtyp_sortorder`
from `echothree`.`billingaccountroletypes`;

