create definer = echothree@`127.0.0.1` view campaignsourcedescriptions as
select `echothree`.`campaignsourcedescriptions`.`cmpgnsrcd_campaignsourcedescriptionid` AS `cmpgnsrcd_campaignsourcedescriptionid`,
       `echothree`.`campaignsourcedescriptions`.`cmpgnsrcd_cmpgnsrc_campaignsourceid`   AS `cmpgnsrcd_cmpgnsrc_campaignsourceid`,
       `echothree`.`campaignsourcedescriptions`.`cmpgnsrcd_lang_languageid`             AS `cmpgnsrcd_lang_languageid`,
       `echothree`.`campaignsourcedescriptions`.`cmpgnsrcd_description`                 AS `cmpgnsrcd_description`
from `echothree`.`campaignsourcedescriptions`
where (`echothree`.`campaignsourcedescriptions`.`cmpgnsrcd_thrutime` = 9223372036854775807);

