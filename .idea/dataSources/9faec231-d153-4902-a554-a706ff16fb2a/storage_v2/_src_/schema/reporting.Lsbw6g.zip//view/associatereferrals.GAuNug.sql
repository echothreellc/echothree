create definer = echothree@`127.0.0.1` view associatereferrals as
select `echothree`.`associatereferrals`.`ascrfr_associatereferralid`                             AS `ascrfr_associatereferralid`,
       `echothree`.`associatereferraldetails`.`ascrfrdt_associatereferralname`                   AS `ascrfrdt_associatereferralname`,
       `echothree`.`associatereferraldetails`.`ascrfrdt_asc_associateid`                         AS `ascrfrdt_asc_associateid`,
       `echothree`.`associatereferraldetails`.`ascrfrdt_ascpcm_associatepartycontactmechanismid` AS `ascrfrdt_ascpcm_associatepartycontactmechanismid`,
       `echothree`.`associatereferraldetails`.`ascrfrdt_targetentityinstanceid`                  AS `ascrfrdt_targetentityinstanceid`,
       `echothree`.`associatereferraldetails`.`ascrfrdt_associatereferraltime`                   AS `ascrfrdt_associatereferraltime`
from `echothree`.`associatereferrals`
         join `echothree`.`associatereferraldetails`
where (`echothree`.`associatereferrals`.`ascrfr_activedetailid` =
       `echothree`.`associatereferraldetails`.`ascrfrdt_associatereferraldetailid`);

