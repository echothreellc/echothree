create definer = echothree@`127.0.0.1` view cancellationreasondescriptions as
select `echothree`.`cancellationreasondescriptions`.`cnclrsnd_cancellationreasondescriptionid` AS `cnclrsnd_cancellationreasondescriptionid`,
       `echothree`.`cancellationreasondescriptions`.`cnclrsnd_cnclrsn_cancellationreasonid`    AS `cnclrsnd_cnclrsn_cancellationreasonid`,
       `echothree`.`cancellationreasondescriptions`.`cnclrsnd_lang_languageid`                 AS `cnclrsnd_lang_languageid`,
       `echothree`.`cancellationreasondescriptions`.`cnclrsnd_description`                     AS `cnclrsnd_description`
from `echothree`.`cancellationreasondescriptions`
where (`echothree`.`cancellationreasondescriptions`.`cnclrsnd_thrutime` = 9223372036854775807);

