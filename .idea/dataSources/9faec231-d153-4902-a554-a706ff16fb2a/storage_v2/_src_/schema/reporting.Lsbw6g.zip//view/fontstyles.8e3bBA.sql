create definer = echothree@`127.0.0.1` view fontstyles as
select `echothree`.`fontstyles`.`fntstyl_fontstyleid`           AS `fntstyl_fontstyleid`,
       `echothree`.`fontstyledetails`.`fntstyldt_fontstylename` AS `fntstyldt_fontstylename`,
       `echothree`.`fontstyledetails`.`fntstyldt_isdefault`     AS `fntstyldt_isdefault`,
       `echothree`.`fontstyledetails`.`fntstyldt_sortorder`     AS `fntstyldt_sortorder`
from `echothree`.`fontstyles`
         join `echothree`.`fontstyledetails`
where (`echothree`.`fontstyles`.`fntstyl_activedetailid` =
       `echothree`.`fontstyledetails`.`fntstyldt_fontstyledetailid`);

