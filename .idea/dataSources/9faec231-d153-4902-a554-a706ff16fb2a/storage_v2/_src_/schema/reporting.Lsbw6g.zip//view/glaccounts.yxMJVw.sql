create definer = echothree@`127.0.0.1` view glaccounts as
select `echothree`.`glaccounts`.`gla_glaccountid`                      AS `gla_glaccountid`,
       `echothree`.`glaccountdetails`.`gladt_glaccountname`            AS `gladt_glaccountname`,
       `echothree`.`glaccountdetails`.`gladt_parentglaccountid`        AS `gladt_parentglaccountid`,
       `echothree`.`glaccountdetails`.`gladt_glatyp_glaccounttypeid`   AS `gladt_glatyp_glaccounttypeid`,
       `echothree`.`glaccountdetails`.`gladt_glacls_glaccountclassid`  AS `gladt_glacls_glaccountclassid`,
       `echothree`.`glaccountdetails`.`gladt_glac_glaccountcategoryid` AS `gladt_glac_glaccountcategoryid`,
       `echothree`.`glaccountdetails`.`gladt_glrtyp_glresourcetypeid`  AS `gladt_glrtyp_glresourcetypeid`,
       `echothree`.`glaccountdetails`.`gladt_cur_currencyid`           AS `gladt_cur_currencyid`,
       `echothree`.`glaccountdetails`.`gladt_isdefault`                AS `gladt_isdefault`
from `echothree`.`glaccounts`
         join `echothree`.`glaccountdetails`
where (`echothree`.`glaccounts`.`gla_activedetailid` = `echothree`.`glaccountdetails`.`gladt_glaccountdetailid`);

