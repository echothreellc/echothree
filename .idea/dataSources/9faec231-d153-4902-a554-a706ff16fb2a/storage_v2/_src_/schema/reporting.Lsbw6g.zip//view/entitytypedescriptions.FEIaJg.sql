create definer = echothree@`127.0.0.1` view entitytypedescriptions as
select `echothree`.`entitytypedescriptions`.`entd_entitytypedescriptionid` AS `entd_entitytypedescriptionid`,
       `echothree`.`entitytypedescriptions`.`entd_ent_entitytypeid`        AS `entd_ent_entitytypeid`,
       `echothree`.`entitytypedescriptions`.`entd_lang_languageid`         AS `entd_lang_languageid`,
       `echothree`.`entitytypedescriptions`.`entd_description`             AS `entd_description`
from `echothree`.`entitytypedescriptions`
where (`echothree`.`entitytypedescriptions`.`entd_thrutime` = 9223372036854775807);

