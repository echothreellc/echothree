create definer = echothree@`127.0.0.1` view itemimagetypes as
select `echothree`.`itemimagetypes`.`iimgt_itemimagetypeid`             AS `iimgt_itemimagetypeid`,
       `echothree`.`itemimagetypedetails`.`iimgtdt_itemimagetypename`   AS `iimgtdt_itemimagetypename`,
       `echothree`.`itemimagetypedetails`.`iimgtdt_preferredmimetypeid` AS `iimgtdt_preferredmimetypeid`,
       `echothree`.`itemimagetypedetails`.`iimgtdt_quality`             AS `iimgtdt_quality`,
       `echothree`.`itemimagetypedetails`.`iimgtdt_isdefault`           AS `iimgtdt_isdefault`,
       `echothree`.`itemimagetypedetails`.`iimgtdt_sortorder`           AS `iimgtdt_sortorder`
from `echothree`.`itemimagetypes`
         join `echothree`.`itemimagetypedetails`
where (`echothree`.`itemimagetypes`.`iimgt_activedetailid` =
       `echothree`.`itemimagetypedetails`.`iimgtdt_itemimagetypedetailid`);

