create definer = echothree@`127.0.0.1` view entitylocks as
select `echothree`.`entitylocks`.`lcks_locktargetentityinstanceid` AS `lcks_locktargetentityinstanceid`,
       `echothree`.`entitylocks`.`lcks_lockedbyentityinstanceid`   AS `lcks_lockedbyentityinstanceid`,
       `echothree`.`entitylocks`.`lcks_lockedtime`                 AS `lcks_lockedtime`,
       `echothree`.`entitylocks`.`lcks_lockexpirationtime`         AS `lcks_lockexpirationtime`
from `echothree`.`entitylocks`;

