create definer = echothree@`127.0.0.1` view geocodealiases as
select `echothree`.`geocodealiases`.`geoa_geocodealiasid`           AS `geoa_geocodealiasid`,
       `echothree`.`geocodealiases`.`geoa_geo_geocodeid`            AS `geoa_geo_geocodeid`,
       `echothree`.`geocodealiases`.`geoa_geos_geocodescopeid`      AS `geoa_geos_geocodescopeid`,
       `echothree`.`geocodealiases`.`geoa_geoat_geocodealiastypeid` AS `geoa_geoat_geocodealiastypeid`,
       `echothree`.`geocodealiases`.`geoa_alias`                    AS `geoa_alias`
from `echothree`.`geocodealiases`
where (`echothree`.`geocodealiases`.`geoa_thrutime` = 9223372036854775807);

