create definer = echothree@`127.0.0.1` view items as
select `echothree`.`items`.`itm_itemid`                                  AS `itm_itemid`,
       `echothree`.`itemdetails`.`itmdt_itemname`                        AS `itmdt_itemname`,
       `echothree`.`itemdetails`.`itmdt_ityp_itemtypeid`                 AS `itmdt_ityp_itemtypeid`,
       `echothree`.`itemdetails`.`itmdt_iutyp_itemusetypeid`             AS `itmdt_iutyp_itemusetypeid`,
       `echothree`.`itemdetails`.`itmdt_ic_itemcategoryid`               AS `itmdt_ic_itemcategoryid`,
       `echothree`.`itemdetails`.`itmdt_iactgc_itemaccountingcategoryid` AS `itmdt_iactgc_itemaccountingcategoryid`,
       `echothree`.`itemdetails`.`itmdt_iprchc_itempurchasingcategoryid` AS `itmdt_iprchc_itempurchasingcategoryid`,
       `echothree`.`itemdetails`.`itmdt_companypartyid`                  AS `itmdt_companypartyid`,
       `echothree`.`itemdetails`.`itmdt_idlvrtyp_itemdeliverytypeid`     AS `itmdt_idlvrtyp_itemdeliverytypeid`,
       `echothree`.`itemdetails`.`itmdt_iinvtyp_iteminventorytypeid`     AS `itmdt_iinvtyp_iteminventorytypeid`,
       `echothree`.`itemdetails`.`itmdt_inventoryserialized`             AS `itmdt_inventoryserialized`,
       `echothree`.`itemdetails`.`itmdt_serialnumbersequenceid`          AS `itmdt_serialnumbersequenceid`,
       `echothree`.`itemdetails`.`itmdt_shippingchargeexempt`            AS `itmdt_shippingchargeexempt`,
       `echothree`.`itemdetails`.`itmdt_shippingstarttime`               AS `itmdt_shippingstarttime`,
       `echothree`.`itemdetails`.`itmdt_shippingendtime`                 AS `itmdt_shippingendtime`,
       `echothree`.`itemdetails`.`itmdt_salesorderstarttime`             AS `itmdt_salesorderstarttime`,
       `echothree`.`itemdetails`.`itmdt_salesorderendtime`               AS `itmdt_salesorderendtime`,
       `echothree`.`itemdetails`.`itmdt_purchaseorderstarttime`          AS `itmdt_purchaseorderstarttime`,
       `echothree`.`itemdetails`.`itmdt_purchaseorderendtime`            AS `itmdt_purchaseorderendtime`,
       `echothree`.`itemdetails`.`itmdt_allowclubdiscounts`              AS `itmdt_allowclubdiscounts`,
       `echothree`.`itemdetails`.`itmdt_allowcoupondiscounts`            AS `itmdt_allowcoupondiscounts`,
       `echothree`.`itemdetails`.`itmdt_allowassociatepayments`          AS `itmdt_allowassociatepayments`,
       `echothree`.`itemdetails`.`itmdt_uomk_unitofmeasurekindid`        AS `itmdt_uomk_unitofmeasurekindid`,
       `echothree`.`itemdetails`.`itmdt_ipt_itempricetypeid`             AS `itmdt_ipt_itempricetypeid`,
       `echothree`.`itemdetails`.`itmdt_cnclplcy_cancellationpolicyid`   AS `itmdt_cnclplcy_cancellationpolicyid`,
       `echothree`.`itemdetails`.`itmdt_rtnplcy_returnpolicyid`          AS `itmdt_rtnplcy_returnpolicyid`,
       `echothree`.`itemdetails`.`itmdt_stylpth_stylepathid`             AS `itmdt_stylpth_stylepathid`
from `echothree`.`items`
         join `echothree`.`itemdetails`
where (`echothree`.`items`.`itm_activedetailid` = `echothree`.`itemdetails`.`itmdt_itemdetailid`);

