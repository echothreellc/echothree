create definer = echothree@`127.0.0.1` view contentcatalogitemfixedprices as
select `echothree`.`contentcatalogitemfixedprices`.`cntctifp_contentcatalogitemfixedpriceid` AS `cntctifp_contentcatalogitemfixedpriceid`,
       `echothree`.`contentcatalogitemfixedprices`.`cntctifp_cntcti_contentcatalogitemid`    AS `cntctifp_cntcti_contentcatalogitemid`,
       `echothree`.`contentcatalogitemfixedprices`.`cntctifp_unitprice`                      AS `cntctifp_unitprice`
from `echothree`.`contentcatalogitemfixedprices`
where (`echothree`.`contentcatalogitemfixedprices`.`cntctifp_thrutime` = 9223372036854775807);

