create definer = echothree@`127.0.0.1` view contentpageareatypes as
select `echothree`.`contentpageareatypes`.`cntpat_contentpageareatypeid`   AS `cntpat_contentpageareatypeid`,
       `echothree`.`contentpageareatypes`.`cntpat_contentpageareatypename` AS `cntpat_contentpageareatypename`
from `echothree`.`contentpageareatypes`;

