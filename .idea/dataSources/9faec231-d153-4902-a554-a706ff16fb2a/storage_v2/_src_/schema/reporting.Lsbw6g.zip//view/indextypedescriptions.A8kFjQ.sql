create definer = echothree@`127.0.0.1` view indextypedescriptions as
select `echothree`.`indextypedescriptions`.`idxtd_indextypedescriptionid` AS `idxtd_indextypedescriptionid`,
       `echothree`.`indextypedescriptions`.`idxtd_idxt_indextypeid`       AS `idxtd_idxt_indextypeid`,
       `echothree`.`indextypedescriptions`.`idxtd_lang_languageid`        AS `idxtd_lang_languageid`,
       `echothree`.`indextypedescriptions`.`idxtd_description`            AS `idxtd_description`
from `echothree`.`indextypedescriptions`
where (`echothree`.`indextypedescriptions`.`idxtd_thrutime` = 9223372036854775807);

