create definer = echothree@`127.0.0.1` view campaigns as
select `echothree`.`campaigns`.`cmpgn_campaignid`            AS `cmpgn_campaignid`,
       `echothree`.`campaigndetails`.`cmpgndt_campaignname`  AS `cmpgndt_campaignname`,
       `echothree`.`campaigndetails`.`cmpgndt_valuesha1hash` AS `cmpgndt_valuesha1hash`,
       `echothree`.`campaigndetails`.`cmpgndt_value`         AS `cmpgndt_value`,
       `echothree`.`campaigndetails`.`cmpgndt_isdefault`     AS `cmpgndt_isdefault`,
       `echothree`.`campaigndetails`.`cmpgndt_sortorder`     AS `cmpgndt_sortorder`
from `echothree`.`campaigns`
         join `echothree`.`campaigndetails`
where (`echothree`.`campaigns`.`cmpgn_activedetailid` = `echothree`.`campaigndetails`.`cmpgndt_campaigndetailid`);

