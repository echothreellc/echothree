create definer = echothree@`127.0.0.1` view customertypepaymentmethods as
select `echothree`.`customertypepaymentmethods`.`cutypm_customertypepaymentmethodid` AS `cutypm_customertypepaymentmethodid`,
       `echothree`.`customertypepaymentmethods`.`cutypm_cuty_customertypeid`         AS `cutypm_cuty_customertypeid`,
       `echothree`.`customertypepaymentmethods`.`cutypm_pm_paymentmethodid`          AS `cutypm_pm_paymentmethodid`,
       `echothree`.`customertypepaymentmethods`.`cutypm_defaultselectionpriority`    AS `cutypm_defaultselectionpriority`,
       `echothree`.`customertypepaymentmethods`.`cutypm_isdefault`                   AS `cutypm_isdefault`,
       `echothree`.`customertypepaymentmethods`.`cutypm_sortorder`                   AS `cutypm_sortorder`
from `echothree`.`customertypepaymentmethods`
where (`echothree`.`customertypepaymentmethods`.`cutypm_thrutime` = 9223372036854775807);

