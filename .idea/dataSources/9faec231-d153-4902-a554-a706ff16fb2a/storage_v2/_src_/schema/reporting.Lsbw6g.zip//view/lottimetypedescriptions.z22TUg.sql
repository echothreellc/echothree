create definer = echothree@`127.0.0.1` view lottimetypedescriptions as
select `echothree`.`lottimetypedescriptions`.`lttimtypd_lottimetypedescriptionid` AS `lttimtypd_lottimetypedescriptionid`,
       `echothree`.`lottimetypedescriptions`.`lttimtypd_lttimtyp_lottimetypeid`   AS `lttimtypd_lttimtyp_lottimetypeid`,
       `echothree`.`lottimetypedescriptions`.`lttimtypd_lang_languageid`          AS `lttimtypd_lang_languageid`,
       `echothree`.`lottimetypedescriptions`.`lttimtypd_description`              AS `lttimtypd_description`
from `echothree`.`lottimetypedescriptions`
where (`echothree`.`lottimetypedescriptions`.`lttimtypd_thrutime` = 9223372036854775807);

