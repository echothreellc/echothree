create definer = echothree@`127.0.0.1` view invoiceroletypes as
select `echothree`.`invoiceroletypes`.`invcrtyp_invoiceroletypeid`   AS `invcrtyp_invoiceroletypeid`,
       `echothree`.`invoiceroletypes`.`invcrtyp_invoiceroletypename` AS `invcrtyp_invoiceroletypename`,
       `echothree`.`invoiceroletypes`.`invcrtyp_sortorder`           AS `invcrtyp_sortorder`
from `echothree`.`invoiceroletypes`;

