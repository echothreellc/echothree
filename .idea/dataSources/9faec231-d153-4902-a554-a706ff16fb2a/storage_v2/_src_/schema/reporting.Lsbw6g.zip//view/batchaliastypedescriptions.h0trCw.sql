create definer = echothree@`127.0.0.1` view batchaliastypedescriptions as
select `echothree`.`batchaliastypedescriptions`.`btchatd_batchaliastypedescriptionid` AS `btchatd_batchaliastypedescriptionid`,
       `echothree`.`batchaliastypedescriptions`.`btchatd_btchat_batchaliastypeid`     AS `btchatd_btchat_batchaliastypeid`,
       `echothree`.`batchaliastypedescriptions`.`btchatd_lang_languageid`             AS `btchatd_lang_languageid`,
       `echothree`.`batchaliastypedescriptions`.`btchatd_description`                 AS `btchatd_description`
from `echothree`.`batchaliastypedescriptions`
where (`echothree`.`batchaliastypedescriptions`.`btchatd_thrutime` = 9223372036854775807);

