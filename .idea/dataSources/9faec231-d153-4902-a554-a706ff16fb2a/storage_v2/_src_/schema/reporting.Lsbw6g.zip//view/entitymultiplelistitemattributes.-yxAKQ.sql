create definer = echothree@`127.0.0.1` view entitymultiplelistitemattributes as
select `echothree`.`entitymultiplelistitemattributes`.`emlia_entitymultiplelistitemattributeid` AS `emlia_entitymultiplelistitemattributeid`,
       `echothree`.`entitymultiplelistitemattributes`.`emlia_ena_entityattributeid`             AS `emlia_ena_entityattributeid`,
       `echothree`.`entitymultiplelistitemattributes`.`emlia_eni_entityinstanceid`              AS `emlia_eni_entityinstanceid`,
       `echothree`.`entitymultiplelistitemattributes`.`emlia_eli_entitylistitemid`              AS `emlia_eli_entitylistitemid`
from `echothree`.`entitymultiplelistitemattributes`
where (`echothree`.`entitymultiplelistitemattributes`.`emlia_thrutime` = 9223372036854775807);

