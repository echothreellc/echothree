create definer = echothree@`127.0.0.1` view documentdescriptions as
select `echothree`.`documentdescriptions`.`dcmntd_documentdescriptionid` AS `dcmntd_documentdescriptionid`,
       `echothree`.`documentdescriptions`.`dcmntd_dcmnt_documentid`      AS `dcmntd_dcmnt_documentid`,
       `echothree`.`documentdescriptions`.`dcmntd_lang_languageid`       AS `dcmntd_lang_languageid`,
       `echothree`.`documentdescriptions`.`dcmntd_description`           AS `dcmntd_description`
from `echothree`.`documentdescriptions`
where (`echothree`.`documentdescriptions`.`dcmntd_thrutime` = 9223372036854775807);

