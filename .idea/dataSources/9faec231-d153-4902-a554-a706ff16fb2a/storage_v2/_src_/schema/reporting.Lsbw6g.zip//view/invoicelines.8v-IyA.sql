create definer = echothree@`127.0.0.1` view invoicelines as
select `echothree`.`invoicelines`.`invcl_invoicelineid`                        AS `invcl_invoicelineid`,
       `echothree`.`invoicelinedetails`.`invcldt_invc_invoiceid`               AS `invcldt_invc_invoiceid`,
       `echothree`.`invoicelinedetails`.`invcldt_invoicelinesequence`          AS `invcldt_invoicelinesequence`,
       `echothree`.`invoicelinedetails`.`invcldt_parentinvoicelineid`          AS `invcldt_parentinvoicelineid`,
       `echothree`.`invoicelinedetails`.`invcldt_invcltyp_invoicelinetypeid`   AS `invcldt_invcltyp_invoicelinetypeid`,
       `echothree`.`invoicelinedetails`.`invcldt_invclut_invoicelineusetypeid` AS `invcldt_invclut_invoicelineusetypeid`,
       `echothree`.`invoicelinedetails`.`invcldt_amount`                       AS `invcldt_amount`,
       `echothree`.`invoicelinedetails`.`invcldt_description`                  AS `invcldt_description`
from `echothree`.`invoicelines`
         join `echothree`.`invoicelinedetails`
where (`echothree`.`invoicelines`.`invcl_activedetailid` =
       `echothree`.`invoicelinedetails`.`invcldt_invoicelinedetailid`);

