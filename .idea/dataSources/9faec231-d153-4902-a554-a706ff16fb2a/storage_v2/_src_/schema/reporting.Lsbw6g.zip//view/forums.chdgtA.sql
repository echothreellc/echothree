create definer = echothree@`127.0.0.1` view forums as
select `echothree`.`forums`.`frm_forumid`                        AS `frm_forumid`,
       `echothree`.`forumdetails`.`frmdt_forumname`              AS `frmdt_forumname`,
       `echothree`.`forumdetails`.`frmdt_frmtyp_forumtypeid`     AS `frmdt_frmtyp_forumtypeid`,
       `echothree`.`forumdetails`.`frmdt_icn_iconid`             AS `frmdt_icn_iconid`,
       `echothree`.`forumdetails`.`frmdt_forumthreadsequenceid`  AS `frmdt_forumthreadsequenceid`,
       `echothree`.`forumdetails`.`frmdt_forummessagesequenceid` AS `frmdt_forummessagesequenceid`,
       `echothree`.`forumdetails`.`frmdt_sortorder`              AS `frmdt_sortorder`
from `echothree`.`forums`
         join `echothree`.`forumdetails`
where (`echothree`.`forums`.`frm_activedetailid` = `echothree`.`forumdetails`.`frmdt_forumdetailid`);

