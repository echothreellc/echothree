create definer = echothree@`127.0.0.1` view contactlistgroups as
select `echothree`.`contactlistgroups`.`clstgrp_contactlistgroupid`           AS `clstgrp_contactlistgroupid`,
       `echothree`.`contactlistgroupdetails`.`clstgrpdt_contactlistgroupname` AS `clstgrpdt_contactlistgroupname`,
       `echothree`.`contactlistgroupdetails`.`clstgrpdt_isdefault`            AS `clstgrpdt_isdefault`,
       `echothree`.`contactlistgroupdetails`.`clstgrpdt_sortorder`            AS `clstgrpdt_sortorder`
from `echothree`.`contactlistgroups`
         join `echothree`.`contactlistgroupdetails`
where (`echothree`.`contactlistgroups`.`clstgrp_activedetailid` =
       `echothree`.`contactlistgroupdetails`.`clstgrpdt_contactlistgroupdetailid`);

