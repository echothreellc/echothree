create definer = echothree@`127.0.0.1` view locationtypes as
select `echothree`.`locationtypes`.`loctyp_locationtypeid`           AS `loctyp_locationtypeid`,
       `echothree`.`locationtypedetails`.`loctypdt_warehousepartyid` AS `loctypdt_warehousepartyid`,
       `echothree`.`locationtypedetails`.`loctypdt_locationtypename` AS `loctypdt_locationtypename`,
       `echothree`.`locationtypedetails`.`loctypdt_isdefault`        AS `loctypdt_isdefault`,
       `echothree`.`locationtypedetails`.`loctypdt_sortorder`        AS `loctypdt_sortorder`
from `echothree`.`locationtypes`
         join `echothree`.`locationtypedetails`
where (`echothree`.`locationtypes`.`loctyp_activedetailid` =
       `echothree`.`locationtypedetails`.`loctypdt_locationtypedetailid`);

