create definer = echothree@`127.0.0.1` view commenttypedescriptions as
select `echothree`.`commenttypedescriptions`.`cmnttypd_commenttypedescriptionid` AS `cmnttypd_commenttypedescriptionid`,
       `echothree`.`commenttypedescriptions`.`cmnttypd_cmnttyp_commenttypeid`    AS `cmnttypd_cmnttyp_commenttypeid`,
       `echothree`.`commenttypedescriptions`.`cmnttypd_lang_languageid`          AS `cmnttypd_lang_languageid`,
       `echothree`.`commenttypedescriptions`.`cmnttypd_description`              AS `cmnttypd_description`
from `echothree`.`commenttypedescriptions`
where (`echothree`.`commenttypedescriptions`.`cmnttypd_thrutime` = 9223372036854775807);

