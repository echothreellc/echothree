create definer = echothree@`127.0.0.1` view jobstatuses as
select `echothree`.`jobstatuses`.`jbst_jobstatusid`   AS `jbst_jobstatusid`,
       `echothree`.`jobstatuses`.`jbst_jb_jobid`      AS `jbst_jb_jobid`,
       `echothree`.`jobstatuses`.`jbst_laststarttime` AS `jbst_laststarttime`,
       `echothree`.`jobstatuses`.`jbst_lastendtime`   AS `jbst_lastendtime`
from `echothree`.`jobstatuses`;

