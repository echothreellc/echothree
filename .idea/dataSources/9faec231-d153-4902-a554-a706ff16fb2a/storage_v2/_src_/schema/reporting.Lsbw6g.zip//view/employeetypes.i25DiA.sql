create definer = echothree@`127.0.0.1` view employeetypes as
select `echothree`.`employeetypes`.`empty_employeetypeid`           AS `empty_employeetypeid`,
       `echothree`.`employeetypedetails`.`emptydt_employeetypename` AS `emptydt_employeetypename`,
       `echothree`.`employeetypedetails`.`emptydt_isdefault`        AS `emptydt_isdefault`,
       `echothree`.`employeetypedetails`.`emptydt_sortorder`        AS `emptydt_sortorder`
from `echothree`.`employeetypes`
         join `echothree`.`employeetypedetails`
where (`echothree`.`employeetypes`.`empty_activedetailid` =
       `echothree`.`employeetypedetails`.`emptydt_employeetypedetailid`);

