create definer = echothree@`127.0.0.1` view inventorylocationgroups as
select `echothree`.`inventorylocationgroups`.`invlocgrp_inventorylocationgroupid`           AS `invlocgrp_inventorylocationgroupid`,
       `echothree`.`inventorylocationgroupdetails`.`invlocgrpdt_warehousepartyid`           AS `invlocgrpdt_warehousepartyid`,
       `echothree`.`inventorylocationgroupdetails`.`invlocgrpdt_inventorylocationgroupname` AS `invlocgrpdt_inventorylocationgroupname`,
       `echothree`.`inventorylocationgroupdetails`.`invlocgrpdt_isdefault`                  AS `invlocgrpdt_isdefault`,
       `echothree`.`inventorylocationgroupdetails`.`invlocgrpdt_sortorder`                  AS `invlocgrpdt_sortorder`
from `echothree`.`inventorylocationgroups`
         join `echothree`.`inventorylocationgroupdetails`
where (`echothree`.`inventorylocationgroups`.`invlocgrp_activedetailid` =
       `echothree`.`inventorylocationgroupdetails`.`invlocgrpdt_inventorylocationgroupdetailid`);

