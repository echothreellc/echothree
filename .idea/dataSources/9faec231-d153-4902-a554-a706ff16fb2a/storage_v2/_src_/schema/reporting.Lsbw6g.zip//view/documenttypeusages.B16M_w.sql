create definer = echothree@`127.0.0.1` view documenttypeusages as
select `echothree`.`documenttypeusages`.`dcmnttypu_documenttypeusageid`                  AS `dcmnttypu_documenttypeusageid`,
       `echothree`.`documenttypeusages`.`dcmnttypu_dcmnttyputyp_documenttypeusagetypeid` AS `dcmnttypu_dcmnttyputyp_documenttypeusagetypeid`,
       `echothree`.`documenttypeusages`.`dcmnttypu_dcmnttyp_documenttypeid`              AS `dcmnttypu_dcmnttyp_documenttypeid`,
       `echothree`.`documenttypeusages`.`dcmnttypu_isdefault`                            AS `dcmnttypu_isdefault`,
       `echothree`.`documenttypeusages`.`dcmnttypu_sortorder`                            AS `dcmnttypu_sortorder`,
       `echothree`.`documenttypeusages`.`dcmnttypu_maximuminstances`                     AS `dcmnttypu_maximuminstances`
from `echothree`.`documenttypeusages`
where (`echothree`.`documenttypeusages`.`dcmnttypu_thrutime` = 9223372036854775807);

