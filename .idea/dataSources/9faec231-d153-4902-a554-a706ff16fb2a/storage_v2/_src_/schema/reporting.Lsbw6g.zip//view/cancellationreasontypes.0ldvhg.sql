create definer = echothree@`127.0.0.1` view cancellationreasontypes as
select `echothree`.`cancellationreasontypes`.`cnclrsntyp_cancellationreasontypeid`     AS `cnclrsntyp_cancellationreasontypeid`,
       `echothree`.`cancellationreasontypes`.`cnclrsntyp_cnclrsn_cancellationreasonid` AS `cnclrsntyp_cnclrsn_cancellationreasonid`,
       `echothree`.`cancellationreasontypes`.`cnclrsntyp_cncltyp_cancellationtypeid`   AS `cnclrsntyp_cncltyp_cancellationtypeid`,
       `echothree`.`cancellationreasontypes`.`cnclrsntyp_isdefault`                    AS `cnclrsntyp_isdefault`,
       `echothree`.`cancellationreasontypes`.`cnclrsntyp_sortorder`                    AS `cnclrsntyp_sortorder`
from `echothree`.`cancellationreasontypes`
where (`echothree`.`cancellationreasontypes`.`cnclrsntyp_thrutime` = 9223372036854775807);

