create definer = echothree@`127.0.0.1` view chainentityroletypedescriptions as
select `echothree`.`chainentityroletypedescriptions`.`chnertypd_chainentityroletypedescriptionid` AS `chnertypd_chainentityroletypedescriptionid`,
       `echothree`.`chainentityroletypedescriptions`.`chnertypd_chnertyp_chainentityroletypeid`   AS `chnertypd_chnertyp_chainentityroletypeid`,
       `echothree`.`chainentityroletypedescriptions`.`chnertypd_lang_languageid`                  AS `chnertypd_lang_languageid`,
       `echothree`.`chainentityroletypedescriptions`.`chnertypd_description`                      AS `chnertypd_description`
from `echothree`.`chainentityroletypedescriptions`
where (`echothree`.`chainentityroletypedescriptions`.`chnertypd_thrutime` = 9223372036854775807);

