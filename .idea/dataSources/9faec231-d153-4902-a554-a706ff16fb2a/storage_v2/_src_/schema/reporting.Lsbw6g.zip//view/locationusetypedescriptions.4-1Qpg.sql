create definer = echothree@`127.0.0.1` view locationusetypedescriptions as
select `echothree`.`locationusetypedescriptions`.`locutypd_locationusetypedescriptionid` AS `locutypd_locationusetypedescriptionid`,
       `echothree`.`locationusetypedescriptions`.`locutypd_locutyp_locationusetypeid`    AS `locutypd_locutyp_locationusetypeid`,
       `echothree`.`locationusetypedescriptions`.`locutypd_lang_languageid`              AS `locutypd_lang_languageid`,
       `echothree`.`locationusetypedescriptions`.`locutypd_description`                  AS `locutypd_description`
from `echothree`.`locationusetypedescriptions`;

