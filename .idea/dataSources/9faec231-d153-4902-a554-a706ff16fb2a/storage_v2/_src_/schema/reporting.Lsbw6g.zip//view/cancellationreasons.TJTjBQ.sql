create definer = echothree@`127.0.0.1` view cancellationreasons as
select `echothree`.`cancellationreasons`.`cnclrsn_cancellationreasonid`             AS `cnclrsn_cancellationreasonid`,
       `echothree`.`cancellationreasondetails`.`cnclrsndt_cnclk_cancellationkindid` AS `cnclrsndt_cnclk_cancellationkindid`,
       `echothree`.`cancellationreasondetails`.`cnclrsndt_cancellationreasonname`   AS `cnclrsndt_cancellationreasonname`,
       `echothree`.`cancellationreasondetails`.`cnclrsndt_isdefault`                AS `cnclrsndt_isdefault`,
       `echothree`.`cancellationreasondetails`.`cnclrsndt_sortorder`                AS `cnclrsndt_sortorder`
from `echothree`.`cancellationreasons`
         join `echothree`.`cancellationreasondetails`
where (`echothree`.`cancellationreasons`.`cnclrsn_activedetailid` =
       `echothree`.`cancellationreasondetails`.`cnclrsndt_cancellationreasondetailid`);

