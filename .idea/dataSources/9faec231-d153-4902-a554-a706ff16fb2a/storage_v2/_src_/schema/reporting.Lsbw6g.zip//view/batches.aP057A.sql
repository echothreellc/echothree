create definer = echothree@`127.0.0.1` view batches as
select `echothree`.`batches`.`btch_batchid`                    AS `btch_batchid`,
       `echothree`.`batchdetails`.`btchdt_btchtyp_batchtypeid` AS `btchdt_btchtyp_batchtypeid`,
       `echothree`.`batchdetails`.`btchdt_batchname`           AS `btchdt_batchname`
from `echothree`.`batches`
         join `echothree`.`batchdetails`
where (`echothree`.`batches`.`btch_activedetailid` = `echothree`.`batchdetails`.`btchdt_batchdetailid`);

