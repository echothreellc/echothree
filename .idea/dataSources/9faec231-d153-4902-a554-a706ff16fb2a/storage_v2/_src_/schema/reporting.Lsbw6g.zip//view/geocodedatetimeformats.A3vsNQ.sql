create definer = echothree@`127.0.0.1` view geocodedatetimeformats as
select `echothree`.`geocodedatetimeformats`.`geodtf_geocodedatetimeformatid` AS `geodtf_geocodedatetimeformatid`,
       `echothree`.`geocodedatetimeformats`.`geodtf_geo_geocodeid`           AS `geodtf_geo_geocodeid`,
       `echothree`.`geocodedatetimeformats`.`geodtf_dtf_datetimeformatid`    AS `geodtf_dtf_datetimeformatid`,
       `echothree`.`geocodedatetimeformats`.`geodtf_isdefault`               AS `geodtf_isdefault`,
       `echothree`.`geocodedatetimeformats`.`geodtf_sortorder`               AS `geodtf_sortorder`
from `echothree`.`geocodedatetimeformats`
where (`echothree`.`geocodedatetimeformats`.`geodtf_thrutime` = 9223372036854775807);

